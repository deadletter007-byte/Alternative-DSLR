# Alternative DSLR — HDR Update 10: Local Tone Mapping

## বাস্তবায়ন
- HDR fusion output-এর ওপর 32×32 pixel cell-ভিত্তিক low-resolution luminance map তৈরি করা হয়েছে।
- 3×3 Gaussian-weighted smoothing দিয়ে local gain map মসৃণ করা হয়েছে, যাতে cell boundary-তে দৃশ্যমান banding/halo কমে।
- Gain map bilinear interpolation করে pixel-এ প্রয়োগ করা হয়।
- RGB channel-এ একই luminance scale প্রয়োগ করে hue shift কমানো হয়েছে।
- Local exposure gain 0.82× থেকে 1.22×-এর মধ্যে সীমাবদ্ধ।
- Full-frame float buffer তৈরি না করে ছোট grid ও 32-row tile ব্যবহার করা হয়েছে।

## সীমাবদ্ধতা
- এটি edge-aware/local Laplacian বা guided-filter tone mapper নয়; এটি lightweight local luminance adaptation।
- খুব ছোট বা high-contrast object boundary-তে কিছু halo/contrast change হতে পারে।
- এই update-এর Android Gradle build, unit test এবং Samsung S21 Plus physical-device test চালানো হয়নি।
- তাই এটি source-level implementation; device-verified feature নয়।
