# Alternative DSLR — HDR Update 15

## ধাপ ৬/১০: Highlight & Shadow Recovery

### পরিবর্তন
- `HighlightShadowRecovery.kt` নতুন low-memory, tile-based post-fusion recovery stage।
- Linear-light luminance অনুযায়ী deep shadow-তে সীমিত toe lift প্রয়োগ করা হয়।
- Bright region-এ smooth shoulder roll-off দিয়ে highlight gradation সংরক্ষণের চেষ্টা করা হয়।
- RGB channel-এ একই luminance scale প্রয়োগ করায় hue shift কমে।
- 24-row tile processing ব্যবহার করা হয়েছে; full-frame float buffer তৈরি হয় না।
- `HdrFusion.alignAndFuse()`-এ Local Tone Mapping-এর পর recovery stage যুক্ত হয়েছে।
- আগের motion detection, optical flow, parallax refinement, ghost suppression ও reference-frame fallback অপরিবর্তিত।

### সীমাবদ্ধতা
- এটি fused SDR bitmap-এর tonal remapping; সব exposure-এ clipped হয়ে যাওয়া highlight বা crushed shadow-এর প্রকৃত sensor detail ফিরিয়ে আনতে পারে না।
- JPEG input, পূর্ববর্তী tone curve এবং display-referred clipping-এর কারণে ফল source exposure-এর ওপর নির্ভরশীল।
- Shadow lift বেশি করলে noise দৃশ্যমান হতে পারে; তাই সীমিত রাখা হয়েছে।
- পূর্ণ Android Gradle build, unit/instrumented tests এবং Samsung Galaxy S21 Plus physical-device validation চালানো হয়নি।

### যাচাই
- Update14 source archive থেকে Update15 তৈরি।
- ZIP archive integrity পরীক্ষা করা হয়েছে।
- Kotlin source-level review করা হয়েছে; Android SDK/Gradle অনুপস্থিত থাকায় compiler/build pass দাবি করা হচ্ছে না।
