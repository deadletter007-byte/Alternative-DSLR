# HDR Update 16: Natural Color Reconstruction

## কী যুক্ত হয়েছে
- HDR fusion এবং Highlight/Shadow Recovery-এর পরে একটি conservative colour reconstruction pass যুক্ত হয়েছে।
- অতিরিক্ত saturated রঙকে সীমিতভাবে compress করে, বিশেষ করে উজ্জ্বল অংশে chroma কমিয়ে clipping-সদৃশ রঙের বিকৃতি কমানোর চেষ্টা করে।
- Luminance মোটামুটি অপরিবর্তিত রেখে RGB chroma নিয়ন্ত্রণ করে, ফলে neutral/কম saturated রঙে পরিবর্তন খুব কম হয়।
- সাধারণ skin-tone-এর মতো RGB range-এ হালকা protection heuristic আছে। এটি face detection বা নির্ভুল skin segmentation নয়।
- 32-row tile processing ব্যবহার করা হয়েছে, যাতে পুরো ছবির অতিরিক্ত pixel buffer তৈরি না হয়।

## সীমাবদ্ধতা
- এটি semantic AI colour reconstruction, camera-profile calibration, illuminant estimation বা RAW white-balance recovery নয়।
- ইনপুটে হারিয়ে যাওয়া/ক্লিপ হওয়া রঙ বা ডিটেইল ফিরিয়ে আনতে পারে না।
- ভিন্ন আলো ও বিভিন্ন ত্বকের রঙে বাস্তব ছবির মাধ্যমে tuning ও validation প্রয়োজন।

## Validation
- ZIP integrity পরীক্ষা করা হবে।
- Android Gradle build, Kotlin compilation এবং Samsung S21 Plus camera test এই প্যাকেজ তৈরির সময় চালানো হয়নি।
