# Alternative DSLR — HDR Update 12

## ধাপ ৩/১০: Optical Flow Alignment

এই আপডেটে আগের global translation alignment-এর ওপর একটি low-memory, block-based local optical-flow refinement যোগ করা হয়েছে। উদ্দেশ্য হলো HDR bracket frame-এর বিভিন্ন অঞ্চলে সামান্য আলাদা নড়াচড়া হলে একই global shift দিয়ে সব অঞ্চলকে ভুলভাবে align না করা।

### পরিবর্তন
- `OpticalFlowAlignment.kt` নতুন engine। 96×72-এর বেশি নয় এমন ছোট luminance analysis image ব্যবহার করে।
- 12×9 পর্যন্ত motion grid-এ 5×5 patch matching করা হয়; প্রতিটি patch সীমিত search window-তে displacement খোঁজে।
- Texture কম, match দুর্বল বা displacement অস্বাভাবিক হলে আগের global translation fallback রাখা হয়।
- নির্ভরযোগ্য প্রতিবেশী vector দিয়ে isolated অনির্ভরযোগ্য grid cell-এর displacement স্থিতিশীল করা হয়।
- `HdrFusion.kt`-এ প্রতিটি non-reference frame-এর জন্য local flow field তৈরি করে fusion-এর সময় displacement bilinear interpolation করা হয়।
- Full-resolution frame-এর সম্পূর্ণ IntArray কপি করা হয় না; প্রতিটি tile-এর জন্য bounded source strip পড়া হয়।
- আগের middle 0 EV reference, motion detection, local tone mapping এবং exposure fusion logic বজায় রাখা হয়েছে।

### গুরুত্বপূর্ণ সীমাবদ্ধতা
- এটি classical block-matching optical-flow approximation; Farneback, RAFT বা neural dense optical flow নয়।
- বড় parallax, rotation, rolling shutter, দ্রুত subject motion, low-texture surface এবং খুব কম আলোতে ভুল vector হতে পারে। Confidence কম হলে global translation fallback ব্যবহৃত হয়।
- S21 Plus-এ performance, memory এবং ghosting-এর বাস্তব ফল নিশ্চিত করতে physical-device test প্রয়োজন।
- এই পরিবেশে Android SDK/Gradle অনুপস্থিত; তাই Android Gradle build ও Robolectric test চালানো যায়নি।

### যাচাই
- আগের Update 11 ZIP-এর integrity test পাস করেছে।
- Update 12 source archive-এর ZIP integrity এবং Kotlin syntax (Android Bitmap stub-সহ compiler check) যাচাই করা হয়েছে।
- পূর্ণ Android build এবং S21 Plus camera test এখনো করা হয়নি।
