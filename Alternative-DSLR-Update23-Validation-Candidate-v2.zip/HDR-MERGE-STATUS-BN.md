# Alternative DSLR + HDR Updates: Merge Status

## এই প্যাকেজে যা করা হয়েছে
- `Alternative-DSLR-camera-capture-fix.zip`-কে মূল প্রজেক্ট হিসেবে রাখা হয়েছে।
- HDR Update 11–21-এর অনুপস্থিত HDR engine/helper source এবং সংশ্লিষ্ট unit test ফাইল যোগ করা হয়েছে।
- মূল ক্যামেরা প্রজেক্টের বিদ্যমান ফাইল overwrite করা হয়নি। বিশেষ করে `MainViewModel.kt`, `CameraMainScreen.kt`, `CameraUiState.kt`, `DeviceProfiler.kt`, `SettingsRepository.kt` এবং capture/touch/focus সংশোধন অপরিবর্তিত।
- আগের HDR update নোটগুলো audit trail হিসেবে যোগ করা হয়েছে।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
- বর্তমান camera-capture-fix-এর `MainViewModel`-এ exposure-bracket capture এবং `HdrFusion.alignAndFuse()` call নেই। তাই HDR fusion engine source যোগ হয়েছে, কিন্তু বাস্তব ক্যামেরার multi-frame HDR capture flow-তে এখনো যুক্ত হয়নি।
- `ComputationalPipeline`-ও single-image HDR-style tone mapping ব্যবহার করছে; এটিকে multi-frame HDR বলা যাবে না।
- এই পরিবেশে Android SDK/Gradle executable ও Gradle wrapper JAR নেই, তাই APK build বা Kotlin/Android compile test চালানো যায়নি। ZIP integrity এবং source-level merge পরীক্ষা করা হয়েছে মাত্র।

## পরবর্তী আবশ্যক কাজ
1. বর্তমান `MainViewModel`-এর camera capture lifecycle না ভেঙে bracket capture ও fusion যুক্ত করা।
2. Android Gradle build এবং unit tests চালানো।
3. বাস্তব ডিভাইসে HDR, motion/ghost, exposure, heat, memory এবং capture latency যাচাই করা।
