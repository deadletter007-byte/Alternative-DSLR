# HDR Update 22: Multi-frame HDR Capture Integration

## কী যুক্ত হয়েছে
- HDR mode-এ CameraX-এর সক্রিয় ক্যামেরার প্রকৃত exposure compensation range এবং step পড়া হয়।
- হার্ডওয়্যার অনুমতি দিলে ExposureBracketPlanner থেকে তিনটি EV index (কম, স্বাভাবিক, বেশি) নেওয়া হয়।
- প্রতিটি index প্রয়োগের পর আলাদা JPEG capture করা হয়।
- তিনটি JPEG decode ও orientation correction-এর পর HdrFusion.alignAndFuse() দিয়ে alignment, motion/ghost-aware fusion এবং বিদ্যমান HDR quality stages চালানো হয়।
- Fusion output ComputationalPipeline-এ `isMultiFrameHdr=true` হিসেবে পাঠানো হয়, ফলে fused ছবিতে single-frame HDR tone mapping দ্বিতীয়বার চালানো হয় না।
- Capture ব্যর্থ হলে exposure compensation আগের মানে ফেরত দেওয়ার চেষ্টা করা হয় এবং single-frame capture fallback চলে।
- EV range অনুপযুক্ত বা API অনুপলব্ধ হলে Multi-frame HDR হয়েছে বলে দাবি করা হয় না।

## সীমাবদ্ধতা ও যাচাই
- এই integration CameraX exposure compensation-এর ওপর নির্ভরশীল। সব ক্যামেরা/লেন্সে তিনটি পৃথক EV capture সম্ভব নাও হতে পারে।
- তিনটি capture sequential, তাই দ্রুত চলমান বিষয় বা হাত কাঁপার কারণে alignment/ghost artefact থাকতে পারে।
- RAW/DNG bracket capture এখানে যুক্ত হয়নি; JPEG pipeline ব্যবহৃত হয়েছে।
- Gradle/Android build এবং বাস্তব ডিভাইসে পরীক্ষা করা হয়নি, কারণ এই পরিবেশে Gradle executable/wrapper JAR নেই। তাই APK build success দাবি করা হচ্ছে না।
- S21 Plus-এ HDR mode, exposure restoration, moving subject, low light, memory pressure এবং fallback আলাদাভাবে পরীক্ষা করতে হবে।
