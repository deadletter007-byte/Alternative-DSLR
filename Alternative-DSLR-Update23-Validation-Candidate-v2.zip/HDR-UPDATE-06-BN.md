# Alternative DSLR — HDR Update 06

এই আপডেটে HDR bracket-এর তিনটি ফ্রেমকে মাঝের (0 EV) ফ্রেমের সঙ্গে ছোট-রেজোলিউশনের luminance block search দিয়ে global translation alignment করার চেষ্টা করা হয়। এরপর স্থানীয় luminance disagreement বেশি হলে পাশের exposure-এর অবদান কমিয়ে/বাদ দিয়ে reference frame-কে অগ্রাধিকার দেওয়া হয়। এতে ছোট হাত-কাঁপুনি ও কিছু moving-region ghosting কমতে পারে।

## সীমাবদ্ধতা
- এটি global translation alignment; optical flow, feature-based homography বা rolling-shutter correction নয়।
- দ্রুত চলমান বিষয়, parallax, বড় camera rotation বা subject deformation পুরোপুরি ঠিক করতে পারে না।
- এটি JPEG-based exposure fusion, radiance-map HDR reconstruction নয়।
- তিনটি full-resolution frame ও pixel arrays একসঙ্গে RAM-এ লাগে; উচ্চ রেজোলিউশনে OutOfMemory ঝুঁকি থাকতে পারে।
- Gradle build, unit/instrumentation test এবং Samsung S21 Plus hardware test এই প্যাকেজ তৈরির সময় চালানো হয়নি।
