# Alternative DSLR — HDR Update 08

## পরিবর্তন
- HDR frame fusion এখন encoded sRGB channel সরাসরি গড় না করে linear-light space-এ blend করে।
- Exposure weighting linear luminance ব্যবহার করে।
- Fusion output-এ ACES-inspired bounded filmic tone curve প্রয়োগ হয়, এরপর sRGB encoding করা হয়।
- আগের tiled processing ও reference-frame motion rejection বজায় আছে।

## সীমাবদ্ধতা
- এটি global tone mapping; local tone mapping নয়।
- Alignment এখনো global translation; dense optical flow নয়।
- JPEG source frames থেকে true sensor RAW HDR নয়।
- Build, automated tests এবং Samsung S21 Plus physical-device validation এখনো প্রয়োজন।
