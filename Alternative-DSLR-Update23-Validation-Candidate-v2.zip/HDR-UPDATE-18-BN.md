# HDR Update 18: Adaptive Noise Reduction

এই আপডেটে `AdaptiveNoiseReduction.kt` যোগ করা হয়েছে এবং `HdrFusion` pipeline-এ Natural Color Reconstruction-এর পরে, Edge-aware Detail Preservation-এর আগে যুক্ত করা হয়েছে।

## কী করে
- 3×3 bilateral neighbourhood দিয়ে কাছাকাছি luminance-এর pixel-কে সীমিতভাবে মিশিয়ে smooth-region noise কমানোর চেষ্টা করে।
- স্থানীয় luminance range দেখে smoothing strength নিয়ন্ত্রণ করে।
- শক্ত edge ও বেশি texture থাকা জায়গায় denoise blend কমিয়ে দেয়।
- 32-row tile এবং এক-pixel halo ব্যবহার করে tile boundary seam কমায়।
- Alpha channel অক্ষত রাখে এবং একই bitmap-এ কাজ করে, অতিরিক্ত full-frame bitmap তৈরি করে না।

## সীমাবদ্ধতা
এটি একটি conservative classical image-processing filter, AI denoiser নয়। সূক্ষ্ম texture ও noise সবসময় নির্ভুলভাবে আলাদা করা সম্ভব নয়। খুব বেশি ISO noise বা motion blur পুরোপুরি দূর করার দাবি করা হচ্ছে না। Android Gradle build এবং বাস্তব S21 Plus camera test আলাদাভাবে চালাতে হবে।
