# Alternative DSLR HDR Update 09

## Alignment confidence and safe fallback

- Added a confidence result to the low-resolution global translation estimator.
- A translated frame is used only when the match error is sufficiently low and the shift improves the zero-shift match.
- Ambiguous, low-texture, or noisy scenes fall back to zero translation instead of applying an arbitrary offset.
- The 0 EV reference remains unshifted and continues to anchor ghost-aware fusion.

## Limitations

This is still global translation alignment, not optical flow or local motion compensation. It does not fully correct parallax, rotation, rolling-shutter distortion, or independently moving subjects. Build and physical-device validation are still required.
