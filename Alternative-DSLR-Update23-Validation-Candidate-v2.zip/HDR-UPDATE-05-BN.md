# Alternative DSLR — HDR Capture Update 05

## Implemented in source
- HDR camera mode now checks the detected exposure compensation range and step.
- When a symmetric three-frame bracket is supported, CameraX captures three JPEG files sequentially at the planned EV compensation indices.
- Each EV request is awaited before its still capture starts.
- The original EV compensation is restored after success and on capture/error paths.
- Captured JPEGs are decoded and fused with a luminance-weighted pixel blend.
- If bracketing is unavailable, the app falls back to a normal single photo and reports why.
- HDR bracket is skipped when manual ISO or shutter is enabled, avoiding conflict with manual exposure.

## Important limitations
- This is a first functional three-frame bracket and basic exposure fusion, not motion-compensated HDR.
- No optical-flow alignment, ghost-removal mask, RAW merge, or sensor-level synchronized burst is implemented here.
- The resulting blend can show ghosting if the phone or subject moves between frames.
- Device-specific CameraX behavior must be tested on the Samsung Galaxy S21 Plus.
- Android build and unit tests were not run because this project snapshot has no `gradle-wrapper.jar` and no installed Gradle executable in the environment.
