package com.example

import com.example.engine.ExposureBracketPlanner
import org.junit.Assert.*
import org.junit.Test

class ExposureBracketPlannerTest {
    @Test fun plansSymmetricBracketWhenRangeAllowsIt() {
        val plan = ExposureBracketPlanner.create(-8, 8, 0.5f)
        assertEquals(listOf(-4, 0, 4), plan.compensationIndices)
        assertTrue(plan.supportsThreeFrameBracket)
    }

    @Test fun limitsBracketToActualCameraRange() {
        val plan = ExposureBracketPlanner.create(-2, 4, 0.5f)
        assertEquals(listOf(-2, 0, 2), plan.compensationIndices)
        assertTrue(plan.supportsThreeFrameBracket)
    }

    @Test fun rejectsInvalidRangesAndSteps() {
        assertFalse(ExposureBracketPlanner.create(4, -4, 0.5f).supportsThreeFrameBracket)
        assertFalse(ExposureBracketPlanner.create(-4, 4, 0f).supportsThreeFrameBracket)
    }

    @Test fun reportsNarrowRangeWithoutPretendingHdrIsPossible() {
        val plan = ExposureBracketPlanner.create(-1, 0, 1f)
        assertFalse(plan.supportsThreeFrameBracket)
        assertEquals(listOf(0), plan.compensationIndices)
    }
}
