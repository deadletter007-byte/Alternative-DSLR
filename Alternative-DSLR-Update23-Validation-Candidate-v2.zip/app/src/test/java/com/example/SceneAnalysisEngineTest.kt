package com.example

import com.example.engine.DetectedScene
import com.example.engine.SceneAnalysisEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SceneAnalysisEngineTest {
    @Test fun emptySamplesReturnSafeNeutralFallback() {
        val result = SceneAnalysisEngine.analyzeLumaSamples(intArrayOf())
        assertEquals(DetectedScene.BALANCED_DAYLIGHT, result.detectedScene)
        assertFalse(result.suggestsNightMode)
        assertFalse(result.suggestsHdr)
    }

    @Test fun darkFrameSuggestsNightModeWithoutClaimingCaptureWasApplied() {
        val result = SceneAnalysisEngine.analyzeLumaSamples(IntArray(1200) { 28 })
        assertEquals(DetectedScene.LOW_LIGHT, result.detectedScene)
        assertTrue(result.suggestsNightMode)
        assertTrue(result.suggestedIso >= 800)
    }

    @Test fun mixedDeepShadowsAndHighlightsSuggestHdr() {
        val samples = IntArray(1200) { index -> if (index < 600) 8 else 248 }
        val result = SceneAnalysisEngine.analyzeLumaSamples(samples)
        assertEquals(DetectedScene.HIGH_CONTRAST, result.detectedScene)
        assertTrue(result.suggestsHdr)
        assertFalse(result.suggestsNightMode)
    }

    @Test fun isolatedOutlierDoesNotCreateFalseHdrRecommendation() {
        val samples = IntArray(1200) { 110 }
        samples[0] = 0
        samples[1] = 255
        val result = SceneAnalysisEngine.analyzeLumaSamples(samples)
        assertFalse(result.suggestsHdr)
    }
}
