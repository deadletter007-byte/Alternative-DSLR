package com.example

import android.graphics.Bitmap
import android.graphics.Color
import com.example.engine.HdrQualityValidation
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class HdrQualityValidationTest {
    @Test
    fun reportsDimensionsAndPassesBalancedGradient() {
        val bitmap = Bitmap.createBitmap(64, 64, Bitmap.Config.ARGB_8888)
        for (y in 0 until 64) for (x in 0 until 64) {
            val value = (40 + x * 2 + y).coerceIn(0, 220)
            bitmap.setPixel(x, y, Color.rgb(value, value, value))
        }
        val report = HdrQualityValidation.inspect(bitmap)
        assertEquals(64, report.width)
        assertEquals(64, report.height)
        assertTrue(report.meanLuminance in 0.0..1.0)
        assertTrue(report.maxLuminance > report.minLuminance)
        assertTrue(report.passed)
        bitmap.recycle()
    }

    @Test
    fun warnsWhenOutputIsFullyClippedWhite() {
        val bitmap = Bitmap.createBitmap(32, 32, Bitmap.Config.ARGB_8888)
        bitmap.eraseColor(Color.WHITE)
        val report = HdrQualityValidation.inspect(bitmap)
        assertFalse(report.passed)
        assertTrue(report.clippedPixelRatio > 0.99)
        assertTrue(report.warnings.isNotEmpty())
        bitmap.recycle()
    }
}
