package com.example.ui.screens

import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Compare
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.camera.VirtualAperture
import com.example.editor.EditorAdjustments
import com.example.editor.PhotoEditorEngine
import com.example.gallery.CapturedMediaItem
import com.example.settings.ColorScienceProfile
import com.example.ui.theme.DslrAmber
import com.example.ui.theme.DslrCyan
import com.example.ui.theme.DslrGreen
import com.example.ui.theme.MetallicCarbon
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.TitaniumBright
import com.example.ui.theme.TitaniumDark
import com.example.ui.theme.TitaniumSilver
import kotlinx.coroutines.launch

enum class EditorToolTab {
    LIGHT,
    COLOR,
    TEXTURE,
    PORTRAIT_APERTURE,
    COLOR_PROFILE
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PhotoEditorScreen(
    item: CapturedMediaItem,
    onNavigateBack: () -> Unit,
    onSavedCopy: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onNavigateBack() }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var originalBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var previewBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var isComparingOriginal by remember { mutableStateOf(false) }
    var isProcessing by remember { mutableStateOf(false) }
    var isSaving by remember { mutableStateOf(false) }
    var statusMessage by remember { mutableStateOf<String?>(null) }

    var adjustments by remember { mutableStateOf(EditorAdjustments()) }
    var activeTab by remember { mutableStateOf(EditorToolTab.LIGHT) }

    // Load original bitmap
    LaunchedEffect(item.uri) {
        try {
            val bmp = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                ImageDecoder.decodeBitmap(ImageDecoder.createSource(context.contentResolver, item.uri)) { decoder, _, _ ->
                    decoder.isMutableRequired = true
                    decoder.setTargetSampleSize(1)
                }
            } else {
                @Suppress("DEPRECATION")
                MediaStore.Images.Media.getBitmap(context.contentResolver, item.uri)
            }
            originalBitmap = bmp
            previewBitmap = bmp
        } catch (e: Exception) {
            statusMessage = "Error loading image"
        }
    }

    // Reapply adjustments when parameters change
    fun updatePreview(newAdjustments: EditorAdjustments) {
        adjustments = newAdjustments
        val base = originalBitmap ?: return
        scope.launch {
            isProcessing = true
            val updated = PhotoEditorEngine.applyAdjustments(base, newAdjustments)
            previewBitmap = updated
            isProcessing = false
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Alternative DSLR Editor",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = TitaniumBright
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("editor_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = TitaniumBright
                        )
                    }
                },
                actions = {
                    // Reset
                    IconButton(
                        onClick = { updatePreview(EditorAdjustments()) },
                        modifier = Modifier.testTag("editor_reset_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.RestartAlt,
                            contentDescription = "Reset",
                            tint = TitaniumSilver
                        )
                    }
                    // Rotate
                    IconButton(
                        onClick = {
                            val newRot = (adjustments.rotationDegrees + 90) % 360
                            updatePreview(adjustments.copy(rotationDegrees = newRot))
                        },
                        modifier = Modifier.testTag("editor_rotate_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.RotateRight,
                            contentDescription = "Rotate 90°",
                            tint = TitaniumSilver
                        )
                    }
                    // Save
                    Button(
                        onClick = {
                            val finalBmp = previewBitmap ?: return@Button
                            scope.launch {
                                isSaving = true
                                val uri = PhotoEditorEngine.saveEditedCopy(context, finalBmp, item.displayName)
                                isSaving = false
                                if (uri != null) {
                                    onSavedCopy()
                                } else {
                                    statusMessage = "Save failed"
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = DslrAmber),
                        shape = RoundedCornerShape(8.dp),
                        enabled = !isSaving && previewBitmap != null,
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .testTag("editor_save_button")
                    ) {
                        if (isSaving) {
                            CircularProgressIndicator(color = ObsidianBlack, modifier = Modifier.size(14.dp))
                        } else {
                            Text("Save Copy", color = ObsidianBlack, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = ObsidianBlack)
            )
        },
        containerColor = ObsidianBlack,
        modifier = modifier.fillMaxSize()
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Live Preview Canvas
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .background(Color.Black)
                    .pointerInput(Unit) {
                        detectTapGestures(
                            onPress = {
                                isComparingOriginal = true
                                tryAwaitRelease()
                                isComparingOriginal = false
                            }
                        )
                    },
                contentAlignment = Alignment.Center
            ) {
                val displayBmp = if (isComparingOriginal) originalBitmap else previewBitmap
                if (displayBmp != null) {
                    Image(
                        bitmap = displayBmp.asImageBitmap(),
                        contentDescription = "Edited Image Preview",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                // Comparison badge
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(12.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(ObsidianBlack.copy(alpha = 0.85f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (isComparingOriginal) "HOLD: ORIGINAL" else "TOUCH TO COMPARE",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isComparingOriginal) DslrCyan else TitaniumSilver,
                        fontFamily = FontFamily.Monospace
                    )
                }

                if (isProcessing) {
                    CircularProgressIndicator(
                        color = DslrAmber,
                        strokeWidth = 2.dp,
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(16.dp)
                            .size(20.dp)
                    )
                }
            }

            // Tools Navigation Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MetallicCarbon)
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                EditorTabItem("LIGHT", activeTab == EditorToolTab.LIGHT) { activeTab = EditorToolTab.LIGHT }
                EditorTabItem("COLOR", activeTab == EditorToolTab.COLOR) { activeTab = EditorToolTab.COLOR }
                EditorTabItem("TEXTURE", activeTab == EditorToolTab.TEXTURE) { activeTab = EditorToolTab.TEXTURE }
                EditorTabItem("BOKEH", activeTab == EditorToolTab.PORTRAIT_APERTURE) { activeTab = EditorToolTab.PORTRAIT_APERTURE }
                EditorTabItem("PROFILE", activeTab == EditorToolTab.COLOR_PROFILE) { activeTab = EditorToolTab.COLOR_PROFILE }
            }

            // Sliders & Controls for Active Tab
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(ObsidianBlack)
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                when (activeTab) {
                    EditorToolTab.LIGHT -> {
                        Column {
                            EditorSliderRow(
                                label = "Exposure",
                                value = adjustments.exposure,
                                onValueChange = { updatePreview(adjustments.copy(exposure = it)) },
                                range = -100f..100f
                            )
                            EditorSliderRow(
                                label = "Contrast",
                                value = adjustments.contrast,
                                onValueChange = { updatePreview(adjustments.copy(contrast = it)) },
                                range = -100f..100f
                            )
                        }
                    }

                    EditorToolTab.COLOR -> {
                        Column {
                            EditorSliderRow(
                                label = "Saturation",
                                value = adjustments.saturation,
                                onValueChange = { updatePreview(adjustments.copy(saturation = it)) },
                                range = -100f..100f
                            )
                            EditorSliderRow(
                                label = "Temp (K)",
                                value = adjustments.temperature,
                                onValueChange = { updatePreview(adjustments.copy(temperature = it)) },
                                range = -100f..100f
                            )
                            EditorSliderRow(
                                label = "Tint",
                                value = adjustments.tint,
                                onValueChange = { updatePreview(adjustments.copy(tint = it)) },
                                range = -100f..100f
                            )
                        }
                    }

                    EditorToolTab.TEXTURE -> {
                        Column {
                            EditorSliderRow(
                                label = "Micro-Detail Pores & Fibers",
                                value = adjustments.texture,
                                onValueChange = { updatePreview(adjustments.copy(texture = it)) },
                                range = 0f..100f
                            )
                            Text(
                                text = "Zero plastic smoothing: amplifies visible skin texture, eyelashes, and textile fibers.",
                                fontSize = 10.sp,
                                color = TitaniumSilver,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                    }

                    EditorToolTab.PORTRAIT_APERTURE -> {
                        Column {
                            Text(
                                text = "Virtual Aperture Bokeh Simulation",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = DslrAmber,
                                modifier = Modifier.padding(bottom = 8.dp)
                            )
                            LazyRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                items(VirtualAperture.values()) { ap ->
                                    val isSelected = adjustments.selectedAperture == ap
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(if (isSelected) DslrAmber else TitaniumDark)
                                            .clickable { updatePreview(adjustments.copy(selectedAperture = ap)) }
                                            .padding(horizontal = 10.dp, vertical = 6.dp)
                                    ) {
                                        Text(
                                            text = ap.label,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isSelected) ObsidianBlack else TitaniumSilver,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                }
                            }
                        }
                    }

                    EditorToolTab.COLOR_PROFILE -> {
                        Column {
                            Text(
                                text = "Color Science Profile",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = DslrCyan,
                                modifier = Modifier.padding(bottom = 8.dp)
                            )
                            LazyRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                items(ColorScienceProfile.values()) { prof ->
                                    val isSelected = adjustments.selectedColorProfile == prof
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(if (isSelected) DslrCyan else TitaniumDark)
                                            .clickable { updatePreview(adjustments.copy(selectedColorProfile = prof)) }
                                            .padding(horizontal = 10.dp, vertical = 6.dp)
                                    ) {
                                        Text(
                                            text = prof.label,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isSelected) ObsidianBlack else TitaniumSilver,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EditorTabItem(text: String, isSelected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Text(
            text = text,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = if (isSelected) DslrAmber else TitaniumSilver,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
private fun EditorSliderRow(
    label: String,
    value: Float,
    onValueChange: (Float) -> Unit,
    range: ClosedFloatingPointRange<Float>
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            color = TitaniumSilver,
            modifier = Modifier.width(130.dp)
        )
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = DslrAmber,
                activeTrackColor = DslrAmber,
                inactiveTrackColor = TitaniumDark
            ),
            modifier = Modifier.weight(1f)
        )
        Text(
            text = "${value.toInt()}",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = TitaniumBright,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.width(36.dp)
        )
    }
}
