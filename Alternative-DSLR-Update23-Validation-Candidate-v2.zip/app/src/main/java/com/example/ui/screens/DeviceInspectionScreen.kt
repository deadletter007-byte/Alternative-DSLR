package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.capability.HardwareCapabilities
import com.example.capability.ProcessingProfile
import com.example.ui.theme.DslrAmber
import com.example.ui.theme.DslrCyan
import com.example.ui.theme.DslrGreen
import com.example.ui.theme.MetallicCarbon
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.TitaniumBright
import com.example.ui.theme.TitaniumDark
import com.example.ui.theme.TitaniumSilver

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeviceInspectionScreen(
    capabilities: HardwareCapabilities?,
    currentProfile: ProcessingProfile,
    onSelectProfile: (ProcessingProfile) -> Unit,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onNavigateBack() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Hardware Profiler & Telemetry",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = TitaniumBright
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("inspector_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = TitaniumBright
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = ObsidianBlack
                )
            )
        },
        containerColor = ObsidianBlack,
        modifier = modifier.fillMaxSize()
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // Processing Profile Selector Section
            Text(
                text = "ADAPTIVE PROCESSING PROFILES",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = DslrAmber,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.sp
            )
            Text(
                text = "Automatically determined from camera hardware level, RAM, and sensor specs.",
                fontSize = 11.sp,
                color = TitaniumSilver,
                modifier = Modifier.padding(top = 2.dp, bottom = 10.dp)
            )

            ProcessingProfile.values().forEach { profile ->
                val isSelected = profile == currentProfile
                val isRecommended = profile == capabilities?.recommendedProfile

                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) TitaniumDark else MetallicCarbon
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clickable { onSelectProfile(profile) }
                        .testTag("profile_card_${profile.name.lowercase()}")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = profile.title,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) DslrAmber else TitaniumBright
                                )
                                if (isRecommended) {
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(DslrGreen)
                                            .padding(horizontal = 4.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = "RECOMMENDED",
                                            fontSize = 8.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = ObsidianBlack
                                        )
                                    }
                                }
                            }
                            Text(
                                text = profile.description,
                                fontSize = 11.sp,
                                color = TitaniumSilver,
                                modifier = Modifier.padding(top = 3.dp)
                            )
                        }

                        if (isSelected) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Active Profile",
                                tint = DslrAmber,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Hardware Specifications Card
            if (capabilities != null) {
                Text(
                    text = "HARDWARE & SENSOR CAPABILITIES",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = DslrCyan,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                Card(
                    colors = CardDefaults.cardColors(containerColor = MetallicCarbon),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        TelemetryLine("Android Version", capabilities.androidVersion)
                        TelemetryLine("CPU Architecture", "${capabilities.cpuArch} (${capabilities.cpuCores} cores)")
                        TelemetryLine("Total RAM", "${capabilities.totalRamMb} MB (${capabilities.availableRamMb} MB free)")
                        TelemetryLine("Camera2 Hardware Level", capabilities.hardwareLevelName)
                        TelemetryLine("Thermal Status", capabilities.thermalStatus)
                        TelemetryLine("RAW Sensor Output", if (capabilities.supportsRawCapture) "Supported (DNG)" else "Unsupported")
                        TelemetryLine("Manual Exposure Control", if (capabilities.supportsManualExposure) "Supported" else "Limited")
                        TelemetryLine("Manual Focus Control", if (capabilities.supportsManualFocus) "Supported" else "Auto only")
                        TelemetryLine("Exposure Compensation", "${capabilities.exposureCompensationRange.first} to +${capabilities.exposureCompensationRange.second} (step ${capabilities.exposureCompensationStep})")
                        TelemetryLine("ISO Range", "${capabilities.isoRange.first} - ${capabilities.isoRange.second}")
                        TelemetryLine("Autofocus Modes", capabilities.supportedAfModes.joinToString(", "))
                        TelemetryLine("Auto White Balance Modes", capabilities.supportedAwbModes.joinToString(", "))
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Detected Physical Lenses
                Text(
                    text = "DETECTED OPTICAL LENSES",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = DslrGreen,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                capabilities.lenses.forEachIndexed { idx, lens ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MetallicCarbon),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "Lens #$idx: ${lens.facing} Camera (ID ${lens.id})",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = TitaniumBright
                            )
                            Text(
                                text = "Focal Length: ${lens.focalLengthsMm.joinToString { "${it}mm" }} • Aperture: ${lens.apertures.joinToString { "f/$it" }}",
                                fontSize = 11.sp,
                                color = TitaniumSilver
                            )
                            Text(
                                text = "Max Resolution: ${String.format("%.1f", lens.maxResolutionMegapixels)} MP • RAW: ${if (lens.supportsRaw) "Yes" else "No"}",
                                fontSize = 11.sp,
                                color = DslrAmber
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun TelemetryLine(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            color = TitaniumSilver
        )
        Text(
            text = value,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            color = TitaniumBright,
            fontFamily = FontFamily.Monospace
        )
    }
}
