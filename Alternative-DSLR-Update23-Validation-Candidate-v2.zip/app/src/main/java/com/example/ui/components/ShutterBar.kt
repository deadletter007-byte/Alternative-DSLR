package com.example.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.camera.CameraUiState
import com.example.ui.theme.DslrAmber
import com.example.ui.theme.DslrRed
import com.example.ui.theme.MetallicCarbon
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.TitaniumBright
import com.example.ui.theme.TitaniumDark
import com.example.ui.theme.TitaniumMid
import com.example.ui.theme.TitaniumSilver

@Composable
fun ShutterBar(
    state: CameraUiState,
    onTriggerCapture: () -> Unit,
    onToggleVideo: () -> Unit,
    onToggleCameraFacing: () -> Unit,
    onOpenGallery: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val recPulseScale by infiniteTransition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(600),
            repeatMode = RepeatMode.Reverse
        ),
        label = "recPulse"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(ObsidianBlack.copy(alpha = 0.95f))
            .padding(horizontal = 24.dp, vertical = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Left: Gallery Thumbnail
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(TitaniumDark)
                    .border(BorderStroke(1.5.dp, TitaniumMid), CircleShape)
                    .clickable { onOpenGallery() }
                    .testTag("gallery_thumbnail_button"),
                contentAlignment = Alignment.Center
            ) {
                if (state.lastCapturedItem != null) {
                    AsyncImage(
                        model = state.lastCapturedItem.uri,
                        contentDescription = "Last captured photo",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(CircleShape)
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.PhotoLibrary,
                        contentDescription = "Open Gallery",
                        tint = TitaniumSilver,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            // Center: DSLR Shutter Button or Video Record Button
            if (state.selectedMode.isVideo) {
                // Video Mode Record Button
                Box(
                    modifier = Modifier
                        .size(76.dp)
                        .clip(CircleShape)
                        .background(TitaniumDark)
                        .border(BorderStroke(3.dp, TitaniumSilver), CircleShape)
                        .clickable { onToggleVideo() }
                        .testTag("video_record_button"),
                    contentAlignment = Alignment.Center
                ) {
                    if (state.isRecordingVideo) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .scale(recPulseScale)
                                .clip(RoundedCornerShape(8.dp))
                                .background(DslrRed)
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                                .background(DslrRed)
                        )
                    }
                }
            } else {
                // Photo Mode Capture Button (DSLR Machined Bevel)
                Box(
                    modifier = Modifier
                        .size(76.dp)
                        .clip(CircleShape)
                        .background(TitaniumDark)
                        .border(BorderStroke(3.5.dp, TitaniumBright), CircleShape)
                        .clickable(enabled = !state.isCapturing) { onTriggerCapture() }
                        .testTag("camera_capture_button"),
                    contentAlignment = Alignment.Center
                ) {
                    if (state.isCapturing) {
                        CircularProgressIndicator(
                            color = DslrAmber,
                            strokeWidth = 3.dp,
                            modifier = Modifier.size(54.dp)
                        )
                    } else {
                        // Inner DSLR polished ring
                        Box(
                            modifier = Modifier
                                .size(58.dp)
                                .clip(CircleShape)
                                .background(TitaniumBright)
                                .border(BorderStroke(1.5.dp, MetallicCarbon), CircleShape)
                        )
                    }
                }
            }

            // Right: Flip Camera Facing
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(TitaniumDark)
                    .border(BorderStroke(1.5.dp, TitaniumMid), CircleShape)
                    .clickable { onToggleCameraFacing() }
                    .testTag("switch_camera_button"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Cameraswitch,
                    contentDescription = "Switch Camera Front or Rear",
                    tint = TitaniumSilver,
                    modifier = Modifier.size(24.dp)
                )
            }
        }

        // Live Video Duration Counter if recording
        if (state.isRecordingVideo) {
            val mins = state.videoDurationSeconds / 60
            val secs = state.videoDurationSeconds % 60
            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(bottom = 80.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(DslrRed.copy(alpha = 0.9f))
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "REC  ${String.format("%02d:%02d", mins, secs)}",
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}
