package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.camera.CameraUiState
import com.example.ui.theme.DslrAmber
import com.example.ui.theme.DslrCyan
import com.example.ui.theme.DslrGold
import com.example.ui.theme.DslrGreen
import com.example.ui.theme.DslrRed
import com.example.ui.theme.MetallicCarbon
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.TitaniumBright
import com.example.ui.theme.TitaniumDark
import com.example.ui.theme.TitaniumMid
import com.example.ui.theme.TitaniumSilver

enum class ProTab {
    ISO,
    SHUTTER,
    EV,
    FOCUS,
    WB
}

@Composable
fun ProControlsPanel(
    state: CameraUiState,
    onSetIso: (Int) -> Unit,
    onToggleAutoIso: () -> Unit,
    onSetShutter: (String) -> Unit,
    onToggleAutoShutter: () -> Unit,
    onSetEv: (Int) -> Unit,
    onSetFocus: (Float) -> Unit,
    onToggleAutoFocus: () -> Unit,
    onSetKelvin: (Int) -> Unit,
    onToggleAutoWb: () -> Unit,
    onToggleAeLock: () -> Unit,
    onToggleAfLock: () -> Unit,
    onToggleRaw: () -> Unit,
    onTogglePeaking: () -> Unit,
    onToggleZebra: () -> Unit,
    modifier: Modifier = Modifier
) {
    var activeTab by remember { mutableStateOf(ProTab.ISO) }

    val shutterSpeeds = listOf(
        "1/4000s", "1/2000s", "1/1000s", "1/500s", "1/250s",
        "1/125s", "1/60s", "1/30s", "1/15s", "1/8s", "1/4s", "1/2s", "1s"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(ObsidianBlack.copy(alpha = 0.90f))
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        // Tab Selector (ISO, SHUTTER, EV, FOCUS, WB, LOCKS)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            ProTabButton("ISO", activeTab == ProTab.ISO) { activeTab = ProTab.ISO }
            ProTabButton("SEC", activeTab == ProTab.SHUTTER) { activeTab = ProTab.SHUTTER }
            ProTabButton("EV", activeTab == ProTab.EV) { activeTab = ProTab.EV }
            ProTabButton("MF", activeTab == ProTab.FOCUS) { activeTab = ProTab.FOCUS }
            ProTabButton("WB", activeTab == ProTab.WB) { activeTab = ProTab.WB }

            // AE Lock button
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(if (state.isAeLocked) DslrAmber else TitaniumDark)
                    .clickable { onToggleAeLock() }
                    .padding(horizontal = 6.dp, vertical = 3.dp)
                    .testTag("ae_lock_button")
            ) {
                Text(
                    text = "AEL",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (state.isAeLocked) ObsidianBlack else TitaniumSilver,
                    fontFamily = FontFamily.Monospace
                )
            }

            // AF Lock button
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(if (state.isAfLocked) DslrGreen else TitaniumDark)
                    .clickable { onToggleAfLock() }
                    .padding(horizontal = 6.dp, vertical = 3.dp)
                    .testTag("af_lock_button")
            ) {
                Text(
                    text = "AFL",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (state.isAfLocked) ObsidianBlack else TitaniumSilver,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Active Tab Slider / Controls
        when (activeTab) {
            ProTab.ISO -> {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AutoToggle(isAuto = !state.isManualIso, onToggle = onToggleAutoIso)
                    Spacer(modifier = Modifier.width(12.dp))
                    Slider(
                        value = state.manualIso.toFloat(),
                        onValueChange = { onSetIso(it.toInt()) },
                        valueRange = 50f..3200f,
                        steps = 15,
                        enabled = state.isManualIso,
                        colors = SliderDefaults.colors(
                            thumbColor = DslrAmber,
                            activeTrackColor = DslrAmber,
                            inactiveTrackColor = TitaniumDark
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("iso_slider")
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (state.isManualIso) "${state.manualIso}" else "AUTO",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = DslrAmber,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.width(48.dp)
                    )
                }
            }

            ProTab.SHUTTER -> {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AutoToggle(isAuto = !state.isManualShutter, onToggle = onToggleAutoShutter)
                    Spacer(modifier = Modifier.width(12.dp))
                    val currentIndex = shutterSpeeds.indexOf(state.manualShutterSpeed).coerceAtLeast(0)
                    Slider(
                        value = currentIndex.toFloat(),
                        onValueChange = { index ->
                            val s = shutterSpeeds[index.toInt().coerceIn(0, shutterSpeeds.size - 1)]
                            onSetShutter(s)
                        },
                        valueRange = 0f..(shutterSpeeds.size - 1).toFloat(),
                        steps = shutterSpeeds.size - 2,
                        enabled = state.isManualShutter,
                        colors = SliderDefaults.colors(
                            thumbColor = DslrAmber,
                            activeTrackColor = DslrAmber,
                            inactiveTrackColor = TitaniumDark
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("shutter_slider")
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (state.isManualShutter) state.manualShutterSpeed else "AUTO",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = DslrAmber,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.width(52.dp)
                    )
                }
            }

            ProTab.EV -> {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "EV COMP",
                        fontSize = 11.sp,
                        color = TitaniumSilver,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    val range = state.capabilities?.exposureCompensationRange ?: Pair(-4, 4)
                    Slider(
                        value = state.evCompensation.toFloat(),
                        onValueChange = { onSetEv(it.toInt()) },
                        valueRange = range.first.toFloat()..range.second.toFloat(),
                        steps = (range.second - range.first - 1).coerceAtLeast(0),
                        colors = SliderDefaults.colors(
                            thumbColor = DslrCyan,
                            activeTrackColor = DslrCyan,
                            inactiveTrackColor = TitaniumDark
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("ev_slider")
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (state.evCompensation >= 0) "+${state.evCompensation}" else "${state.evCompensation}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = DslrCyan,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.width(36.dp)
                    )
                }
            }

            ProTab.FOCUS -> {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AutoToggle(isAuto = !state.isManualFocus, onToggle = onToggleAutoFocus)
                    Spacer(modifier = Modifier.width(12.dp))
                    Slider(
                        value = state.manualFocusDistance,
                        onValueChange = { onSetFocus(it) },
                        valueRange = 0f..1f,
                        enabled = state.isManualFocus,
                        colors = SliderDefaults.colors(
                            thumbColor = DslrGreen,
                            activeTrackColor = DslrGreen,
                            inactiveTrackColor = TitaniumDark
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("focus_slider")
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (state.isManualFocus) {
                            if (state.manualFocusDistance < 0.1f) "∞" else String.format("%.2fm", 1.0f / (state.manualFocusDistance * 10f))
                        } else "AF",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = DslrGreen,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.width(42.dp)
                    )
                }
            }

            ProTab.WB -> {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AutoToggle(isAuto = !state.isManualWb, onToggle = onToggleAutoWb)
                    Spacer(modifier = Modifier.width(12.dp))
                    Slider(
                        value = state.whiteBalanceKelvin.toFloat(),
                        onValueChange = { onSetKelvin(it.toInt()) },
                        valueRange = 2500f..8500f,
                        enabled = state.isManualWb,
                        colors = SliderDefaults.colors(
                            thumbColor = DslrGold,
                            activeTrackColor = DslrGold,
                            inactiveTrackColor = TitaniumDark
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("wb_slider")
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (state.isManualWb) "${state.whiteBalanceKelvin}K" else "AWB",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = DslrGold,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.width(50.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Pro Tool Toggles: RAW, Focus Peaking, Zebra Warning
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            SmallToolToggle(
                label = "RAW DNG",
                isActive = state.isRawCaptureEnabled,
                onClick = onToggleRaw
            )
            SmallToolToggle(
                label = "FOCUS PEAK",
                isActive = state.showFocusPeaking,
                onClick = onTogglePeaking
            )
            SmallToolToggle(
                label = "ZEBRA 95%",
                isActive = state.showZebraWarning,
                onClick = onToggleZebra
            )
        }
    }
}

@Composable
private fun ProTabButton(text: String, isSelected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(if (isSelected) TitaniumMid else Color.Transparent)
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(
            text = text,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Medium,
            color = if (isSelected) DslrAmber else TitaniumSilver,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
private fun AutoToggle(isAuto: Boolean, onToggle: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(if (isAuto) DslrAmber else TitaniumDark)
            .clickable { onToggle() }
            .padding(horizontal = 6.dp, vertical = 4.dp)
    ) {
        Text(
            text = "AUTO",
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = if (isAuto) ObsidianBlack else TitaniumSilver,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
private fun SmallToolToggle(label: String, isActive: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(if (isActive) TitaniumMid else TitaniumDark)
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(
            text = label,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = if (isActive) DslrAmber else TitaniumSilver,
            fontFamily = FontFamily.Monospace
        )
    }
}
