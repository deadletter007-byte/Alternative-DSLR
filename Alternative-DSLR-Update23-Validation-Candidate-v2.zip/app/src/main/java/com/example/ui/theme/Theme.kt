package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DslrDarkColorScheme = darkColorScheme(
    primary = TitaniumBright,
    onPrimary = ObsidianBlack,
    primaryContainer = TitaniumMid,
    onPrimaryContainer = TitaniumBright,
    secondary = DslrAmber,
    onSecondary = ObsidianBlack,
    secondaryContainer = TitaniumDark,
    onSecondaryContainer = DslrGold,
    tertiary = DslrCyan,
    onTertiary = ObsidianBlack,
    background = ObsidianBlack,
    onBackground = TitaniumBright,
    surface = MetallicCarbon,
    onSurface = TitaniumBright,
    surfaceVariant = TitaniumDark,
    onSurfaceVariant = TitaniumSilver,
    outline = TitaniumMid,
    outlineVariant = Color(0xFF22252C),
    error = DslrRed,
    onError = Color.White
)

@Composable
fun AlternativeDslrTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DslrDarkColorScheme,
        typography = Typography,
        content = content
    )
}
