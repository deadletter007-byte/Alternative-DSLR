package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.gallery.CapturedMediaItem
import com.example.ui.theme.DslrAmber
import com.example.ui.theme.DslrCyan
import com.example.ui.theme.MetallicCarbon
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.TitaniumBright
import com.example.ui.theme.TitaniumDark
import com.example.ui.theme.TitaniumSilver

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CompareScreen(
    item: CapturedMediaItem,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onNavigateBack() }
    var showProcessed by remember { mutableStateOf(true) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Original vs Processed",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = TitaniumBright
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("compare_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = TitaniumBright
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = ObsidianBlack
                )
            )
        },
        containerColor = ObsidianBlack,
        modifier = modifier.fillMaxSize()
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Toggle Switch
            Row(
                modifier = Modifier
                    .padding(vertical = 12.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(MetallicCarbon)
                    .padding(4.dp),
                horizontalArrangement = Arrangement.Center
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (showProcessed) DslrAmber else Color.Transparent)
                        .clickable { showProcessed = true }
                        .padding(horizontal = 20.dp, vertical = 8.dp)
                        .testTag("toggle_processed_button")
                ) {
                    Text(
                        text = "PROCESSED (ADSLR)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (showProcessed) ObsidianBlack else TitaniumSilver,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (!showProcessed) DslrCyan else Color.Transparent)
                        .clickable { showProcessed = false }
                        .padding(horizontal = 20.dp, vertical = 8.dp)
                        .testTag("toggle_original_button")
                ) {
                    Text(
                        text = "SENSOR ORIGINAL",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (!showProcessed) ObsidianBlack else TitaniumSilver,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            // Image display
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .background(Color.Black),
                contentAlignment = Alignment.Center
            ) {
                val activeUri = if (showProcessed) item.uri else (item.originalUri ?: item.uri)
                AsyncImage(
                    model = activeUri,
                    contentDescription = if (showProcessed) "Processed image" else "Original image",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize()
                )

                // Current view badge
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(16.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(ObsidianBlack.copy(alpha = 0.85f))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (showProcessed) "Alternative DSLR Computational Engine" else "Original Unprocessed Sensor Data",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (showProcessed) DslrAmber else DslrCyan,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            // Engine details panel
            Card(
                colors = CardDefaults.cardColors(containerColor = MetallicCarbon),
                shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (showProcessed) "COMPUTATIONAL ENHANCEMENTS APPLIED" else "SENSOR BASELINE",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (showProcessed) DslrAmber else DslrCyan,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    if (showProcessed) {
                        Text(
                            text = "• Natural Color Grading with Kelvin Tone Alignment\n• Micro-Contrast Enhancement (Zero Plastic Beauty Filter)\n• HDR Highlight Rolloff & Shadow Detail Recovery\n• Tactile Noise Reduction & Grain Harmonization",
                            fontSize = 11.sp,
                            color = TitaniumBright,
                            lineHeight = 16.sp
                        )
                    } else {
                        Text(
                            text = "• Raw unprocessed single-exposure capture\n• Standard sensor demosaicing\n• Preserved without computational optics or bokeh",
                            fontSize = 11.sp,
                            color = TitaniumSilver,
                            lineHeight = 16.sp
                        )
                    }
                }
            }
        }
    }
}
