package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Alternative DSLR Titanium & Obsidian Dark Palette
val ObsidianBlack = Color(0xFF090A0C)
val MetallicCarbon = Color(0xFF131519)
val TitaniumDark = Color(0xFF1C1E24)
val TitaniumMid = Color(0xFF2B2E37)
val TitaniumSilver = Color(0xFFD4D8DF)
val TitaniumBright = Color(0xFFF1F3F6)

// Accent Colors inspired by high-end DSLR status lamps & red ring lenses
val DslrAmber = Color(0xFFFFB300)
val DslrGold = Color(0xFFFFD54F)
val DslrRed = Color(0xFFFF3B30)
val DslrCyan = Color(0xFF00E5FF)
val DslrGreen = Color(0xFF00E676)

// Zebra & Peaking
val ZebraYellow = Color(0xFFFFEB3B)
val PeakingGreen = Color(0xFF76FF03)
val LevelGreen = Color(0xFF00E676)
val LevelWarning = Color(0xFFFF9100)
