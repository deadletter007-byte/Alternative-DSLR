package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.camera.CameraUiState
import com.example.camera.GridType
import com.example.ui.theme.DslrAmber
import com.example.ui.theme.DslrCyan
import com.example.ui.theme.DslrGreen
import com.example.ui.theme.DslrRed
import com.example.ui.theme.LevelGreen
import com.example.ui.theme.LevelWarning
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.PeakingGreen
import com.example.ui.theme.ZebraYellow
import kotlin.math.abs

@Composable
fun ViewfinderOverlays(
    state: CameraUiState,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier.fillMaxSize()) {

        // 1. Framing Grid Lines
        if (state.showGrid && state.gridType != GridType.NONE) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                val lineColor = Color.White.copy(alpha = 0.35f)
                val strokeWidth = 1.2.dp.toPx()

                when (state.gridType) {
                    GridType.RULE_OF_THIRDS -> {
                        // Vertical lines at 1/3 and 2/3
                        drawLine(lineColor, Offset(w / 3f, 0f), Offset(w / 3f, h), strokeWidth)
                        drawLine(lineColor, Offset(2f * w / 3f, 0f), Offset(2f * w / 3f, h), strokeWidth)
                        // Horizontal lines at 1/3 and 2/3
                        drawLine(lineColor, Offset(0f, h / 3f), Offset(w, h / 3f), strokeWidth)
                        drawLine(lineColor, Offset(0f, 2f * h / 3f), Offset(w, 2f * h / 3f), strokeWidth)
                    }
                    GridType.GOLDEN_RATIO -> {
                        val phiRatio = 0.382f
                        drawLine(lineColor, Offset(w * phiRatio, 0f), Offset(w * phiRatio, h), strokeWidth)
                        drawLine(lineColor, Offset(w * (1f - phiRatio), 0f), Offset(w * (1f - phiRatio), h), strokeWidth)
                        drawLine(lineColor, Offset(0f, h * phiRatio), Offset(w, h * phiRatio), strokeWidth)
                        drawLine(lineColor, Offset(0f, h * (1f - phiRatio)), Offset(w, h * (1f - phiRatio)), strokeWidth)
                    }
                    GridType.SQUARE -> {
                        val side = minOf(w, h)
                        val left = (w - side) / 2f
                        val top = (h - side) / 2f
                        drawRect(
                            color = lineColor,
                            topLeft = Offset(left, top),
                            size = Size(side, side),
                            style = Stroke(width = strokeWidth)
                        )
                    }
                    else -> {}
                }
            }
        }

        // 2. Horizon Level Indicator
        if (state.showHorizonLevel) {
            val roll = state.rollDegrees
            val isLevel = abs(roll) < 1.0f
            val indicatorColor = if (isLevel) LevelGreen else LevelWarning

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 48.dp),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val cx = size.width / 2f
                    val cy = size.height / 2f
                    val lineLength = 120.dp.toPx()

                    rotate(degrees = -roll, pivot = Offset(cx, cy)) {
                        // Left bar
                        drawLine(
                            color = indicatorColor,
                            start = Offset(cx - lineLength, cy),
                            end = Offset(cx - 30.dp.toPx(), cy),
                            strokeWidth = if (isLevel) 3.dp.toPx() else 1.8.dp.toPx()
                        )
                        // Right bar
                        drawLine(
                            color = indicatorColor,
                            start = Offset(cx + 30.dp.toPx(), cy),
                            end = Offset(cx + lineLength, cy),
                            strokeWidth = if (isLevel) 3.dp.toPx() else 1.8.dp.toPx()
                        )
                        // Center reticle dot
                        drawCircle(
                            color = indicatorColor,
                            radius = if (isLevel) 4.dp.toPx() else 2.5.dp.toPx(),
                            center = Offset(cx, cy)
                        )
                    }
                }

                // Numerical degree badge
                Text(
                    text = "${if (roll > 0) "+" else ""}${String.format("%.1f", roll)}°",
                    color = indicatorColor,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(top = 34.dp)
                )
            }
        }

        // 3. Real-time Histogram HUD (Top Left)
        if (state.showHistogram) {
            Box(
                modifier = Modifier
                    .padding(start = 12.dp, top = 8.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(ObsidianBlack.copy(alpha = 0.75f))
                    .padding(6.dp)
            ) {
                Canvas(
                    modifier = Modifier
                        .width(90.dp)
                        .height(36.dp)
                ) {
                    val bins = state.histogramLuminance
                    val barWidth = size.width / bins.size.toFloat()
                    for (i in bins.indices) {
                        val barH = size.height * bins[i]
                        drawRect(
                            color = Color.White.copy(alpha = 0.85f),
                            topLeft = Offset(i * barWidth, size.height - barH),
                            size = Size(barWidth - 0.5f, barH)
                        )
                    }
                }
            }
        }

        // 4. Focus Peaking Overlay Simulation
        if (state.showFocusPeaking) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val cx = size.width / 2f
                val cy = size.height / 2f
                val radius = size.width * 0.22f
                drawCircle(
                    color = PeakingGreen.copy(alpha = 0.6f),
                    center = Offset(cx, cy),
                    radius = radius,
                    style = Stroke(width = 2.dp.toPx())
                )
            }
        }

        // 5. Zebra Exposure Warning Overlay
        if (state.showZebraWarning) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                // Diagonal warning hash pattern in top highlight region
                val w = size.width
                val h = size.height * 0.25f
                for (x in 0..(w + h).toInt() step 20) {
                    drawLine(
                        color = ZebraYellow.copy(alpha = 0.45f),
                        start = Offset(x.toFloat(), 0f),
                        end = Offset((x - 20).toFloat(), h),
                        strokeWidth = 2.dp.toPx()
                    )
                }
            }
        }

        // 6. Large Shutter Countdown Overlay
        AnimatedVisibility(
            visible = state.countdownRemaining > 0,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.Center)
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(24.dp))
                    .background(ObsidianBlack.copy(alpha = 0.85f))
                    .padding(horizontal = 40.dp, vertical = 24.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "${state.countdownRemaining}",
                    fontSize = 72.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = DslrAmber,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}
