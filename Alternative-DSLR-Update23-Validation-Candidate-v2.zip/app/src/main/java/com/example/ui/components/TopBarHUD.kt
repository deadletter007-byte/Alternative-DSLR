package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.FlashAuto
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.GridOn
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.camera.core.ImageCapture
import com.example.camera.ActiveScreen
import com.example.camera.CameraUiState
import com.example.camera.GridType
import com.example.ui.theme.DslrAmber
import com.example.ui.theme.DslrCyan
import com.example.ui.theme.DslrGold
import com.example.ui.theme.DslrGreen
import com.example.ui.theme.DslrRed
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.TitaniumBright
import com.example.ui.theme.TitaniumDark
import com.example.ui.theme.TitaniumSilver

@Composable
fun TopBarHUD(
    state: CameraUiState,
    onToggleFlash: () -> Unit,
    onCycleTimer: () -> Unit,
    onCycleGrid: () -> Unit,
    onToggleLevel: () -> Unit,
    onOpenAiAssistant: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenInspector: () -> Unit,
    onOpenAbout: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(ObsidianBlack.copy(alpha = 0.82f))
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        // Upper row: DSLR Telemetry Readout (ISO, Shutter, EV, WB, RAW, Profile)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Profile & RAW badge
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(state.currentProfile.let {
                            if (it.supportsSuperRes) DslrAmber else TitaniumDark
                        })
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = state.currentProfile.name.take(4),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = ObsidianBlack,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (state.isRawCaptureEnabled) DslrRed else Color.Transparent)
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = if (state.isRawCaptureEnabled) "RAW+JPG" else "JPEG",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (state.isRawCaptureEnabled) Color.White else TitaniumSilver,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            // Real DSLR Optical Parameters (ISO, Shutter, EV, Kelvin)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                TelemetryItem(
                    label = "ISO",
                    value = if (state.isManualIso) "${state.manualIso}" else "A ${state.liveScene?.suggestedIso ?: 100}",
                    isManual = state.isManualIso
                )
                TelemetryItem(
                    label = "SEC",
                    value = if (state.isManualShutter) state.manualShutterSpeed else "A ${state.liveScene?.suggestedShutterSpeed ?: "1/250"}",
                    isManual = state.isManualShutter
                )
                TelemetryItem(
                    label = "EV",
                    value = if (state.evCompensation >= 0) "+${state.evCompensation}" else "${state.evCompensation}",
                    isManual = state.evCompensation != 0
                )
                TelemetryItem(
                    label = "WB",
                    value = "${state.whiteBalanceKelvin}K",
                    isManual = state.isManualWb
                )
            }

            // Battery / Thermal Health
            Text(
                text = state.capabilities?.thermalStatus ?: "OK",
                fontSize = 10.sp,
                color = DslrGreen,
                fontWeight = FontWeight.Medium,
                fontFamily = FontFamily.Monospace
            )
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Lower row: Quick Control Icons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Flash Mode
            IconButton(
                onClick = onToggleFlash,
                modifier = Modifier
                    .size(38.dp)
                    .testTag("flash_toggle_button")
            ) {
                Icon(
                    imageVector = when (state.flashMode) {
                        ImageCapture.FLASH_MODE_ON -> Icons.Default.FlashOn
                        ImageCapture.FLASH_MODE_AUTO -> Icons.Default.FlashAuto
                        else -> Icons.Default.FlashOff
                    },
                    contentDescription = "Flash mode",
                    tint = if (state.flashMode != ImageCapture.FLASH_MODE_OFF) DslrAmber else TitaniumSilver,
                    modifier = Modifier.size(20.dp)
                )
            }

            // Shutter Timer
            IconButton(
                onClick = onCycleTimer,
                modifier = Modifier
                    .size(38.dp)
                    .testTag("timer_button")
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.Timer,
                        contentDescription = "Shutter timer",
                        tint = if (state.timerSeconds > 0) DslrAmber else TitaniumSilver,
                        modifier = Modifier.size(20.dp)
                    )
                    if (state.timerSeconds > 0) {
                        Text(
                            text = "${state.timerSeconds}",
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            color = DslrAmber,
                            modifier = Modifier.padding(top = 10.dp)
                        )
                    }
                }
            }

            // Grid selector
            IconButton(
                onClick = onCycleGrid,
                modifier = Modifier
                    .size(38.dp)
                    .testTag("grid_toggle_button")
            ) {
                Icon(
                    imageVector = Icons.Default.GridOn,
                    contentDescription = "Framing Grid",
                    tint = if (state.showGrid) DslrCyan else TitaniumSilver,
                    modifier = Modifier.size(20.dp)
                )
            }

            // Horizon Level Toggle
            Box(
                modifier = Modifier
                    .clip(CircleShape)
                    .clickable { onToggleLevel() }
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (state.showHorizonLevel) "LVL" else "--",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (state.showHorizonLevel) DslrGreen else TitaniumSilver,
                    fontFamily = FontFamily.Monospace
                )
            }

            // Hardware Inspector
            IconButton(
                onClick = onOpenInspector,
                modifier = Modifier
                    .size(38.dp)
                    .testTag("hardware_inspector_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Memory,
                    contentDescription = "Device Hardware Profiler",
                    tint = TitaniumSilver,
                    modifier = Modifier.size(20.dp)
                )
            }

            // AI Photography Assistant
            IconButton(
                onClick = onOpenAiAssistant,
                modifier = Modifier
                    .size(38.dp)
                    .testTag("ai_assistant_button")
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = "AI Photography Assistant",
                    tint = DslrAmber,
                    modifier = Modifier.size(20.dp)
                )
            }

            // Settings
            IconButton(
                onClick = onOpenSettings,
                modifier = Modifier
                    .size(38.dp)
                    .testTag("settings_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = "Settings",
                    tint = TitaniumSilver,
                    modifier = Modifier.size(20.dp)
                )
            }

            // About Brand
            IconButton(
                onClick = onOpenAbout,
                modifier = Modifier
                    .size(38.dp)
                    .testTag("about_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = "About Alternative DSLR",
                    tint = TitaniumSilver,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
private fun TelemetryItem(label: String, value: String, isManual: Boolean) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = label,
            fontSize = 9.sp,
            color = if (isManual) DslrAmber else TitaniumSilver,
            fontWeight = FontWeight.Medium
        )
        Text(
            text = value,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = if (isManual) DslrAmber else TitaniumBright,
            fontFamily = FontFamily.Monospace
        )
    }
}
