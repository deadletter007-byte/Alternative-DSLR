package com.example.ui.screens

import android.graphics.Bitmap
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.MainViewModel
import com.example.ai.ChatMessage
import com.example.ai.MessageSender
import com.example.ai.MessageStatus
import com.example.camera.ActiveScreen
import com.example.camera.CameraUiState
import com.example.settings.AiProvider
import com.example.settings.SettingsRepository
import com.example.ui.theme.DslrAmber
import com.example.ui.theme.DslrCyan
import com.example.ui.theme.DslrGold
import com.example.ui.theme.DslrRed
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.TitaniumBright
import com.example.ui.theme.TitaniumDark
import com.example.ui.theme.TitaniumMid
import com.example.ui.theme.TitaniumSilver
import kotlinx.coroutines.launch

@Composable
fun AiAssistantScreen(
    viewModel: MainViewModel,
    state: CameraUiState,
    onNavigateBack: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val repo = viewModel.aiAssistantRepo
    val settingsRepo = remember { SettingsRepository(context) }

    val messages by repo.messages.collectAsStateWithLifecycle()
    val isGenerating by repo.isGenerating.collectAsStateWithLifecycle()

    var inputText by remember { mutableStateOf("") }
    var selectedProvider by remember { mutableStateOf(settingsRepo.aiProvider) }
    var attachedBitmap by remember { mutableStateOf<Bitmap?>(null) }

    val listState = rememberLazyListState()

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    val hasGeminiKey = repo.getGeminiApiKey().isNotBlank()
    val hasOpenAiKey = repo.getOpenAiApiKey().isNotBlank()

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBlack),
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(ObsidianBlack)
                    .padding(top = 16.dp, bottom = 8.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = onNavigateBack,
                            modifier = Modifier.testTag("ai_back_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = TitaniumBright
                            )
                        }
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "AI Photography Studio",
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TitaniumBright
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = null,
                                    tint = DslrAmber,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            Text(
                                text = "Alternative DSLR Intelligence",
                                fontSize = 11.sp,
                                color = TitaniumSilver
                            )
                        }
                    }

                    Row {
                        IconButton(
                            onClick = { repo.clearHistory() },
                            modifier = Modifier.testTag("clear_chat_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.DeleteSweep,
                                contentDescription = "Clear Chat",
                                tint = TitaniumSilver
                            )
                        }
                        IconButton(
                            onClick = onOpenSettings,
                            modifier = Modifier.testTag("ai_settings_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "Settings",
                                tint = TitaniumSilver
                            )
                        }
                    }
                }

                // AI Provider Selector Chips
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AiProvider.values().forEach { provider ->
                        val isSelected = provider == selectedProvider
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    if (isSelected) {
                                        when (provider) {
                                            AiProvider.GEMINI -> DslrCyan
                                            AiProvider.CHATGPT -> DslrAmber
                                            AiProvider.ON_DEVICE -> DslrGold
                                        }
                                    } else TitaniumDark
                                )
                                .clickable {
                                    selectedProvider = provider
                                    settingsRepo.aiProvider = provider
                                }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                                .testTag("provider_chip_${provider.name.lowercase()}"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = provider.label,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) ObsidianBlack else TitaniumSilver,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }

                // Configuration Diagnostic Banner
                when (selectedProvider) {
                    AiProvider.GEMINI -> {
                        if (!hasGeminiKey) {
                            ConfigNoticeCard(
                                message = "Gemini API key unconfigured. Tap to configure in Settings.",
                                onClick = onOpenSettings
                            )
                        }
                    }
                    AiProvider.CHATGPT -> {
                        if (!hasOpenAiKey) {
                            ConfigNoticeCard(
                                message = "OpenAI API key unconfigured. Tap to configure in Settings.",
                                onClick = onOpenSettings
                            )
                        }
                    }
                    AiProvider.ON_DEVICE -> {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 4.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(TitaniumDark.copy(alpha = 0.5f))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "🔒 100% Offline Mode: All queries analyzed locally. Maximum privacy.",
                                fontSize = 10.sp,
                                color = DslrGold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(ObsidianBlack)
        ) {
            // Quick Photography Prompt Chips
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val promptSuggestions = listOf(
                    "Critique composition & lighting",
                    "Settings for 200MP sharp capture",
                    "Optical vs Digital zoom difference",
                    "Low light golden hour ISO recommendation",
                    "DSLR Portrait bokeh aperture guide"
                )
                items(promptSuggestions) { prompt ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .border(1.dp, TitaniumDark, RoundedCornerShape(16.dp))
                            .background(TitaniumDark.copy(alpha = 0.4f))
                            .clickable {
                                scope.launch {
                                    repo.sendMessage(prompt, attachedBitmap)
                                    attachedBitmap = null
                                }
                            }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = prompt,
                            fontSize = 11.sp,
                            color = TitaniumBright
                        )
                    }
                }
            }

            // Message Stream
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(messages, key = { it.id }) { message ->
                    ChatMessageBubble(message = message)
                }

                if (isGenerating) {
                    item {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(8.dp)
                        ) {
                            CircularProgressIndicator(
                                color = DslrAmber,
                                strokeWidth = 2.dp,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Analyzing photography parameters...",
                                fontSize = 12.sp,
                                color = TitaniumSilver,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }

            // Attached Photo Preview
            if (attachedBitmap != null) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(TitaniumDark)
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(
                            bitmap = attachedBitmap!!.asImageBitmap(),
                            contentDescription = "Attached photo",
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(6.dp))
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Photo attached for critique",
                            fontSize = 12.sp,
                            color = TitaniumBright
                        )
                    }
                    IconButton(
                        onClick = { attachedBitmap = null },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Remove attached photo",
                            tint = TitaniumSilver,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            // Bottom Input Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(ObsidianBlack)
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Attach latest captured photo button
                IconButton(
                    onClick = {
                        val lastItem = state.lastCapturedItem
                        if (lastItem != null) {
                            scope.launch {
                                val bmp = com.example.gallery.GalleryRepository.loadBitmap(context, lastItem.uri)
                                attachedBitmap = bmp
                            }
                        }
                    },
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(TitaniumDark)
                        .testTag("attach_photo_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Image,
                        contentDescription = "Attach Photo",
                        tint = if (attachedBitmap != null) DslrAmber else TitaniumSilver,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                OutlinedTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    placeholder = {
                        Text(
                            text = "Ask about lighting, ISO, 200MP...",
                            fontSize = 12.sp,
                            color = TitaniumMid
                        )
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = DslrAmber,
                        unfocusedBorderColor = TitaniumDark,
                        focusedTextColor = TitaniumBright,
                        unfocusedTextColor = TitaniumBright,
                        cursorColor = DslrAmber
                    ),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp)
                        .testTag("ai_input_field")
                )

                Spacer(modifier = Modifier.width(8.dp))

                IconButton(
                    onClick = {
                        val text = inputText
                        if (text.isNotBlank() || attachedBitmap != null) {
                            inputText = ""
                            val bmp = attachedBitmap
                            attachedBitmap = null
                            scope.launch {
                                repo.sendMessage(text, bmp)
                            }
                        }
                    },
                    enabled = !isGenerating && (inputText.isNotBlank() || attachedBitmap != null),
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(if (inputText.isNotBlank() || attachedBitmap != null) DslrAmber else TitaniumDark)
                        .testTag("send_ai_message_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Send,
                        contentDescription = "Send Message",
                        tint = if (inputText.isNotBlank() || attachedBitmap != null) ObsidianBlack else TitaniumMid,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun ConfigNoticeCard(message: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(DslrRed.copy(alpha = 0.20f))
            .border(1.dp, DslrRed.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = message,
            fontSize = 11.sp,
            color = TitaniumBright,
            modifier = Modifier.weight(1f)
        )
        Icon(
            imageVector = Icons.Default.Settings,
            contentDescription = null,
            tint = DslrAmber,
            modifier = Modifier.size(16.dp)
        )
    }
}

@Composable
private fun ChatMessageBubble(message: ChatMessage) {
    val isUser = message.sender == MessageSender.USER

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        if (!isUser && message.providerBadge != null) {
            Text(
                text = message.providerBadge,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                color = DslrAmber,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(start = 6.dp, bottom = 2.dp)
            )
        }

        Box(
            modifier = Modifier
                .clip(
                    RoundedCornerShape(
                        topStart = 14.dp,
                        topEnd = 14.dp,
                        bottomStart = if (isUser) 14.dp else 2.dp,
                        bottomEnd = if (isUser) 2.dp else 14.dp
                    )
                )
                .background(if (isUser) TitaniumDark else ObsidianBlack.copy(alpha = 0.95f))
                .border(
                    width = 1.dp,
                    color = if (isUser) DslrAmber.copy(alpha = 0.4f) else TitaniumDark,
                    shape = RoundedCornerShape(
                        topStart = 14.dp,
                        topEnd = 14.dp,
                        bottomStart = if (isUser) 14.dp else 2.dp,
                        bottomEnd = if (isUser) 2.dp else 14.dp
                    )
                )
                .padding(12.dp)
        ) {
            Column {
                if (message.attachedBitmap != null) {
                    Image(
                        bitmap = message.attachedBitmap.asImageBitmap(),
                        contentDescription = "Attached photo",
                        modifier = Modifier
                            .size(120.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .padding(bottom = 6.dp)
                    )
                }

                Text(
                    text = message.text,
                    fontSize = 13.sp,
                    color = if (message.status == MessageStatus.ERROR) DslrRed else TitaniumBright,
                    lineHeight = 18.sp
                )
            }
        }
    }
}
