package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.DslrAmber
import com.example.ui.theme.DslrCyan
import com.example.ui.theme.DslrGreen
import com.example.ui.theme.MetallicCarbon
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.TitaniumBright
import com.example.ui.theme.TitaniumDark
import com.example.ui.theme.TitaniumMid
import com.example.ui.theme.TitaniumSilver

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutScreen(
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onNavigateBack() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "About Alternative DSLR",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = TitaniumBright
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("about_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = TitaniumBright
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = ObsidianBlack
                )
            )
        },
        containerColor = ObsidianBlack,
        modifier = modifier.fillMaxSize()
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // 3D Aperture Logo
            Box(
                modifier = Modifier
                    .size(96.dp)
                    .clip(CircleShape)
                    .border(2.dp, TitaniumMid, CircleShape)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.dslr_lens_icon),
                    contentDescription = "Alternative DSLR Logo",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "Alternative DSLR",
                fontSize = 22.sp,
                fontWeight = FontWeight.ExtraBold,
                color = TitaniumBright,
                letterSpacing = 0.5.sp
            )

            Text(
                text = "Computational Photography Engine • v1.0",
                fontSize = 12.sp,
                color = DslrAmber,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(top = 2.dp)
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Natural Philosophy Card
            Card(
                colors = CardDefaults.cardColors(containerColor = MetallicCarbon),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Verified,
                            contentDescription = null,
                            tint = DslrGreen,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "NATURAL IMAGE PHILOSOPHY",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = DslrGreen,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "\"Enhance reality, don't replace reality.\"",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TitaniumBright,
                        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Alternative DSLR preserves natural facial identity, authentic skin texture, facial hair, skin pores, clothing texture, and realistic highlights. The application rejects automatic beauty filters and synthetic plastic skin smoothing.",
                        fontSize = 12.sp,
                        color = TitaniumSilver,
                        lineHeight = 18.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 10 Engines Architecture Card
            Card(
                colors = CardDefaults.cardColors(containerColor = MetallicCarbon),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "10 MODULAR COMPUTATIONAL ENGINES",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = DslrCyan,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    val engines = listOf(
                        "1. Capture Engine",
                        "2. Camera Metadata Engine",
                        "3. Scene Analysis Engine",
                        "4. HDR Processing Engine",
                        "5. Noise Reduction Engine",
                        "6. Super Resolution Engine (Up to 200MP)",
                        "7. Detail Preservation Engine",
                        "8. Portrait & Depth Engine (f/1.2 - f/8)",
                        "9. Natural Color Engine (Kelvin Curves)",
                        "10. Final Optimization Engine (EXIF)"
                    )

                    engines.forEach { eng ->
                        Text(
                            text = "• $eng",
                            fontSize = 11.sp,
                            color = TitaniumSilver,
                            modifier = Modifier.padding(vertical = 2.dp),
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
