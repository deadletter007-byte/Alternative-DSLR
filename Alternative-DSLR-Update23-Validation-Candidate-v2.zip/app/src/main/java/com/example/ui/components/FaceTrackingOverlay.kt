package com.example.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.camera.FaceFocusState
import com.example.camera.FaceTrackingState
import com.example.camera.TrackedFace
import com.example.ui.theme.DslrAmber
import com.example.ui.theme.DslrCyan
import com.example.ui.theme.DslrGreen
import com.example.ui.theme.DslrRed
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.TitaniumBright
import com.example.ui.theme.TitaniumSilver

@Composable
fun FaceTrackingOverlay(
    trackingState: FaceTrackingState,
    onSelectFace: (normX: Float, normY: Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "facePulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.75f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(800),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    // This layer is deliberately non-interactive. A full-screen pointerInput/tap
    // detector here steals MotionEvents from PreviewView and breaks native pinch zoom
    // and CameraX tap-to-focus. PreviewView owns camera gestures.
    Box(modifier = modifier.fillMaxSize()) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val canvasW = size.width
            val canvasH = size.height

            trackingState.faces.forEach { face ->
                val left = face.bounds.left * canvasW
                val top = face.bounds.top * canvasH
                val right = face.bounds.right * canvasW
                val bottom = face.bounds.bottom * canvasH
                val width = right - left
                val height = bottom - top

                if (width > 20 && height > 20) {
                    val color = when (face.focusState) {
                        FaceFocusState.LOCKED -> DslrGreen
                        FaceFocusState.SELECTED -> DslrCyan
                        FaceFocusState.EYE_DETECTED -> DslrCyan
                        FaceFocusState.AF_ACTIVE -> DslrAmber.copy(alpha = pulseAlpha)
                        FaceFocusState.LOST -> DslrAmber.copy(alpha = 0.35f)
                        FaceFocusState.DETECTED -> TitaniumSilver.copy(alpha = 0.85f)
                    }

                    val strokePx = if (face.isSelected) 2.5.dp.toPx() else 1.8.dp.toPx()
                    val cornerLen = (minOf(width, height) * 0.22f).coerceIn(12f, 32f)

                    // Draw DSLR Corner Brackets: Top-Left
                    drawLine(color, Offset(left, top), Offset(left + cornerLen, top), strokePx)
                    drawLine(color, Offset(left, top), Offset(left, top + cornerLen), strokePx)

                    // Top-Right
                    drawLine(color, Offset(right, top), Offset(right - cornerLen, top), strokePx)
                    drawLine(color, Offset(right, top), Offset(right, top + cornerLen), strokePx)

                    // Bottom-Left
                    drawLine(color, Offset(left, bottom), Offset(left + cornerLen, bottom), strokePx)
                    drawLine(color, Offset(left, bottom), Offset(left, bottom - cornerLen), strokePx)

                    // Bottom-Right
                    drawLine(color, Offset(right, bottom), Offset(right - cornerLen, bottom), strokePx)
                    drawLine(color, Offset(right, bottom), Offset(right, bottom - cornerLen), strokePx)

                    // Center AF crosshair if locked or selected
                    if (face.isSelected) {
                        val cx = left + width / 2f
                        val cy = top + height / 2f
                        val crossSize = 6.dp.toPx()
                        drawLine(color, Offset(cx - crossSize, cy), Offset(cx + crossSize, cy), 1.5.dp.toPx())
                        drawLine(color, Offset(cx, cy - crossSize), Offset(cx, cy + crossSize), 1.5.dp.toPx())
                    }

                    // Eye AF Reticles
                    face.leftEye?.let { eye ->
                        val ex = eye.x * canvasW
                        val ey = eye.y * canvasH
                        val eyeBox = 16.dp.toPx()
                        drawRect(DslrGreen, Offset(ex - eyeBox / 2f, ey - eyeBox / 2f), Size(eyeBox, eyeBox), style = Stroke(width = 1.6.dp.toPx()))
                        drawLine(DslrGreen, Offset(ex - 3.dp.toPx(), ey), Offset(ex + 3.dp.toPx(), ey), 1.dp.toPx())
                        drawLine(DslrGreen, Offset(ex, ey - 3.dp.toPx()), Offset(ex, ey + 3.dp.toPx()), 1.dp.toPx())
                    }
                    face.rightEye?.let { eye ->
                        val ex = eye.x * canvasW
                        val ey = eye.y * canvasH
                        val eyeBox = 16.dp.toPx()
                        drawRect(DslrGreen, Offset(ex - eyeBox / 2f, ey - eyeBox / 2f), Size(eyeBox, eyeBox), style = Stroke(width = 1.6.dp.toPx()))
                        drawLine(DslrGreen, Offset(ex - 3.dp.toPx(), ey), Offset(ex + 3.dp.toPx(), ey), 1.dp.toPx())
                        drawLine(DslrGreen, Offset(ex, ey - 3.dp.toPx()), Offset(ex, ey + 3.dp.toPx()), 1.dp.toPx())
                    }
                }
            }
        }

        // Tracking Status Badge (Top-Center Viewfinder indicator)
        if (trackingState.faces.isNotEmpty()) {
            val primaryFace = trackingState.faces.firstOrNull { it.isSelected } ?: trackingState.faces.firstOrNull()
            if (primaryFace != null) {
                val badgeColor = when (primaryFace.focusState) {
                    FaceFocusState.LOCKED -> DslrGreen
                    FaceFocusState.EYE_DETECTED -> DslrCyan
                    FaceFocusState.SELECTED -> DslrCyan
                    FaceFocusState.LOST -> DslrAmber
                    else -> TitaniumSilver
                }

                Box(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 118.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "● ${trackingState.trackingStatusText}",
                        color = badgeColor,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}
