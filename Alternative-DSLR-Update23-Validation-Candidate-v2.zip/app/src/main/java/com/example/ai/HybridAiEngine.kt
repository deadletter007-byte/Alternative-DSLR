package com.example.ai

import android.content.Context
import android.graphics.Bitmap
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.util.Log
import com.example.capability.HardwareCapabilities
import com.example.engine.SceneAnalysisResult
import com.example.settings.AiProcessingMode
import com.example.settings.SettingsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class AiDecision(
    val selectedExecutionEngine: ExecutionEngine,
    val explanation: String,
    val requiresConsentPrompt: Boolean = false,
    val sceneInsight: String? = null
)

enum class ExecutionEngine(val label: String) {
    ON_DEVICE("On-device traditional processing (no neural image model)"),
    CLOUD("Cloud scene analysis (not cloud image enhancement)"),
    TRADITIONAL_COMPUTATIONAL("Hardware Computational Pipeline"),
    AI_UPSCALED("Bitmap upscaling requested (no AI super-resolution model)")
}

data class CloudAiCritique(
    val sceneUnderstanding: String,
    val compositionFeedback: String,
    val lightingRecommendation: String,
    val recommendedColorProfile: String
)

object HybridAiEngine {
    private const val TAG = "HybridAiEngine"

    fun decideExecutionPath(
        context: Context,
        mode: AiProcessingMode,
        targetMegapixels: Int,
        capabilities: HardwareCapabilities?
    ): AiDecision {
        val settings = SettingsRepository(context)
        val hasNetwork = isNetworkAvailable(context)

        return when (mode) {
            AiProcessingMode.ON_DEVICE_ONLY -> {
                AiDecision(
                    selectedExecutionEngine = if (targetMegapixels > 24) ExecutionEngine.AI_UPSCALED else ExecutionEngine.ON_DEVICE,
                    explanation = "No neural image-enhancement model is bundled. Traditional local processing will run; no AI image restoration is performed."
                )
            }

            AiProcessingMode.CLOUD_ON_REQUEST -> {
                if (settings.cloudConsentGiven && hasNetwork) {
                    AiDecision(
                        selectedExecutionEngine = ExecutionEngine.CLOUD,
                        explanation = "Cloud text-based scene analysis may be available; this does not edit or enhance the image."
                    )
                } else {
                    AiDecision(
                        selectedExecutionEngine = ExecutionEngine.ON_DEVICE,
                        explanation = if (!hasNetwork) "No internet available — operating in On-Device AI mode."
                        else "Operating locally on device (Cloud AI on request)."
                    )
                }
            }

            AiProcessingMode.HYBRID -> {
                // Hybrid decision: local fast processing + optional cloud deep analysis
                if (hasNetwork && settings.cloudConsentGiven && capabilities?.availableRamMb != null && capabilities.availableRamMb < 1500) {
                    AiDecision(
                        selectedExecutionEngine = ExecutionEngine.CLOUD,
                        explanation = "Hybrid route selected, but cloud processing here is scene analysis only; no image enhancement is uploaded or performed."
                    )
                } else {
                    AiDecision(
                        selectedExecutionEngine = if (targetMegapixels > 24) ExecutionEngine.AI_UPSCALED else ExecutionEngine.ON_DEVICE,
                        explanation = "Local traditional processing selected. No neural image-enhancement or super-resolution model is bundled in this build."
                    )
                }
            }
        }
    }

    suspend fun requestSceneUnderstanding(
        context: Context,
        sampleBitmap: Bitmap,
        sceneAnalysis: SceneAnalysisResult
    ): CloudAiCritique = withContext(Dispatchers.IO) {
        val hasNetwork = isNetworkAvailable(context)
        val settings = SettingsRepository(context)

        if (!hasNetwork || !settings.cloudConsentGiven) {
            // Local intelligent assessment
            return@withContext CloudAiCritique(
                sceneUnderstanding = "On-Device Scene Analysis: ${sceneAnalysis.detectedScene.label} (Luminance: ${String.format("%.2f", sceneAnalysis.luminance)}, Temp: ${sceneAnalysis.colorTemperatureKelvin}K)",
                compositionFeedback = if (sceneAnalysis.suggestsHdr) "High dynamic contrast detected. Multi-exposure tone curve engaged." else "Balanced natural lighting. Zero beauty distortion engaged.",
                lightingRecommendation = if (sceneAnalysis.suggestsNightMode) "Low-light night mode recommended with multi-frame stabilization." else "Optimal daylight exposure.",
                recommendedColorProfile = if (sceneAnalysis.colorTemperatureKelvin > 6000) "Golden Warm" else "Natural"
            )
        }

        val repo = AiAssistantRepository(context)
        val geminiKey = repo.getGeminiApiKey()
        val openAiKey = repo.getOpenAiApiKey()

        // When cloud is active and consented, use real Gemini / OpenAI API
        try {
            if (geminiKey.isNotBlank()) {
                val prompt = "Analyze this camera frame: detected scene is ${sceneAnalysis.detectedScene.label}, luminance ${String.format("%.2f", sceneAnalysis.luminance)}, dynamic range ${String.format("%.1f", sceneAnalysis.dynamicRangeEstimate * 100)}%, color temp ${sceneAnalysis.colorTemperatureKelvin}K. Give a concise 4-part assessment: 1) Scene Understanding, 2) Composition Feedback, 3) Lighting Recommendation, 4) Recommended DSLR Color Profile."
                val request = GeminiGenerateContentRequest(
                    contents = listOf(
                        GeminiContent(
                            role = "user",
                            parts = listOf(GeminiPart(text = prompt))
                        )
                    ),
                    generationConfig = GeminiGenerationConfig(temperature = 0.5, maxOutputTokens = 300)
                )
                val response = GeminiClient.api.generateContent(
                    model = settings.geminiModel,
                    apiKey = geminiKey,
                    request = request
                )
                val text = response.body()?.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                if (!text.isNullOrBlank()) {
                    return@withContext CloudAiCritique(
                        sceneUnderstanding = "Gemini Scene Understanding: ${sceneAnalysis.detectedScene.label}",
                        compositionFeedback = text.take(120),
                        lightingRecommendation = if (sceneAnalysis.luminance < 0.25f) "Low-light night stack recommended" else "Natural daylight balanced",
                        recommendedColorProfile = if (sceneAnalysis.colorTemperatureKelvin > 5500) "Golden Warm" else "DSLR Natural"
                    )
                }
            } else if (openAiKey.isNotBlank()) {
                val request = OpenAiChatRequest(
                    model = settings.openAiModel,
                    messages = listOf(
                        OpenAiMessage(role = "system", content = "You are Alternative DSLR's computational scene analyzer. Provide concise 2-sentence photography feedback."),
                        OpenAiMessage(role = "user", content = "Scene is ${sceneAnalysis.detectedScene.label}, luminance ${sceneAnalysis.luminance}. Critique framing and exposure.")
                    ),
                    maxTokens = 150
                )
                val authHeader = if (openAiKey.startsWith("Bearer ")) openAiKey else "Bearer $openAiKey"
                val response = OpenAiClient.api.createChatCompletion(authHeader, request)
                val text = response.body()?.choices?.firstOrNull()?.message?.content
                if (!text.isNullOrBlank()) {
                    return@withContext CloudAiCritique(
                        sceneUnderstanding = "OpenAI Scene Analysis: ${sceneAnalysis.detectedScene.label}",
                        compositionFeedback = text.take(120),
                        lightingRecommendation = if (sceneAnalysis.luminance < 0.25f) "Multi-frame exposure advised" else "Exposure optimal",
                        recommendedColorProfile = "Portrait Natural"
                    )
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Cloud AI request fallback to local analytics", e)
        }

        // Local neural/optical intelligence
        CloudAiCritique(
            sceneUnderstanding = "On-Device Scene Analysis: ${sceneAnalysis.detectedScene.label} (DR: ${String.format("%.1f", sceneAnalysis.dynamicRangeEstimate * 100)}%)",
            compositionFeedback = if (sceneAnalysis.suggestsHdr) "High contrast range detected. Multi-exposure tone curve active." else "Balanced natural illumination.",
            lightingRecommendation = if (sceneAnalysis.luminance < 0.25f) "Multi-frame night stack active." else "Standard daylight balance.",
            recommendedColorProfile = if (sceneAnalysis.colorTemperatureKelvin > 6000) "Golden Warm" else "DSLR Natural"
        )
    }

    private fun isNetworkAvailable(context: Context): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }
}
