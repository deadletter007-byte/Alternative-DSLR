package com.example.ai

import android.content.Context
import android.graphics.Bitmap
import android.util.Base64
import android.util.Log
import com.example.BuildConfig
import com.example.engine.ShotMetadata
import com.example.settings.AiProvider
import com.example.settings.SettingsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.util.UUID

enum class MessageSender {
    USER,
    ASSISTANT,
    SYSTEM
}

enum class MessageStatus {
    SENDING,
    SENT,
    ERROR
}

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val sender: MessageSender,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val status: MessageStatus = MessageStatus.SENT,
    val errorMessage: String? = null,
    val providerBadge: String? = null,
    val attachedBitmap: Bitmap? = null
)

class AiAssistantRepository(private val context: Context) {
    private val TAG = "AiAssistantRepository"
    private val settingsRepo = SettingsRepository(context)

    private val _messages = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage(
                sender = MessageSender.ASSISTANT,
                text = "Welcome to Alternative DSLR AI Photography Assistant. I can critique your composition, calculate manual exposure settings, recommend color science profiles, or explain computational optics. Ask me anything or attach a photo from your gallery.",
                providerBadge = "Alternative DSLR Intelligence"
            )
        )
    )
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    fun clearHistory() {
        _messages.value = listOf(
            ChatMessage(
                sender = MessageSender.ASSISTANT,
                text = "Conversation cleared. Ready for your photography questions.",
                providerBadge = "System"
            )
        )
    }

    suspend fun sendMessage(userText: String, attachedBitmap: Bitmap? = null) = withContext(Dispatchers.IO) {
        if (userText.isBlank() && attachedBitmap == null) return@withContext

        val userMessage = ChatMessage(
            sender = MessageSender.USER,
            text = userText,
            attachedBitmap = attachedBitmap
        )
        _messages.update { it + userMessage }
        _isGenerating.value = true

        val provider = settingsRepo.aiProvider

        try {
            when (provider) {
                AiProvider.GEMINI -> {
                    processGeminiMessage(userText, attachedBitmap)
                }

                AiProvider.CHATGPT -> {
                    processChatGptMessage(userText, attachedBitmap)
                }

                AiProvider.ON_DEVICE -> {
                    processOnDeviceLocalMessage(userText, attachedBitmap)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "AI generation failed", e)
            val errorMsg = ChatMessage(
                sender = MessageSender.ASSISTANT,
                text = "Failed to communicate with ${provider.label}: ${e.localizedMessage ?: "Unknown error"}. Check network connection or API key configuration in Settings.",
                status = MessageStatus.ERROR,
                errorMessage = e.localizedMessage,
                providerBadge = provider.label
            )
            _messages.update { it + errorMsg }
        } finally {
            _isGenerating.value = false
        }
    }

    private suspend fun processGeminiMessage(userText: String, attachedBitmap: Bitmap?) {
        val apiKey = getGeminiApiKey()
        if (apiKey.isBlank()) {
            val configNotice = ChatMessage(
                sender = MessageSender.ASSISTANT,
                text = "Gemini API key is not configured.\n\nTo use Gemini AI:\n1. Open Settings -> AI Assistant Configuration.\n2. Enter your Google AI Studio Gemini API Key (or set GEMINI_API_KEY in .env/Secrets).\n3. You can also switch to OpenAI ChatGPT or On-Device Local AI anytime.",
                status = MessageStatus.ERROR,
                providerBadge = "Gemini Configuration Required"
            )
            _messages.update { it + configNotice }
            return
        }

        val parts = mutableListOf<GeminiPart>()
        parts.add(GeminiPart(text = userText))

        if (attachedBitmap != null) {
            val base64Data = bitmapToBase64(attachedBitmap)
            parts.add(GeminiPart(inlineData = GeminiBlob(mimeType = "image/jpeg", data = base64Data)))
        }

        // Build conversation history (up to last 6 messages)
        val contents = mutableListOf<GeminiContent>()
        _messages.value.dropLast(1).takeLast(6).filter { it.status == MessageStatus.SENT }.forEach { msg ->
            val role = if (msg.sender == MessageSender.USER) "user" else "model"
            contents.add(GeminiContent(role = role, parts = listOf(GeminiPart(text = msg.text))))
        }
        contents.add(GeminiContent(role = "user", parts = parts))

        val systemInstruction = GeminiContent(
            role = "system",
            parts = listOf(
                GeminiPart(
                    text = "You are Alternative DSLR's professional photography expert and computational imaging architect. Provide insightful, realistic, and mathematically sound photography advice. Emphasize manual camera techniques, realistic lighting, non-plastic skin texture preservation, color grading, and optical physics. Keep answers direct, structured, and practical."
                )
            )
        )

        val request = GeminiGenerateContentRequest(
            contents = contents,
            systemInstruction = systemInstruction,
            generationConfig = GeminiGenerationConfig(temperature = 0.7, maxOutputTokens = 1000)
        )

        val modelName = settingsRepo.geminiModel
        val response = GeminiClient.api.generateContent(
            model = modelName,
            apiKey = apiKey,
            request = request
        )

        if (response.isSuccessful && response.body() != null) {
            val body = response.body()!!
            val replyText = body.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                ?: "Received empty response from Gemini."
            val reply = ChatMessage(
                sender = MessageSender.ASSISTANT,
                text = replyText,
                providerBadge = "Google $modelName"
            )
            _messages.update { it + reply }
        } else {
            val errBody = response.errorBody()?.string() ?: response.message()
            val reply = ChatMessage(
                sender = MessageSender.ASSISTANT,
                text = "Gemini Error (${response.code()}): $errBody\n\nPlease verify that your Gemini API Key is valid and has access to $modelName.",
                status = MessageStatus.ERROR,
                providerBadge = "Google Gemini Error"
            )
            _messages.update { it + reply }
        }
    }

    private suspend fun processChatGptMessage(userText: String, attachedBitmap: Bitmap?) {
        val apiKey = getOpenAiApiKey()
        if (apiKey.isBlank()) {
            val configNotice = ChatMessage(
                sender = MessageSender.ASSISTANT,
                text = "OpenAI API key is not configured.\n\nTo use ChatGPT:\n1. Open Settings -> AI Assistant Configuration.\n2. Enter your OpenAI API Key (starts with sk-...) or configure OPENAI_API_KEY in .env/Secrets.\n3. You can also switch to Google Gemini or On-Device Local AI.",
                status = MessageStatus.ERROR,
                providerBadge = "OpenAI Configuration Required"
            )
            _messages.update { it + configNotice }
            return
        }

        val messagesList = mutableListOf<OpenAiMessage>()
        messagesList.add(
            OpenAiMessage(
                role = "system",
                content = "You are the computational photography intelligence assistant inside Alternative DSLR. Give expert advice on DSLR shutter speed, ISO balance, optical focal lengths, color science, and natural detail preservation. Be concise, actionable, and mathematically accurate."
            )
        )

        // Include recent history
        _messages.value.dropLast(1).takeLast(6).filter { it.status == MessageStatus.SENT }.forEach { msg ->
            val role = if (msg.sender == MessageSender.USER) "user" else "assistant"
            messagesList.add(OpenAiMessage(role = role, content = msg.text))
        }

        messagesList.add(OpenAiMessage(role = "user", content = userText))

        val modelName = settingsRepo.openAiModel
        val request = OpenAiChatRequest(
            model = modelName,
            messages = messagesList,
            temperature = 0.7,
            maxTokens = 800
        )

        val authHeader = if (apiKey.startsWith("Bearer ")) apiKey else "Bearer $apiKey"
        val response = OpenAiClient.api.createChatCompletion(authHeader, request)

        if (response.isSuccessful && response.body() != null) {
            val body = response.body()!!
            val replyText = body.choices.firstOrNull()?.message?.content
                ?: "Received empty response from OpenAI."
            val reply = ChatMessage(
                sender = MessageSender.ASSISTANT,
                text = replyText,
                providerBadge = "OpenAI $modelName"
            )
            _messages.update { it + reply }
        } else {
            val errBody = response.errorBody()?.string() ?: response.message()
            val reply = ChatMessage(
                sender = MessageSender.ASSISTANT,
                text = "OpenAI Error (${response.code()}): $errBody\n\nPlease check your OpenAI API key and account quota.",
                status = MessageStatus.ERROR,
                providerBadge = "OpenAI Error"
            )
            _messages.update { it + reply }
        }
    }

    private fun processOnDeviceLocalMessage(userText: String, attachedBitmap: Bitmap?) {
        val lower = userText.lowercase()
        val replyText = when {
            lower.contains("200mp") || lower.contains("super resolution") || lower.contains("megapixels") -> {
                "200MP output status: this project currently performs conventional tiled bitmap interpolation, not neural AI super-resolution. It increases pixel dimensions but cannot recover details that were not captured. For genuine AI reconstruction, a compatible trained model and Android inference runtime must be integrated. Use a steady grip to reduce source blur."
            }

            lower.contains("iso") || lower.contains("shutter") || lower.contains("exposure") -> {
                "DSLR Exposure Calculation Rule:\n\n• Base ISO: Keep ISO between 50-200 for maximum dynamic range and zero chroma noise.\n• Handheld Rule: Minimum shutter speed = 1 / (focal length × crop factor). For 50mm, aim for 1/100s or faster.\n• Low Light: Engage Night Mode for bracketed multi-frame accumulation rather than spiking analog gain above ISO 3200."
            }

            lower.contains("portrait") || lower.contains("bokeh") || lower.contains("aperture") -> {
                "Computational Portrait Depth Engine:\n\n• Lenses: 85mm f/1.4 produces the classic flattering perspective compression without facial distortion.\n• Bokeh Roll-off: Physical lenses do not blur uniformly; Alternative DSLR simulates depth gradient falloff with hair-edge protection.\n• Aperture: For group shots, step down to f/2.8 or f/4 to keep all eyes in focus."
            }

            lower.contains("color") || lower.contains("profile") -> {
                "Alternative DSLR Color Science:\n\n• Natural: Uncompromised true-to-life organic tones.\n• Portrait Natural: Calibrated melanin preservation with soft shadow rolloff.\n• Cinematic Classic: Gentle analog highlight rolloff and subtle shadow warmth.\n• DSLR Natural: Classic 35mm full-frame midtone punch."
            }

            else -> {
                "Offline photography help: this response is generated from built-in rules, not a local generative AI model. For open-ended AI conversation, configure Gemini or OpenAI in Settings."
            }
        }

        val reply = ChatMessage(
            sender = MessageSender.ASSISTANT,
            text = replyText,
            providerBadge = "Offline rule-based photography tips (not generative AI)"
        )
        _messages.update { it + reply }
    }

    suspend fun critiquePhoto(bitmap: Bitmap, metadata: ShotMetadata?): String = withContext(Dispatchers.IO) {
        val prompt = buildString {
            append("Please provide a concise, professional DSLR critique of this photo:\n")
            if (metadata != null) {
                append("• Shot Settings: ISO ${metadata.iso}, Shutter ${metadata.shutterSpeed}, Aperture f/${metadata.aperture}, Focal Length ${metadata.focalLengthMm}mm, Profile: ${metadata.processingProfileName}\n")
            }
            append("Evaluate: 1) Composition & Framing, 2) Exposure & Dynamic Range, 3) Lighting Quality, 4) Recommended Color Science or settings adjustments.")
        }
        sendMessage(prompt, bitmap)
        "Critique requested. See AI Photography Studio conversation."
    }

    fun getOpenAiApiKey(): String {
        val userKey = settingsRepo.openAiApiKey
        if (userKey.isNotBlank()) return userKey
        return try {
            val field = BuildConfig::class.java.getField("OPENAI_API_KEY")
            (field.get(null) as? String) ?: ""
        } catch (e: Exception) {
            ""
        }
    }

    fun getGeminiApiKey(): String {
        val userKey = settingsRepo.geminiApiKey
        if (userKey.isNotBlank()) return userKey
        return try {
            val field = BuildConfig::class.java.getField("GEMINI_API_KEY")
            (field.get(null) as? String) ?: ""
        } catch (e: Exception) {
            ""
        }
    }

    private fun bitmapToBase64(bitmap: Bitmap): String {
        val stream = ByteArrayOutputStream()
        // Resize thumbnail to 512px max for fast network transfer
        val maxDim = 512
        val scale = if (bitmap.width > maxDim || bitmap.height > maxDim) {
            maxDim.toFloat() / maxOf(bitmap.width, bitmap.height)
        } else 1.0f

        val scaled = if (scale < 1.0f) {
            Bitmap.createScaledBitmap(bitmap, (bitmap.width * scale).toInt(), (bitmap.height * scale).toInt(), true)
        } else bitmap

        scaled.compress(Bitmap.CompressFormat.JPEG, 85, stream)
        val byteArray = stream.toByteArray()
        return Base64.encodeToString(byteArray, Base64.NO_WRAP)
    }
}
