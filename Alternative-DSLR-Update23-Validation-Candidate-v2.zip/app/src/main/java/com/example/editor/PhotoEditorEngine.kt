package com.example.editor

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import com.example.camera.VirtualAperture
import com.example.camera.VirtualLens
import com.example.engine.ColorScience
import com.example.engine.DetailPreservationEngine
import com.example.engine.PortraitDepthEngine
import com.example.settings.ColorScienceProfile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class EditorAdjustments(
    val exposure: Float = 0f,       // -100 to +100
    val contrast: Float = 0f,       // -100 to +100
    val highlights: Float = 0f,     // -100 to +100
    val shadows: Float = 0f,        // -100 to +100
    val saturation: Float = 0f,     // -100 to +100
    val temperature: Float = 0f,    // -100 to +100 (Cool to Warm)
    val tint: Float = 0f,           // -100 to +100 (Green to Magenta)
    val texture: Float = 0f,        // 0 to +100
    val rotationDegrees: Int = 0,   // 0, 90, 180, 270
    val selectedAperture: VirtualAperture? = null,
    val selectedColorProfile: ColorScienceProfile = ColorScienceProfile.NATURAL
)

object PhotoEditorEngine {
    private const val TAG = "PhotoEditorEngine"

    suspend fun applyAdjustments(
        baseBitmap: Bitmap,
        adjustments: EditorAdjustments
    ): Bitmap = withContext(Dispatchers.Default) {
        var result = baseBitmap

        // 1. Rotation if applied
        if (adjustments.rotationDegrees % 360 != 0) {
            val rotMatrix = Matrix().apply { postRotate(adjustments.rotationDegrees.toFloat()) }
            result = Bitmap.createBitmap(result, 0, 0, result.width, result.height, rotMatrix, true)
        }

        // 2. Color, Exposure, Contrast, Temperature, Tint Matrix
        val adjusted = Bitmap.createBitmap(result.width, result.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(adjusted)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

        // Exposure & Contrast
        val expFactor = 1.0f + (adjustments.exposure / 100f) * 0.6f
        val expOffset = (adjustments.exposure / 100f) * 35f

        val contFactor = 1.0f + (adjustments.contrast / 100f) * 0.5f
        val contOffset = (-0.5f * contFactor + 0.5f) * 255f

        // Temperature (Warm/Cool) & Tint
        val tempR = 1.0f + (adjustments.temperature / 100f) * 0.25f
        val tempB = 1.0f - (adjustments.temperature / 100f) * 0.25f
        val tintG = 1.0f - (adjustments.tint / 100f) * 0.20f
        val tintR = 1.0f + (adjustments.tint / 100f) * 0.15f

        val colorMatrix = ColorMatrix(floatArrayOf(
            expFactor * contFactor * tempR * tintR, 0f, 0f, 0f, expOffset + contOffset,
            0f, expFactor * contFactor * tintG, 0f, 0f, expOffset + contOffset,
            0f, 0f, expFactor * contFactor * tempB, 0f, expOffset + contOffset,
            0f, 0f, 0f, 1.0f, 0f
        ))

        // Saturation
        val satFactor = 1.0f + (adjustments.saturation / 100f) * 0.8f
        val satMatrix = ColorMatrix().apply { setSaturation(satFactor.coerceAtLeast(0f)) }
        colorMatrix.postConcat(satMatrix)

        paint.colorFilter = ColorMatrixColorFilter(colorMatrix)
        canvas.drawBitmap(result, 0f, 0f, paint)

        // 3. Color Science Profile
        var finalBitmap = ColorScience.applyColorProfile(adjusted, adjustments.selectedColorProfile)
        adjusted.recycle()

        // 4. Texture / Microdetail preservation
        if (adjustments.texture > 0) {
            val strength = 1.0f + (adjustments.texture / 100f) * 0.35f
            finalBitmap = DetailPreservationEngine.enhanceTexture(finalBitmap, strength)
        }

        // 5. Portrait Aperture Bokeh simulation
        if (adjustments.selectedAperture != null && adjustments.selectedAperture != VirtualAperture.F8_0) {
            finalBitmap = PortraitDepthEngine.renderPortraitBokeh(finalBitmap, adjustments.selectedAperture)
        }

        finalBitmap
    }

    suspend fun saveEditedCopy(
        context: Context,
        editedBitmap: Bitmap,
        originalDisplayName: String
    ): Uri? = withContext(Dispatchers.IO) {
        val resolver = context.contentResolver
        val newName = "ADSLR_EDIT_${System.currentTimeMillis()}.jpg"

        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, newName)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.DATE_ADDED, System.currentTimeMillis() / 1000)
            put(MediaStore.Images.Media.DATE_TAKEN, System.currentTimeMillis())

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_DCIM}/AlternativeDSLR")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
        }

        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        } else {
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        }

        val uri = resolver.insert(collection, values) ?: return@withContext null

        try {
            resolver.openOutputStream(uri)?.use { out ->
                editedBitmap.compress(Bitmap.CompressFormat.JPEG, 98, out)
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                values.clear()
                values.put(MediaStore.Images.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed saving edited copy", e)
            return@withContext null
        }

        uri
    }
}
