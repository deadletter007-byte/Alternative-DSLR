package com.example.engine

import android.graphics.Bitmap
import kotlin.math.max
import kotlin.math.min

/**
 * Conservative display-referred colour reconstruction for fused HDR output.
 * It controls excessive chroma near bright tones and gently compresses extreme
 * saturation while preserving luminance. A simple RGB heuristic reduces the
 * chance of over-processing common skin-tone hues; it is not face/skin detection.
 */
object NaturalColorReconstruction {
    private const val TILE_HEIGHT = 32

    fun apply(bitmap: Bitmap): Bitmap {
        require(!bitmap.isRecycled && bitmap.width > 0 && bitmap.height > 0) {
            "HDR bitmap must be valid and unrecycled"
        }
        val width = bitmap.width
        val height = bitmap.height
        val tile = IntArray(width * min(TILE_HEIGHT, height))
        var top = 0
        while (top < height) {
            val rows = min(TILE_HEIGHT, height - top)
            bitmap.getPixels(tile, 0, width, 0, top, width, rows)
            for (i in 0 until width * rows) {
                val color = tile[i]
                val r = (color ushr 16) and 0xFF
                val g = (color ushr 8) and 0xFF
                val b = color and 0xFF
                val y = 0.2126 * r + 0.7152 * g + 0.0722 * b
                val maxC = max(r, max(g, b)).toDouble()
                val minC = min(r, min(g, b)).toDouble()
                val chroma = maxC - minC
                if (chroma < 1.0) continue

                // Reduce chroma only when it is unusually strong or highlights
                // approach clipping. Neutral colours remain unchanged.
                val saturation = chroma / max(1.0, maxC)
                val highlight = ((y - 190.0) / 65.0).coerceIn(0.0, 1.0)
                val excess = ((saturation - 0.72) / 0.28).coerceIn(0.0, 1.0)
                val skinLike = isSkinLikeRgb(r, g, b)
                val skinProtection = if (skinLike) 0.72 else 1.0
                val chromaScale = (1.0 - (0.10 * excess + 0.12 * highlight * saturation) * skinProtection)
                    .coerceIn(0.78, 1.0)

                val nr = (y + (r - y) * chromaScale).toInt().coerceIn(0, 255)
                val ng = (y + (g - y) * chromaScale).toInt().coerceIn(0, 255)
                val nb = (y + (b - y) * chromaScale).toInt().coerceIn(0, 255)
                tile[i] = (color and -0x1000000) or (nr shl 16) or (ng shl 8) or nb
            }
            bitmap.setPixels(tile, 0, width, 0, top, width, rows)
            top += rows
        }
        return bitmap
    }

    /** Broad RGB-range heuristic only. It does not identify people or faces. */
    private fun isSkinLikeRgb(r: Int, g: Int, b: Int): Boolean {
        return r > 70 && g > 35 && b > 15 && r >= g &&
            (r - g) > 8 && r - g < 100 && (max(r, max(g, b)) - min(r, min(g, b))) > 12
    }
}
