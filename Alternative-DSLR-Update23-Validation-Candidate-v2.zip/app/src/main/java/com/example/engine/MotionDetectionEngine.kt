package com.example.engine

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Low-memory motion detector for exposure-bracketed HDR frames.
 * It compensates for the global exposure difference before comparing local cells,
 * then dilates detections slightly so moving-object edges are not blended twice.
 * This is grid-based motion detection, not dense optical flow.
 */
object MotionDetectionEngine {
    private const val GRID_W = 48
    private const val GRID_H = 36
    private const val CELL_THRESHOLD_STOPS = 0.48
    private const val MIN_LUMA = 0.025
    private const val MAX_LUMA = 0.94

    data class MotionMap internal constructor(
        val columns: Int,
        val rows: Int,
        private val moving: BooleanArray,
        val movingCellRatio: Float,
        val exposureScale: Float
    ) {
        fun isMoving(x: Int, y: Int, imageWidth: Int, imageHeight: Int): Boolean {
            if (imageWidth <= 0 || imageHeight <= 0) return false
            val gx = (x.toLong() * columns / imageWidth).toInt().coerceIn(0, columns - 1)
            val gy = (y.toLong() * rows / imageHeight).toInt().coerceIn(0, rows - 1)
            return moving[gy * columns + gx]
        }
    }

    fun detect(
        reference: Bitmap,
        source: Bitmap,
        sourceDx: Int = 0,
        sourceDy: Int = 0
    ): MotionMap {
        require(!reference.isRecycled && !source.isRecycled) { "HDR frames must not be recycled" }
        require(reference.width > 0 && reference.height > 0 && source.width > 0 && source.height > 0)
        val width = reference.width
        val height = reference.height
        val columns = min(GRID_W, width).coerceAtLeast(1)
        val rows = min(GRID_H, height).coerceAtLeast(1)
        val refSamples = FloatArray(columns * rows)
        val srcSamples = FloatArray(columns * rows)
        val sample = IntArray(1)
        val ratios = ArrayList<Float>(columns * rows)

        for (gy in 0 until rows) {
            val y = ((gy + 0.5f) * height / rows).roundToInt().coerceIn(0, height - 1)
            for (gx in 0 until columns) {
                val x = ((gx + 0.5f) * width / columns).roundToInt().coerceIn(0, width - 1)
                reference.getPixels(sample, 0, 1, x, y, 1, 1)
                val refLuma = luma(sample[0])
                val sx = (x + sourceDx).coerceIn(0, source.width - 1)
                val sy = (y + sourceDy).coerceIn(0, source.height - 1)
                source.getPixels(sample, 0, 1, sx, sy, 1, 1)
                val srcLuma = luma(sample[0])
                val index = gy * columns + gx
                refSamples[index] = refLuma
                srcSamples[index] = srcLuma
                if (refLuma in MIN_LUMA..MAX_LUMA && srcLuma in MIN_LUMA..MAX_LUMA) {
                    ratios.add((refLuma / max(0.005f, srcLuma)).coerceIn(0.125f, 8f))
                }
            }
        }

        // Median ratio removes the bracket's global exposure shift while retaining
        // local differences caused by scene motion.
        ratios.sort()
        val scale = if (ratios.isEmpty()) 1f else ratios[ratios.size / 2]
        val raw = BooleanArray(columns * rows)
        for (i in raw.indices) {
            val ref = refSamples[i]
            val normalizedSource = (srcSamples[i] * scale).coerceIn(0f, 1f)
            val valid = ref in MIN_LUMA..MAX_LUMA && normalizedSource in MIN_LUMA..MAX_LUMA
            val deltaStops = if (valid) abs(ln(max(0.005f, normalizedSource) / max(0.005f, ref)) / ln(2f)) else 0f
            raw[i] = valid && deltaStops > CELL_THRESHOLD_STOPS
        }

        // One-cell dilation protects object boundaries from mixed-frame halos.
        val expanded = raw.copyOf()
        for (gy in 0 until rows) for (gx in 0 until columns) {
            val index = gy * columns + gx
            if (!raw[index]) continue
            for (oy in -1..1) for (ox in -1..1) {
                val nx = gx + ox
                val ny = gy + oy
                if (nx in 0 until columns && ny in 0 until rows) expanded[ny * columns + nx] = true
            }
        }
        val expandedCount = expanded.count { it }
        return MotionMap(columns, rows, expanded,
            expandedCount.toFloat() / expanded.size.coerceAtLeast(1), scale)
    }

    private fun luma(color: Int): Float =
        (0.2126f * ((color shr 16) and 0xFF) +
            0.7152f * ((color shr 8) and 0xFF) +
            0.0722f * (color and 0xFF)) / 255f
}
