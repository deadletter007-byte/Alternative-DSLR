package com.example.engine

import android.graphics.Bitmap
import kotlin.math.max
import kotlin.math.min

/**
 * Lightweight, non-destructive sanity checks for display-referred HDR output.
 * These metrics detect obvious pipeline failures; they are not a substitute for
 * reference-image scoring, visual review, or testing on a physical camera device.
 */
object HdrQualityValidation {
    private const val TILE_HEIGHT = 32

    data class Report(
        val width: Int,
        val height: Int,
        val meanLuminance: Double,
        val minLuminance: Double,
        val maxLuminance: Double,
        val clippedPixelRatio: Double,
        val nearBlackPixelRatio: Double,
        val passed: Boolean,
        val warnings: List<String>
    )

    fun inspect(bitmap: Bitmap): Report {
        require(!bitmap.isRecycled && bitmap.width > 0 && bitmap.height > 0) {
            "HDR output must be a valid, unrecycled bitmap"
        }
        val width = bitmap.width
        val height = bitmap.height
        val pixels = IntArray(width * min(TILE_HEIGHT, height))
        val total = width.toLong() * height.toLong()
        var sum = 0.0
        var minLuma = 1.0
        var maxLuma = 0.0
        var clipped = 0L
        var nearBlack = 0L
        var top = 0
        while (top < height) {
            val rows = min(TILE_HEIGHT, height - top)
            bitmap.getPixels(pixels, 0, width, 0, top, width, rows)
            val count = width * rows
            for (i in 0 until count) {
                val color = pixels[i]
                val r = (color ushr 16) and 0xFF
                val g = (color ushr 8) and 0xFF
                val b = color and 0xFF
                val luma = (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255.0
                sum += luma
                minLuma = min(minLuma, luma)
                maxLuma = max(maxLuma, luma)
                if (r >= 254 && g >= 254 && b >= 254) clipped++
                if (r <= 1 && g <= 1 && b <= 1) nearBlack++
            }
            top += rows
        }
        val mean = sum / total.toDouble()
        val clippedRatio = clipped.toDouble() / total.toDouble()
        val blackRatio = nearBlack.toDouble() / total.toDouble()
        val warnings = mutableListOf<String>()
        if (clippedRatio > 0.02) warnings += "More than 2% of pixels are near-white clipped."
        if (blackRatio > 0.05) warnings += "More than 5% of pixels are near-black."
        if (maxLuma - minLuma < 0.02) warnings += "Output has very low luminance range; check exposure fusion."
        if (mean < 0.015) warnings += "Output is unusually dark."
        if (mean > 0.985) warnings += "Output is unusually bright."
        return Report(
            width = width,
            height = height,
            meanLuminance = mean,
            minLuminance = minLuma,
            maxLuminance = maxLuma,
            clippedPixelRatio = clippedRatio,
            nearBlackPixelRatio = blackRatio,
            passed = warnings.isEmpty(),
            warnings = warnings.toList()
        )
    }
}
