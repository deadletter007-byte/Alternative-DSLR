package com.example.engine

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Memory-bounded, coarse-to-fine block optical-flow approximation for HDR frame alignment.
 * This is not a neural or full-resolution dense-flow model. It estimates local block motion
 * on a small luminance image and smoothly interpolates the vectors during full-resolution fusion.
 */
object OpticalFlowAlignment {
    private const val ANALYSIS_WIDTH = 96
    private const val ANALYSIS_HEIGHT = 72
    private const val GRID_COLUMNS = 12
    private const val GRID_ROWS = 9
    private const val PATCH_RADIUS = 2
    private const val SEARCH_RADIUS = 7
    private const val MAX_VECTOR_PIXELS = 48f
    private const val MIN_TEXTURE = 0.012
    private const val MIN_CONFIDENCE_GAIN = 0.015

    data class FlowField internal constructor(
        val columns: Int,
        val rows: Int,
        val imageWidth: Int,
        val imageHeight: Int,
        internal val dx: FloatArray,
        internal val dy: FloatArray,
        internal val reliable: BooleanArray,
        val reliableCellRatio: Float
    ) {
        fun displacementAt(x: Int, y: Int): Pair<Float, Float> {
            val gx = (x.toFloat() / imageWidth * (columns - 1)).coerceIn(0f, (columns - 1).toFloat())
            val gy = (y.toFloat() / imageHeight * (rows - 1)).coerceIn(0f, (rows - 1).toFloat())
            val x0 = gx.toInt().coerceIn(0, columns - 1)
            val y0 = gy.toInt().coerceIn(0, rows - 1)
            val x1 = min(x0 + 1, columns - 1)
            val y1 = min(y0 + 1, rows - 1)
            val fx = gx - x0
            val fy = gy - y0
            fun interpolate(values: FloatArray): Float {
                val a = values[y0 * columns + x0] * (1f - fx) + values[y0 * columns + x1] * fx
                val b = values[y1 * columns + x0] * (1f - fx) + values[y1 * columns + x1] * fx
                return a * (1f - fy) + b * fy
            }
            return Pair(interpolate(dx), interpolate(dy))
        }
    }

    fun estimate(reference: Bitmap, source: Bitmap, baseDx: Int = 0, baseDy: Int = 0): FlowField {
        require(!reference.isRecycled && !source.isRecycled) { "Optical-flow frames must not be recycled" }
        require(reference.width > 0 && reference.height > 0 && source.width > 0 && source.height > 0)
        val width = min(ANALYSIS_WIDTH, reference.width).coerceAtLeast(24)
        val height = min(ANALYSIS_HEIGHT, reference.height).coerceAtLeast(18)
        val refBitmap = Bitmap.createScaledBitmap(reference, width, height, true)
        val srcBitmap = Bitmap.createScaledBitmap(source, width, height, true)
        try {
            val refPixels = IntArray(width * height)
            val srcPixels = IntArray(width * height)
            refBitmap.getPixels(refPixels, 0, width, 0, 0, width, height)
            srcBitmap.getPixels(srcPixels, 0, width, 0, 0, width, height)
            val ref = FloatArray(refPixels.size) { luma(refPixels[it]) }
            val src = FloatArray(srcPixels.size) { luma(srcPixels[it]) }
            val columns = min(GRID_COLUMNS, max(2, width / 6))
            val rows = min(GRID_ROWS, max(2, height / 6))
            val dx = FloatArray(columns * rows)
            val dy = FloatArray(columns * rows)
            val reliable = BooleanArray(columns * rows)
            val scaleX = reference.width.toFloat() / width
            val scaleY = reference.height.toFloat() / height
            val baseSmallX = (baseDx / scaleX).roundToInt()
            val baseSmallY = (baseDy / scaleY).roundToInt()

            for (gy in 0 until rows) for (gx in 0 until columns) {
                val cx = ((gx + 0.5f) * width / columns).roundToInt().coerceIn(PATCH_RADIUS + SEARCH_RADIUS, width - PATCH_RADIUS - SEARCH_RADIUS - 1)
                val cy = ((gy + 0.5f) * height / rows).roundToInt().coerceIn(PATCH_RADIUS + SEARCH_RADIUS, height - PATCH_RADIUS - SEARCH_RADIUS - 1)
                val index = gy * columns + gx
                var texture = 0f
                for (py in -PATCH_RADIUS..PATCH_RADIUS) for (px in -PATCH_RADIUS..PATCH_RADIUS) {
                    val v = ref[(cy + py) * width + cx + px]
                    texture += abs(v - ref[(cy + py) * width + cx + px - 1])
                    texture += abs(v - ref[(cy + py - 1) * width + cx + px])
                }
                if (texture / 50f < MIN_TEXTURE) {
                    dx[index] = baseDx.toFloat(); dy[index] = baseDy.toFloat(); continue
                }
                var best = Float.MAX_VALUE
                var second = Float.MAX_VALUE
                var bestX = baseSmallX
                var bestY = baseSmallY
                for (oy in -SEARCH_RADIUS..SEARCH_RADIUS) for (ox in -SEARCH_RADIUS..SEARCH_RADIUS) {
                    val sx = cx + baseSmallX + ox
                    val sy = cy + baseSmallY + oy
                    if (sx - PATCH_RADIUS < 0 || sx + PATCH_RADIUS >= width || sy - PATCH_RADIUS < 0 || sy + PATCH_RADIUS >= height) continue
                    var error = 0f
                    for (py in -PATCH_RADIUS..PATCH_RADIUS) for (px in -PATCH_RADIUS..PATCH_RADIUS) {
                        error += abs(ref[(cy + py) * width + cx + px] - src[(sy + py) * width + sx + px])
                    }
                    error /= 25f
                    if (error < best) { second = best; best = error; bestX = baseSmallX + ox; bestY = baseSmallY + oy }
                    else if (error < second) second = error
                }
                val distinct = if (second.isFinite() && second > 1e-6f) (second - best) / second else 0f
                val valid = best < 0.18f && distinct >= MIN_CONFIDENCE_GAIN
                val fullDx = bestX * scaleX
                val fullDy = bestY * scaleY
                val bounded = abs(fullDx) <= MAX_VECTOR_PIXELS && abs(fullDy) <= MAX_VECTOR_PIXELS
                if (valid && bounded) {
                    dx[index] = fullDx; dy[index] = fullDy; reliable[index] = true
                } else {
                    dx[index] = baseDx.toFloat(); dy[index] = baseDy.toFloat()
                }
            }
            // Replace isolated unreliable cells with the median of reliable neighbours.
            for (gy in 0 until rows) for (gx in 0 until columns) {
                val i = gy * columns + gx
                if (reliable[i]) continue
                val nx = ArrayList<Float>(8); val ny = ArrayList<Float>(8)
                for (oy in -1..1) for (ox in -1..1) {
                    val x = gx + ox; val y = gy + oy
                    if (x !in 0 until columns || y !in 0 until rows) continue
                    val ni = y * columns + x
                    if (reliable[ni]) { nx.add(dx[ni]); ny.add(dy[ni]) }
                }
                if (nx.size >= 3) { nx.sort(); ny.sort(); dx[i] = nx[nx.size / 2]; dy[i] = ny[ny.size / 2] }
            }
            return FlowField(columns, rows, reference.width, reference.height, dx, dy, reliable,
                reliable.count { it }.toFloat() / reliable.size.coerceAtLeast(1))
        } finally {
            if (refBitmap !== reference && !refBitmap.isRecycled) refBitmap.recycle()
            if (srcBitmap !== source && !srcBitmap.isRecycled) srcBitmap.recycle()
        }
    }

    private fun luma(color: Int): Float =
        (0.2126f * ((color shr 16) and 0xFF) + 0.7152f * ((color shr 8) and 0xFF) +
            0.0722f * (color and 0xFF)) / 255f
}
