package com.example.engine

import kotlin.math.abs

/**
 * Conservative reference-guided ghost suppression for three-frame HDR fusion.
 * Moving regions are reconstructed from the middle/reference exposure only;
 * static regions retain exposure fusion. This avoids blending duplicated edges.
 * It is an image-space fallback, not object tracking or semantic segmentation.
 */
object GhostRemovalEngine {
    data class Decision(val weight: Double, val useReferenceOnly: Boolean)

    /** Returns the contribution weight for a non-reference exposure sample. */
    fun contributionWeight(
        referenceLuma: Double,
        candidateLuma: Double,
        motionDetected: Boolean,
        exposureWeight: Double
    ): Decision {
        if (motionDetected) return Decision(0.0, true)

        // Exposure brackets naturally differ in brightness. Large normalized
        // disagreement is treated conservatively to avoid false double contours.
        val disagreement = abs(candidateLuma - referenceLuma)
        val consistency = when {
            disagreement >= 0.34 -> 0.0
            disagreement >= 0.23 -> 0.12
            disagreement >= 0.15 -> 0.40
            else -> 1.0
        }
        return Decision(exposureWeight * consistency, false)
    }

    /** Small mask dilation is already performed by MotionDetectionEngine. */
    fun shouldUseReferenceOnly(motionDetected: Boolean): Boolean = motionDetected
}
