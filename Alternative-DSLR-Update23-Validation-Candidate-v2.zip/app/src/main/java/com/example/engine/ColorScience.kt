package com.example.engine

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import com.example.settings.ColorScienceProfile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object ColorScience {

    suspend fun applyColorProfile(
        input: Bitmap,
        profile: ColorScienceProfile
    ): Bitmap = withContext(Dispatchers.Default) {
        val output = Bitmap.createBitmap(input.width, input.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

        val matrix = when (profile) {
            ColorScienceProfile.NATURAL -> {
                // Organic balance, slight saturation enhancement without skin clipping
                val cm = ColorMatrix()
                cm.setSaturation(1.04f)
                cm
            }

            ColorScienceProfile.NEUTRAL -> {
                // Flat linear curve, lower contrast for grading
                ColorMatrix(floatArrayOf(
                    0.92f, 0f, 0f, 0f, 10f,
                    0f, 0.92f, 0f, 0f, 10f,
                    0f, 0f, 0.92f, 0f, 10f,
                    0f, 0f, 0f, 1.0f, 0f
                ))
            }

            ColorScienceProfile.VIVID -> {
                // Rich dynamic tones
                val cm = ColorMatrix(floatArrayOf(
                    1.08f, 0f, 0f, 0f, -8f,
                    0f, 1.08f, 0f, 0f, -8f,
                    0f, 0f, 1.10f, 0f, -6f,
                    0f, 0f, 0f, 1.0f, 0f
                ))
                val sat = ColorMatrix()
                sat.setSaturation(1.22f)
                cm.postConcat(sat)
                cm
            }

            ColorScienceProfile.PORTRAIT_NATURAL -> {
                // Gentle red rolloff to protect skin tones, subtle warmth
                ColorMatrix(floatArrayOf(
                    1.01f, 0f, 0f, 0f, 4f,
                    0f, 0.99f, 0f, 0f, 2f,
                    0f, 0f, 0.96f, 0f, 0f,
                    0f, 0f, 0f, 1.0f, 0f
                ))
            }

            ColorScienceProfile.LANDSCAPE_NATURAL -> {
                // Deep greens and vibrant sky blues with haze reduction
                ColorMatrix(floatArrayOf(
                    0.98f, 0f, 0f, 0f, -4f,
                    0f, 1.06f, 0f, 0f, 2f,
                    0f, 0f, 1.08f, 0f, 4f,
                    0f, 0f, 0f, 1.0f, 0f
                ))
            }

            ColorScienceProfile.WARM -> {
                // Golden hour warmth
                ColorMatrix(floatArrayOf(
                    1.10f, 0f, 0f, 0f, 8f,
                    0f, 1.04f, 0f, 0f, 4f,
                    0f, 0f, 0.90f, 0f, -6f,
                    0f, 0f, 0f, 1.0f, 0f
                ))
            }

            ColorScienceProfile.COOL -> {
                // Clean titanium daylight
                ColorMatrix(floatArrayOf(
                    0.94f, 0f, 0f, 0f, -4f,
                    0f, 0.98f, 0f, 0f, 0f,
                    0f, 0f, 1.10f, 0f, 10f,
                    0f, 0f, 0f, 1.0f, 0f
                ))
            }

            ColorScienceProfile.PRO_NEUTRAL -> {
                // Studio color chart response
                ColorMatrix(floatArrayOf(
                    1.0f, 0f, 0f, 0f, 0f,
                    0f, 1.0f, 0f, 0f, 0f,
                    0f, 0f, 1.0f, 0f, 0f,
                    0f, 0f, 0f, 1.0f, 0f
                ))
            }

            ColorScienceProfile.DSLR_NATURAL -> {
                // Rich midtones, aperture depth
                val cm = ColorMatrix(floatArrayOf(
                    1.05f, 0f, 0f, 0f, -5f,
                    0f, 1.05f, 0f, 0f, -5f,
                    0f, 0f, 1.04f, 0f, -4f,
                    0f, 0f, 0f, 1.0f, 0f
                ))
                val sat = ColorMatrix()
                sat.setSaturation(1.08f)
                cm.postConcat(sat)
                cm
            }

            ColorScienceProfile.CINEMATIC_CLASSIC -> {
                // Analog film rolloff, subtle warm shadows and cool highlights
                ColorMatrix(floatArrayOf(
                    1.03f, 0f, 0f, 0f, 5f,
                    0f, 1.01f, 0f, 0f, 2f,
                    0f, 0f, 0.95f, 0f, 8f,
                    0f, 0f, 0f, 1.0f, 0f
                ))
            }
        }

        paint.colorFilter = ColorMatrixColorFilter(matrix)
        canvas.drawBitmap(input, 0f, 0f, paint)
        output
    }
}
