package com.example.engine

/**
 * Builds a safe exposure-bracketing plan from the camera's real EV compensation range.
 * Values are CameraX exposure-compensation indices, not assumed EV stops.
 * This planner does not capture frames or claim HDR fusion has occurred.
 */
data class ExposureBracketPlan(
    val compensationIndices: List<Int>,
    val evStep: Float,
    val supportsThreeFrameBracket: Boolean,
    val explanation: String
)

object ExposureBracketPlanner {
    fun create(
        minIndex: Int,
        maxIndex: Int,
        evStep: Float
    ): ExposureBracketPlan {
        if (minIndex > maxIndex || !evStep.isFinite() || evStep <= 0f) {
            return ExposureBracketPlan(emptyList(), 0f, false, "Invalid camera exposure range")
        }
        if (minIndex == maxIndex) {
            return ExposureBracketPlan(listOf(0.coerceIn(minIndex, maxIndex)), evStep, false,
                "Camera exposes no usable exposure-compensation range")
        }

        // CameraX indices are converted to EV using the camera's own Rational step.
        // The caller supplies that step; choose the largest symmetric bracket not
        // exceeding the hardware range, with a practical target of +/- 2 EV.
        val availableEv = minOf(-minIndex * evStep, maxIndex * evStep).coerceAtLeast(0f)
        val bracketEv = minOf(2f, availableEv)
        if (bracketEv < evStep) {
            return ExposureBracketPlan(listOf(0.coerceIn(minIndex, maxIndex)), evStep, false,
                "Exposure range is too narrow for a useful three-frame bracket")
        }
        val offset = (bracketEv / evStep).toInt().coerceAtLeast(1)
        val indices = listOf(-offset, 0, offset).map { it.coerceIn(minIndex, maxIndex) }.distinct()
        val valid = indices.size == 3 && indices.first() < 0 && indices.last() > 0
        return ExposureBracketPlan(
            compensationIndices = indices,
            evStep = evStep,
            supportsThreeFrameBracket = valid,
            explanation = if (valid) "Camera range permits a three-frame exposure bracket; capture and fusion are separate steps"
                else "Camera range does not permit a symmetric three-frame exposure bracket"
        )
    }
}
