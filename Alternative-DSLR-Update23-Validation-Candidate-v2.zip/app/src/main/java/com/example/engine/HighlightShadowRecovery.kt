package com.example.engine

import android.graphics.Bitmap
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/**
 * Conservative highlight and shadow recovery for an already fused SDR bitmap.
 * Operates in linear light and scales RGB together to preserve hue. It cannot
 * recover detail clipped in every source exposure; it only remaps retained data.
 */
object HighlightShadowRecovery {
    private const val TILE_HEIGHT = 24

    fun apply(bitmap: Bitmap) {
        require(!bitmap.isRecycled && bitmap.width > 0 && bitmap.height > 0) {
            "Highlight/shadow input must be a valid bitmap"
        }
        val width = bitmap.width
        val height = bitmap.height
        val tile = IntArray(width * min(TILE_HEIGHT, height))
        var top = 0
        while (top < height) {
            val rows = min(TILE_HEIGHT, height - top)
            bitmap.getPixels(tile, 0, width, 0, top, width, rows)
            val count = width * rows
            for (i in 0 until count) {
                val color = tile[i]
                val r = toLinear((color shr 16) and 0xFF)
                val g = toLinear((color shr 8) and 0xFF)
                val b = toLinear(color and 0xFF)
                val y = 0.2126 * r + 0.7152 * g + 0.0722 * b
                if (y <= 1e-6) continue

                // Gentle toe lifts only deep shadows; smoothstep avoids a visible threshold.
                val shadowT = smoothstep(0.015, 0.34, y)
                val shadowLift = 0.035 * (1.0 - shadowT).pow(1.35)
                // A soft shoulder compresses bright values while retaining highlight gradation.
                val highlightT = smoothstep(0.48, 0.98, y)
                val shoulder = 1.0 - 0.20 * highlightT
                val recoveredY = ((y + shadowLift) * shoulder).coerceIn(0.0, 1.0)
                val scale = (recoveredY / y).coerceIn(0.78, 1.55)
                tile[i] = (color and (0xFF shl 24)) or
                    (toSrgb(r * scale) shl 16) or
                    (toSrgb(g * scale) shl 8) or toSrgb(b * scale)
            }
            bitmap.setPixels(tile, 0, width, 0, top, width, rows)
            top += rows
        }
    }

    private fun smoothstep(edge0: Double, edge1: Double, value: Double): Double {
        val t = ((value - edge0) / (edge1 - edge0)).coerceIn(0.0, 1.0)
        return t * t * (3.0 - 2.0 * t)
    }

    private fun toLinear(channel: Int): Double {
        val v = channel.coerceIn(0, 255) / 255.0
        return if (v <= 0.04045) v / 12.92 else ((v + 0.055) / 1.055).pow(2.4)
    }

    private fun toSrgb(value: Double): Int {
        val v = value.coerceIn(0.0, 1.0)
        val encoded = if (v <= 0.0031308) v * 12.92 else 1.055 * v.pow(1.0 / 2.4) - 0.055
        return (encoded * 255.0).toInt().coerceIn(0, 255)
    }
}
