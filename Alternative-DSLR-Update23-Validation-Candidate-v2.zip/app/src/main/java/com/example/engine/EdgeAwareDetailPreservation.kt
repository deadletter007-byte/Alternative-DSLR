package com.example.engine

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Conservative edge-aware detail restoration for display-referred HDR output.
 * A small luminance high-pass is applied only where a local contrast gate allows
 * it. RGB channels are scaled together so hue/chroma are not independently sharpened.
 * This is not AI super-resolution and cannot recreate detail absent from the input.
 */
object EdgeAwareDetailPreservation {
    private const val TILE_HEIGHT = 32
    private const val DETAIL_GAIN = 0.32
    private const val MAX_DETAIL_DELTA = 6.0
    private const val FLAT_REGION_THRESHOLD = 3.0
    private const val FULL_GATE_RANGE = 18.0

    fun apply(bitmap: Bitmap): Bitmap {
        require(!bitmap.isRecycled && bitmap.width > 0 && bitmap.height > 0) {
            "HDR bitmap must be valid and unrecycled"
        }
        val width = bitmap.width
        val height = bitmap.height
        val rowsPerTile = min(TILE_HEIGHT, height)
        // One-pixel halo above and below avoids visible seams between tiles.
        val strip = IntArray(width * (rowsPerTile + 2))
        val output = IntArray(width * rowsPerTile)
        var top = 0
        while (top < height) {
            val rows = min(TILE_HEIGHT, height - top)
            val sourceTop = max(0, top - 1)
            val sourceBottom = min(height - 1, top + rows)
            val sourceRows = sourceBottom - sourceTop + 1
            bitmap.getPixels(strip, 0, width, 0, sourceTop, width, sourceRows)

            for (y in 0 until rows) {
                val imageY = top + y
                val localY = imageY - sourceTop
                for (x in 0 until width) {
                    val index = y * width + x
                    val center = strip[localY * width + x]
                    val centerLuma = luma(center)
                    var weightedBlur = 0.0
                    var weightSum = 0.0
                    var localMin = 255.0
                    var localMax = 0.0

                    // Separable-style 3x3 Gaussian weights: 1,2,1 in each axis.
                    for (oy in -1..1) {
                        val sy = (localY + oy).coerceIn(0, sourceRows - 1)
                        val wy = if (oy == 0) 2.0 else 1.0
                        for (ox in -1..1) {
                            val sx = (x + ox).coerceIn(0, width - 1)
                            val sample = luma(strip[sy * width + sx])
                            val wx = if (ox == 0) 2.0 else 1.0
                            val weight = wx * wy
                            weightedBlur += sample * weight
                            weightSum += weight
                            localMin = min(localMin, sample)
                            localMax = max(localMax, sample)
                        }
                    }

                    val localRange = localMax - localMin
                    val gate = ((localRange - FLAT_REGION_THRESHOLD) /
                        (FULL_GATE_RANGE - FLAT_REGION_THRESHOLD)).coerceIn(0.0, 1.0)
                    if (gate <= 0.0 || centerLuma <= 1.0) {
                        output[index] = center
                        continue
                    }
                    val blur = weightedBlur / weightSum
                    val detail = (centerLuma - blur) * DETAIL_GAIN * gate
                    val adjustedLuma = (centerLuma + detail.coerceIn(-MAX_DETAIL_DELTA, MAX_DETAIL_DELTA))
                        .coerceIn(0.0, 255.0)
                    val scale = (adjustedLuma / centerLuma).coerceIn(0.94, 1.06)
                    val a = (center ushr 24) and 0xFF
                    val r = (((center ushr 16) and 0xFF) * scale).toInt().coerceIn(0, 255)
                    val g = (((center ushr 8) and 0xFF) * scale).toInt().coerceIn(0, 255)
                    val b = ((center and 0xFF) * scale).toInt().coerceIn(0, 255)
                    output[index] = (a shl 24) or (r shl 16) or (g shl 8) or b
                }
            }
            bitmap.setPixels(output, 0, width, 0, top, width, rows)
            top += rows
        }
        return bitmap
    }

    private fun luma(color: Int): Double {
        val r = ((color ushr 16) and 0xFF).toDouble()
        val g = ((color ushr 8) and 0xFF).toDouble()
        val b = (color and 0xFF).toDouble()
        return 0.2126 * r + 0.7152 * g + 0.0722 * b
    }
}
