package com.example.engine

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.max

/**
 * Conservative same-exposure burst enhancement.
 * This improves random noise by combining only temporally consistent samples.
 * It does NOT increase captured dynamic range or recover clipped sensor data.
 * The middle frame remains the reference in moving/disagreeing regions.
 */
object BurstEnhancementEngine {
    data class Result(val bitmap: Bitmap, val acceptedSampleRatio: Float)

    fun fuseSameExposure(frames: List<Bitmap>, referenceIndex: Int = frames.size / 2): Result {
        require(frames.size >= 3) { "At least three same-exposure frames are required" }
        require(frames.all { !it.isRecycled && it.width > 0 && it.height > 0 })
        val ref = frames[referenceIndex.coerceIn(frames.indices)]
        val compatible = frames.filter { it.width == ref.width && it.height == ref.height }
        require(compatible.size >= 3) { "Burst frames must have matching dimensions" }
        val refPosition = compatible.indexOfFirst { it === ref }.coerceAtLeast(0)
        val out = ref.copy(Bitmap.Config.ARGB_8888, true)
        val width = ref.width
        val height = ref.height
        val tileHeight = 24
        val refPixels = IntArray(width * minOf(tileHeight, height))
        val buffers = Array(compatible.size) { IntArray(refPixels.size) }
        var accepted = 0L
        var total = 0L
        var top = 0
        while (top < height) {
            val rows = minOf(tileHeight, height - top)
            val count = width * rows
            for (i in compatible.indices) compatible[i].getPixels(buffers[i], 0, width, 0, top, width, rows)
            for (p in 0 until count) {
                val base = buffers[refPosition][p]
                val baseY = luma(base)
                var sr = 0L; var sg = 0L; var sb = 0L; var n = 0
                for (i in buffers.indices) {
                    val c = buffers[i][p]
                    // Reject moving edges and exposure/flicker disagreements.
                    if (abs(luma(c) - baseY) <= max(14, baseY * 10 / 100)) {
                        sr += (c shr 16) and 255; sg += (c shr 8) and 255; sb += c and 255; n++
                    }
                }
                if (n >= 2) {
                    buffers[0][p] = (0xFF shl 24) or
                        (((sr / n).toInt() and 255) shl 16) or
                        (((sg / n).toInt() and 255) shl 8) or
                        ((sb / n).toInt() and 255)
                    accepted++
                } else buffers[0][p] = base
                total++
            }
            out.setPixels(buffers[0], 0, width, 0, top, width, rows)
            top += rows
        }
        return Result(out, if (total == 0L) 0f else accepted.toFloat() / total)
    }

    private fun luma(color: Int): Int = (((color shr 16) and 255) * 299 + ((color shr 8) and 255) * 587 + (color and 255) * 114) / 1000
}
