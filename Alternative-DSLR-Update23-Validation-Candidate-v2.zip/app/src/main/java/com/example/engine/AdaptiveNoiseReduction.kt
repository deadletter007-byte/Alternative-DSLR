package com.example.engine

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Conservative, edge-aware denoising for display-referred HDR output.
 * Uses a small bilateral neighbourhood and a local-contrast gate. Flat areas
 * receive modest smoothing; strong edges and textured regions retain the centre
 * pixel. This is not AI denoising and cannot distinguish every fine texture from noise.
 */
object AdaptiveNoiseReduction {
    private const val TILE_HEIGHT = 32
    private const val MAX_BLEND = 0.34
    private const val FLAT_RANGE = 5.0
    private const val EDGE_RANGE = 24.0
    private const val COLOR_SIGMA = 18.0

    fun apply(bitmap: Bitmap): Bitmap {
        require(!bitmap.isRecycled && bitmap.width > 0 && bitmap.height > 0) {
            "HDR bitmap must be valid and unrecycled"
        }
        val width = bitmap.width
        val height = bitmap.height
        val tileRows = min(TILE_HEIGHT, height)
        // One-pixel halo keeps the filter continuous across tile boundaries.
        val source = IntArray(width * (tileRows + 2))
        val output = IntArray(width * tileRows)
        var top = 0
        while (top < height) {
            val rows = min(TILE_HEIGHT, height - top)
            val sourceTop = max(0, top - 1)
            val sourceBottom = min(height - 1, top + rows)
            val sourceRows = sourceBottom - sourceTop + 1
            bitmap.getPixels(source, 0, width, 0, sourceTop, width, sourceRows)

            for (y in 0 until rows) {
                val localY = top + y - sourceTop
                for (x in 0 until width) {
                    val center = source[localY * width + x]
                    val centerLuma = luma(center)
                    var minLuma = centerLuma
                    var maxLuma = centerLuma
                    var sumR = 0.0
                    var sumG = 0.0
                    var sumB = 0.0
                    var weightSum = 0.0

                    for (oy in -1..1) {
                        val sy = (localY + oy).coerceIn(0, sourceRows - 1)
                        val spatialY = if (oy == 0) 1.0 else 0.72
                        for (ox in -1..1) {
                            val sx = (x + ox).coerceIn(0, width - 1)
                            val sample = source[sy * width + sx]
                            val sampleLuma = luma(sample)
                            minLuma = min(minLuma, sampleLuma)
                            maxLuma = max(maxLuma, sampleLuma)
                            val difference = abs(sampleLuma - centerLuma)
                            val rangeWeight = Math.exp(-(difference * difference) /
                                (2.0 * COLOR_SIGMA * COLOR_SIGMA))
                            val spatialX = if (ox == 0) 1.0 else 0.72
                            val weight = spatialX * spatialY * rangeWeight
                            sumR += ((sample ushr 16) and 0xFF) * weight
                            sumG += ((sample ushr 8) and 0xFF) * weight
                            sumB += (sample and 0xFF) * weight
                            weightSum += weight
                        }
                    }

                    val localRange = maxLuma - minLuma
                    // Noise reduction is strongest in nearly-flat regions and fades
                    // smoothly toward edges, where real detail must be protected.
                    val flatGate = ((EDGE_RANGE - localRange) /
                        (EDGE_RANGE - FLAT_RANGE)).coerceIn(0.0, 1.0)
                    val blend = MAX_BLEND * flatGate
                    if (blend < 0.01 || weightSum <= 1e-9) {
                        output[y * width + x] = center
                    } else {
                        val a = (center ushr 24) and 0xFF
                        val r = (center ushr 16) and 0xFF
                        val g = (center ushr 8) and 0xFF
                        val b = center and 0xFF
                        val nr = sumR / weightSum
                        val ng = sumG / weightSum
                        val nb = sumB / weightSum
                        val outR = (r + (nr - r) * blend).toInt().coerceIn(0, 255)
                        val outG = (g + (ng - g) * blend).toInt().coerceIn(0, 255)
                        val outB = (b + (nb - b) * blend).toInt().coerceIn(0, 255)
                        output[y * width + x] = (a shl 24) or (outR shl 16) or
                            (outG shl 8) or outB
                    }
                }
            }
            bitmap.setPixels(output, 0, width, 0, top, width, rows)
            top += rows
        }
        return bitmap
    }

    private fun luma(color: Int): Double =
        0.2126 * ((color ushr 16) and 0xFF) +
            0.7152 * ((color ushr 8) and 0xFF) +
            0.0722 * (color and 0xFF)
}
