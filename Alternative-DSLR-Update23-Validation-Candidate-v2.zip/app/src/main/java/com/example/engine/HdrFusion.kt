package com.example.engine

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Memory-bounded three-frame HDR alignment and ghost-aware exposure fusion.
 * Alignment combines a global translation fallback with low-resolution local block flow.
 * Fusion is performed in horizontal tiles so full-frame IntArray copies are never allocated.
 */
object HdrFusion {
    private const val ANALYSIS_W = 96
    private const val ANALYSIS_H = 72
    private const val SEARCH_RADIUS = 8
    private const val TILE_HEIGHT = 32

    fun alignAndFuse(input: List<Bitmap>): Bitmap = alignAndFuse(input, null)

    /**
     * Fuses the bracket and optionally returns a non-destructive quality report.
     * Validation warnings never discard an otherwise valid HDR bitmap.
     */
    fun alignAndFuse(
        input: List<Bitmap>,
        onValidation: ((HdrQualityValidation.Report) -> Unit)?
    ): Bitmap {
        require(input.size == 3) { "HDR fusion requires exactly three bracket frames" }
        require(input.all { !it.isRecycled && it.width > 0 && it.height > 0 }) {
            "HDR frames must be valid, unrecycled bitmaps"
        }

        val width = input.minOf { it.width }
        val height = input.minOf { it.height }
        val frames = input.map { frame ->
            if (frame.width == width && frame.height == height) frame
            else Bitmap.createScaledBitmap(frame, width, height, true)
        }
        val reference = frames[1]
        // Reject unreliable alignment rather than applying a bad shift that can
        // create doubled edges. The reference frame always remains at (0, 0).
        val offsets = listOf(
            estimateTranslation(reference, frames[0]).takeIf { it.confident }?.let { Pair(it.dx, it.dy) } ?: Pair(0, 0),
            Pair(0, 0),
            estimateTranslation(reference, frames[2]).takeIf { it.confident }?.let { Pair(it.dx, it.dy) } ?: Pair(0, 0)
        )
        // Local block-flow vectors refine the global translation for independently
        // moving regions. Unreliable blocks retain the safe global-translation fallback.
        val flowFields = listOf(
            ParallaxCorrection.refine(reference, OpticalFlowAlignment.estimate(reference, frames[0], offsets[0].first, offsets[0].second)),
            null,
            ParallaxCorrection.refine(reference, OpticalFlowAlignment.estimate(reference, frames[2], offsets[2].first, offsets[2].second))
        )
        // Detect local scene motion after accounting for the estimated global shift.
        // The middle exposure is the reference and is never marked as moving.
        val motionMaps = listOf(
            MotionDetectionEngine.detect(reference, frames[0], offsets[0].first, offsets[0].second),
            null,
            MotionDetectionEngine.detect(reference, frames[2], offsets[2].first, offsets[2].second)
        )
        val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val tilePixels = IntArray(width * min(TILE_HEIGHT, height))
        val sourceTiles = Array(3) { IntArray(width * min(TILE_HEIGHT, height)) }

        try {
            var top = 0
            while (top < height) {
                val rows = min(TILE_HEIGHT, height - top)
                val count = width * rows
                for (frameIndex in 0..2) {
                    readTranslatedTile(frames[frameIndex], offsets[frameIndex].first,
                        offsets[frameIndex].second, flowFields[frameIndex], top, rows, sourceTiles[frameIndex])
                }

                for (i in 0 until count) {
                    val ref = sourceTiles[1][i]
                    val refLuma = linearLuma(ref)
                    var red = 0.0
                    var green = 0.0
                    var blue = 0.0
                    var totalWeight = 0.0
                    for (frameIndex in 0..2) {
                        val color = sourceTiles[frameIndex][i]
                        val luminance = linearLuma(color)
                        // Prefer well-exposed samples, but retain a small contribution
                        // from every frame to avoid abrupt tonal transitions.
                        val exposureWeight = (1.0 - abs(luminance - 0.45) / 0.55)
                            .coerceIn(0.06, 1.0)
                        val disagreement = abs(luminance - refLuma)
                        val detectedMotion = motionMaps[frameIndex]?.isMoving(
                            i % width, top + i / width, width, height
                        ) == true
                        val motionWeight = if (frameIndex == 1) 1.0 else {
                            GhostRemovalEngine.contributionWeight(
                                refLuma, luminance, detectedMotion, exposureWeight
                            ).weight
                        }
                        // The middle exposure is the sole source inside detected
                        // motion regions, preventing a second silhouette/edge.
                        val weight = if (frameIndex == 1) 1.0 else motionWeight
                        red += srgbToLinear((color shr 16) and 0xFF) * weight
                        green += srgbToLinear((color shr 8) and 0xFF) * weight
                        blue += srgbToLinear(color and 0xFF) * weight
                        totalWeight += weight
                    }
                    tilePixels[i] = if (totalWeight <= 0.0001) ref else {
                        // Exposure fusion is blended in linear light, then mapped
                        // through a bounded filmic curve for a display-ready JPEG.
                        val r = toneMapLinear(red / totalWeight)
                        val g = toneMapLinear(green / totalWeight)
                        val b = toneMapLinear(blue / totalWeight)
                        (0xFF shl 24) or (linearToSrgb(r) shl 16) or
                            (linearToSrgb(g) shl 8) or linearToSrgb(b)
                    }
                }
                output.setPixels(tilePixels, 0, width, 0, top, width, rows)
                top += rows
            }
            // Apply a low-resolution, smoothly interpolated local adaptation map.
            // The map is intentionally gentle to avoid halos and tile boundaries.
            applyLocalToneMapping(output)
            // Recover retained shadow detail and gently roll off highlights after local adaptation.
            // This is display-referred SDR remapping, not recovery of sensor-clipped data.
            HighlightShadowRecovery.apply(output)
            // Reconstruct a restrained, natural-looking colour response after
            // highlight/shadow mapping. This is conservative chroma control,
            // not semantic AI colourization or recovery of clipped source data.
            NaturalColorReconstruction.apply(output)
            // Reduce noise conservatively before detail restoration so sharpening
            // does not amplify grain in smooth regions. Strong edges are protected.
            AdaptiveNoiseReduction.apply(output)
            // Restore restrained local luminance detail without globally sharpening
            // flat regions or strongly amplifying residual noise.
            EdgeAwareDetailPreservation.apply(output)
            // Run a lightweight sanity check on the final display-referred output.
            // This is diagnostic only: natural low/high-key scenes may legitimately
            // trigger warnings, so validation must never reject or alter the image.
            val qualityReport = HdrQualityValidation.inspect(output)
            onValidation?.let { callback ->
                runCatching { callback(qualityReport) }
            }
            return output
        } catch (error: Throwable) {
            if (!output.isRecycled) output.recycle()
            throw error
        } finally {
            // Only recycle scaled working copies. The caller owns its input frames.
            frames.forEachIndexed { index, frame ->
                if (frame !== input[index] && !frame.isRecycled) frame.recycle()
            }
        }
    }


    /**
     * Local tone mapping using a small luminance grid rather than a full-frame
     * float buffer. This keeps memory bounded on devices such as the S21 Plus.
     * A smoothed gain map gently lifts darker regions and protects bright regions
     * while applying the same luminance scale to RGB to preserve hue.
     */
    private fun applyLocalToneMapping(bitmap: Bitmap) {
        val cellSize = 32
        val gridWidth = ((bitmap.width + cellSize - 1) / cellSize).coerceAtLeast(1)
        val gridHeight = ((bitmap.height + cellSize - 1) / cellSize).coerceAtLeast(1)
        val localLuma = FloatArray(gridWidth * gridHeight)
        val smoothedLuma = FloatArray(localLuma.size)
        val samplePixels = IntArray(cellSize * cellSize)

        // Estimate local mean luminance from each small cell.
        for (gy in 0 until gridHeight) {
            val top = gy * cellSize
            val rows = min(cellSize, bitmap.height - top)
            for (gx in 0 until gridWidth) {
                val left = gx * cellSize
                val cols = min(cellSize, bitmap.width - left)
                bitmap.getPixels(samplePixels, 0, cols, left, top, cols, rows)
                var sum = 0.0
                val count = cols * rows
                for (i in 0 until count) sum += linearLuma(samplePixels[i])
                localLuma[gy * gridWidth + gx] = (sum / max(1, count)).toFloat()
            }
        }

        // Smooth the grid with a compact 3x3 Gaussian kernel to prevent halos.
        val kernel = intArrayOf(1, 2, 1)
        for (gy in 0 until gridHeight) for (gx in 0 until gridWidth) {
            var weighted = 0.0
            var weightSum = 0.0
            for (oy in -1..1) for (ox in -1..1) {
                val sx = (gx + ox).coerceIn(0, gridWidth - 1)
                val sy = (gy + oy).coerceIn(0, gridHeight - 1)
                val weight = kernel[ox + 1] * kernel[oy + 1]
                weighted += localLuma[sy * gridWidth + sx] * weight
                weightSum += weight
            }
            smoothedLuma[gy * gridWidth + gx] = (weighted / weightSum).toFloat()
        }

        val tileHeight = 32
        val tile = IntArray(bitmap.width * min(tileHeight, bitmap.height))
        var top = 0
        while (top < bitmap.height) {
            val rows = min(tileHeight, bitmap.height - top)
            bitmap.getPixels(tile, 0, bitmap.width, 0, top, bitmap.width, rows)
            for (y in 0 until rows) {
                val imageY = top + y
                val gridY = (imageY.toFloat() / cellSize - 0.5f).coerceAtLeast(0f)
                val gy0 = gridY.toInt().coerceIn(0, gridHeight - 1)
                val gy1 = min(gy0 + 1, gridHeight - 1)
                val fy = (gridY - gy0).coerceIn(0f, 1f)
                for (x in 0 until bitmap.width) {
                    val gridX = (x.toFloat() / cellSize - 0.5f).coerceAtLeast(0f)
                    val gx0 = gridX.toInt().coerceIn(0, gridWidth - 1)
                    val gx1 = min(gx0 + 1, gridWidth - 1)
                    val fx = (gridX - gx0).coerceIn(0f, 1f)
                    val a = smoothedLuma[gy0 * gridWidth + gx0]
                    val b = smoothedLuma[gy0 * gridWidth + gx1]
                    val c = smoothedLuma[gy1 * gridWidth + gx0]
                    val d = smoothedLuma[gy1 * gridWidth + gx1]
                    val topMean = a + (b - a) * fx
                    val bottomMean = c + (d - c) * fx
                    val localMean = (topMean + (bottomMean - topMean) * fy).toDouble()

                    // Bounded local exposure compensation: never amplify by more
                    // than 22% or suppress by more than 18%.
                    val gain = (0.42 / max(0.08, localMean)).coerceIn(0.82, 1.22)
                    val index = y * bitmap.width + x
                    val color = tile[index]
                    val r = srgbToLinear((color shr 16) and 0xFF)
                    val g = srgbToLinear((color shr 8) and 0xFF)
                    val bl = srgbToLinear(color and 0xFF)
                    val yLinear = 0.2126 * r + 0.7152 * g + 0.0722 * bl
                    if (yLinear > 1e-5) {
                        // Shoulder preserves white points while adjusting local midtones.
                        val boosted = yLinear * gain
                        val mapped = (boosted * 1.22) / (1.0 + boosted * 0.22)
                        val scale = (mapped / yLinear).coerceIn(0.65, 1.35)
                        tile[index] = (0xFF shl 24) or
                            (linearToSrgb(r * scale) shl 16) or
                            (linearToSrgb(g * scale) shl 8) or linearToSrgb(bl * scale)
                    }
                }
            }
            bitmap.setPixels(tile, 0, bitmap.width, 0, top, bitmap.width, rows)
            top += rows
        }
    }

    private fun readTranslatedTile(
        bitmap: Bitmap, dx: Int, dy: Int, flow: OpticalFlowAlignment.FlowField?,
        top: Int, rows: Int, destination: IntArray
    ) {
        // Read only a bounded strip around this output tile. Optical-flow vectors
        // are clamped to +/-48 px, so this avoids a full-frame source pixel copy.
        val margin = if (flow == null) 0 else 48
        val sourceTop = (top + dy - margin).coerceIn(0, bitmap.height - 1)
        val sourceBottom = (top + rows - 1 + dy + margin).coerceIn(sourceTop, bitmap.height - 1)
        val stripRows = sourceBottom - sourceTop + 1
        val strip = IntArray(bitmap.width * stripRows)
        bitmap.getPixels(strip, 0, bitmap.width, 0, sourceTop, bitmap.width, stripRows)
        for (y in 0 until rows) for (x in 0 until bitmap.width) {
            val vector = flow?.displacementAt(x, top + y)
            val localDx = vector?.first ?: dx.toFloat()
            val localDy = vector?.second ?: dy.toFloat()
            val sx = (x + localDx).roundToInt().coerceIn(0, bitmap.width - 1)
            val sy = (top + y + localDy).roundToInt().coerceIn(0, bitmap.height - 1)
            val actualY = (sy - sourceTop).coerceIn(0, stripRows - 1)
            destination[y * bitmap.width + x] = strip[actualY * bitmap.width + sx]
        }
    }

    private data class TranslationEstimate(
        val dx: Int,
        val dy: Int,
        val confident: Boolean
    )

    private fun estimateTranslation(reference: Bitmap, source: Bitmap): TranslationEstimate {
        val rw = min(ANALYSIS_W, reference.width).coerceAtLeast(16)
        val rh = min(ANALYSIS_H, reference.height).coerceAtLeast(16)
        val refSmall = Bitmap.createScaledBitmap(reference, rw, rh, true)
        val srcSmall = Bitmap.createScaledBitmap(source, rw, rh, true)
        try {
            val ref = IntArray(rw * rh)
            val src = IntArray(rw * rh)
            refSmall.getPixels(ref, 0, rw, 0, 0, rw, rh)
            srcSmall.getPixels(src, 0, rw, 0, 0, rw, rh)
            val radiusX = min(SEARCH_RADIUS, rw / 8)
            val radiusY = min(SEARCH_RADIUS, rh / 8)
            var bestX = 0
            var bestY = 0
            var bestScore = Double.MAX_VALUE
            var zeroShiftScore = Double.MAX_VALUE
            for (dy in -radiusY..radiusY) for (dx in -radiusX..radiusX) {
                var error = 0.0
                var count = 0
                for (y in radiusY until rh - radiusY step 2) {
                    for (x in radiusX until rw - radiusX step 2) {
                        error += abs(luma(ref[y * rw + x]) - luma(src[(y + dy) * rw + x + dx]))
                        count++
                    }
                }
                val score = error / max(1, count)
                if (dx == 0 && dy == 0) zeroShiftScore = score
                if (score < bestScore) {
                    bestScore = score
                    bestX = dx
                    bestY = dy
                }
            }
            // Accept a shift only when it materially improves the match and the
            // resulting average luma error is low. Flat/noisy scenes often have
            // ambiguous minima; in those cases zero-shift is safer.
            val improvement = if (zeroShiftScore > 1e-9)
                (zeroShiftScore - bestScore) / zeroShiftScore else 0.0
            val confident = bestScore < 0.12 &&
                ((bestX == 0 && bestY == 0) || improvement >= 0.025)
            return TranslationEstimate(
                (bestX * reference.width.toFloat() / rw).toInt(),
                (bestY * reference.height.toFloat() / rh).toInt(),
                confident
            )
        } finally {
            if (refSmall !== reference && !refSmall.isRecycled) refSmall.recycle()
            if (srcSmall !== source && !srcSmall.isRecycled) srcSmall.recycle()
        }
    }

    private fun luma(color: Int): Double =
        (0.2126 * ((color shr 16) and 0xFF) +
            0.7152 * ((color shr 8) and 0xFF) +
            0.0722 * (color and 0xFF)) / 255.0

    private fun linearLuma(color: Int): Double =
        0.2126 * srgbToLinear((color shr 16) and 0xFF) +
            0.7152 * srgbToLinear((color shr 8) and 0xFF) +
            0.0722 * srgbToLinear(color and 0xFF)

    private fun srgbToLinear(channel: Int): Double {
        val value = channel.coerceIn(0, 255) / 255.0
        return if (value <= 0.04045) value / 12.92
        else Math.pow((value + 0.055) / 1.055, 2.4)
    }

    /** ACES-inspired filmic shoulder. Input and output are linear-light values. */
    private fun toneMapLinear(value: Double): Double {
        val x = value.coerceAtLeast(0.0)
        val mapped = (x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14)
        return mapped.coerceIn(0.0, 1.0)
    }

    private fun linearToSrgb(value: Double): Int {
        val linear = value.coerceIn(0.0, 1.0)
        val encoded = if (linear <= 0.0031308) linear * 12.92
        else 1.055 * Math.pow(linear, 1.0 / 2.4) - 0.055
        return (encoded * 255.0).toInt().coerceIn(0, 255)
    }
}
