package com.example.engine

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.media.ExifInterface
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream

data class SavedCaptureResult(
    val processedUri: Uri?,
    val originalUri: Uri?,
    val processedFilePath: String?,
    val originalFilePath: String?,
    val isRaw: Boolean,
    val resolution: String,
    val megapixels: Float
)

object FinalOptimizationEngine {
    private const val TAG = "FinalOptEngine"

    suspend fun saveCapturePair(
        context: Context,
        processedBitmap: Bitmap,
        originalBitmap: Bitmap?,
        metadata: ShotMetadata
    ): SavedCaptureResult = withContext(Dispatchers.IO) {
        val timestamp = System.currentTimeMillis()
        val processedName = "ADSLR_IMG_${timestamp}_PROC.jpg"
        val originalName = "ADSLR_IMG_${timestamp}_ORIG.jpg"

        // 1. Save processed image to MediaStore
        val procUri = saveBitmapToMediaStore(
            context = context,
            bitmap = processedBitmap,
            displayName = processedName,
            metadata = metadata,
            isProcessed = true
        )

        // 2. Save original in app internal storage or MediaStore for comparison
        val origFile = File(context.filesDir, originalName)
        try {
            FileOutputStream(origFile).use { out ->
                originalBitmap?.compress(Bitmap.CompressFormat.JPEG, 95, out)
                    ?: processedBitmap.compress(Bitmap.CompressFormat.JPEG, 95, out)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed saving original cache", e)
        }

        val megapixels = (processedBitmap.width.toLong() * processedBitmap.height.toLong()) / 1_000_000f
        val resolution = "${processedBitmap.width} × ${processedBitmap.height}"

        SavedCaptureResult(
            processedUri = procUri,
            originalUri = Uri.fromFile(origFile),
            processedFilePath = procUri?.toString(),
            originalFilePath = origFile.absolutePath,
            isRaw = metadata.isRaw,
            resolution = resolution,
            megapixels = megapixels
        )
    }

    private fun saveBitmapToMediaStore(
        context: Context,
        bitmap: Bitmap,
        displayName: String,
        metadata: ShotMetadata,
        isProcessed: Boolean
    ): Uri? {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, displayName)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.DATE_ADDED, System.currentTimeMillis() / 1000)
            put(MediaStore.Images.Media.DATE_TAKEN, System.currentTimeMillis())

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_DCIM}/AlternativeDSLR")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
        }

        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        } else {
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        }

        val uri = resolver.insert(collection, values) ?: return null

        try {
            resolver.openOutputStream(uri)?.use { stream ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 98, stream)
            }

            // Write EXIF
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                resolver.openFileDescriptor(uri, "rw")?.use { pfd ->
                    try {
                        val exif = ExifInterface(pfd.fileDescriptor)
                        exif.setAttribute(ExifInterface.TAG_MAKE, "Alternative DSLR")
                        exif.setAttribute(ExifInterface.TAG_MODEL, "Computational Optics Engine")
                        exif.setAttribute(ExifInterface.TAG_SOFTWARE, "Alternative DSLR 1.0 (Android)")
                        exif.setAttribute(ExifInterface.TAG_ISO_SPEED_RATINGS, metadata.iso.toString())
                        exif.setAttribute(ExifInterface.TAG_FOCAL_LENGTH, "${metadata.focalLengthMm}/1")
                        exif.setAttribute(ExifInterface.TAG_IMAGE_DESCRIPTION, "Alternative DSLR Profile: ${metadata.processingProfileName}")
                        exif.saveAttributes()
                    } catch (e: Exception) {
                        Log.w(TAG, "EXIF write warning", e)
                    }
                }

                values.clear()
                values.put(MediaStore.Images.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error saving bitmap to MediaStore", e)
        }

        return uri
    }
}
