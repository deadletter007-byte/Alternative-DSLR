package com.example.engine

import android.graphics.Bitmap
import android.graphics.Color
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class SceneAnalysisResult(
    val luminance: Float, // 0.0 (dark) to 1.0 (bright)
    val dynamicRangeEstimate: Float, // 0.0 to 1.0
    val detectedScene: DetectedScene,
    val suggestedIso: Int,
    val suggestedShutterSpeed: String,
    val suggestsFlash: Boolean,
    val suggestsHdr: Boolean,
    val suggestsNightMode: Boolean,
    val colorTemperatureKelvin: Int
)

enum class DetectedScene(val label: String) {
    BALANCED_DAYLIGHT("Daylight Landscape"),
    PORTRAIT("Portrait Subject"),
    LOW_LIGHT("Low Light / Night"),
    HIGH_CONTRAST("Backlit / High Dynamic Range"),
    MACRO("Close-up Subject"),
    INDOOR_WARM("Indoor Tungsten/Warm")
}

data class ShotMetadata(
    val iso: Int,
    val shutterSpeed: String,
    val evCompensation: Float,
    val focalLengthMm: Float,
    val aperture: Float,
    val whiteBalanceKelvin: Int,
    val captureTimestamp: Long = System.currentTimeMillis(),
    val isRaw: Boolean = false,
    val processingProfileName: String = "Balanced",
    val lensFacing: String = "Back",
    val sensorMegapixels: Float = 12.0f
) {
    fun formattedDate(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
        return sdf.format(Date(captureTimestamp))
    }
}

object SceneAnalysisEngine {
    /** Analyze grayscale/luma samples in the 0..255 range. Percentiles suppress isolated noise. */
    fun analyzeLumaSamples(samples: IntArray): SceneAnalysisResult {
        if (samples.isEmpty()) {
            return SceneAnalysisResult(
                luminance = 0.5f,
                dynamicRangeEstimate = 0f,
                detectedScene = DetectedScene.BALANCED_DAYLIGHT,
                suggestedIso = 100,
                suggestedShutterSpeed = "1/250s",
                suggestsFlash = false,
                suggestsHdr = false,
                suggestsNightMode = false,
                colorTemperatureKelvin = 5500
            )
        }

        val normalized = samples.map { it.coerceIn(0, 255) / 255f }.sorted()
        val average = (normalized.sum() / normalized.size).coerceIn(0f, 1f)
        val lowIndex = ((normalized.size - 1) * 0.05f).toInt()
        val highIndex = ((normalized.size - 1) * 0.95f).toInt()
        val robustRange = (normalized[highIndex] - normalized[lowIndex]).coerceIn(0f, 1f)
        val isLowLight = average < 0.25f
        val isHighContrast = robustRange > 0.75f && average in 0.3f..0.7f
        val scene = when {
            isLowLight -> DetectedScene.LOW_LIGHT
            isHighContrast -> DetectedScene.HIGH_CONTRAST
            else -> DetectedScene.BALANCED_DAYLIGHT
        }
        val iso = when {
            average < 0.15f -> 1600
            average < 0.3f -> 800
            average < 0.6f -> 200
            else -> 100
        }
        val shutter = when {
            average < 0.15f -> "1/15s"
            average < 0.3f -> "1/60s"
            average < 0.6f -> "1/250s"
            else -> "1/1000s"
        }
        return SceneAnalysisResult(
            luminance = average,
            dynamicRangeEstimate = robustRange,
            detectedScene = scene,
            suggestedIso = iso,
            suggestedShutterSpeed = shutter,
            suggestsFlash = average < 0.18f,
            suggestsHdr = isHighContrast,
            suggestsNightMode = isLowLight,
            colorTemperatureKelvin = 5500
        )
    }

    /**
     * Real analysis of preview frames / downscaled capture to determine real luminance,
     * dynamic range distribution, and scene recommendation.
     */
    fun analyzeBitmap(sample: Bitmap): SceneAnalysisResult {
        val width = sample.width
        val height = sample.height
        val stepX = (width / 32).coerceAtLeast(1)
        val stepY = (height / 32).coerceAtLeast(1)

        var totalLum = 0.0
        var minLum = 1.0f
        var maxLum = 0.0f
        var samplesCount = 0

        var sumRed = 0.0
        var sumBlue = 0.0

        for (y in 0 until height step stepY) {
            for (x in 0 until width step stepX) {
                val pixel = sample.getPixel(x, y)
                val r = Color.red(pixel) / 255.0f
                val g = Color.green(pixel) / 255.0f
                val b = Color.blue(pixel) / 255.0f

                val lum = 0.299f * r + 0.587f * g + 0.114f * b
                totalLum += lum
                if (lum < minLum) minLum = lum
                if (lum > maxLum) maxLum = lum

                sumRed += r
                sumBlue += b
                samplesCount++
            }
        }

        val avgLum = if (samplesCount > 0) (totalLum / samplesCount).toFloat() else 0.5f
        val dynamicRange = (maxLum - minLum).coerceIn(0f, 1f)

        val redRatio = if (samplesCount > 0) sumRed / samplesCount else 0.5
        val blueRatio = if (samplesCount > 0) sumBlue / samplesCount else 0.5
        val tempKelvin = (5500 + (blueRatio - redRatio) * 3500).toInt().coerceIn(2500, 8500)

        val isLowLight = avgLum < 0.25f
        val isHighContrast = dynamicRange > 0.75f && avgLum in 0.3f..0.7f

        val scene = when {
            isLowLight -> DetectedScene.LOW_LIGHT
            isHighContrast -> DetectedScene.HIGH_CONTRAST
            tempKelvin < 4000 -> DetectedScene.INDOOR_WARM
            else -> DetectedScene.BALANCED_DAYLIGHT
        }

        val suggestedIso = when {
            avgLum < 0.15f -> 1600
            avgLum < 0.3f -> 800
            avgLum < 0.6f -> 200
            else -> 100
        }

        val suggestedShutter = when {
            avgLum < 0.15f -> "1/15s"
            avgLum < 0.3f -> "1/60s"
            avgLum < 0.6f -> "1/250s"
            else -> "1/1000s"
        }

        return SceneAnalysisResult(
            luminance = avgLum,
            dynamicRangeEstimate = dynamicRange,
            detectedScene = scene,
            suggestedIso = suggestedIso,
            suggestedShutterSpeed = suggestedShutter,
            suggestsFlash = avgLum < 0.18f,
            suggestsHdr = isHighContrast,
            suggestsNightMode = isLowLight,
            colorTemperatureKelvin = tempKelvin
        )
    }
}
