package com.example.engine

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Conservative parallax-aware refinement for the local HDR motion field.
 * This is a classical image-space approximation, not metric depth estimation.
 * It stabilizes vectors inside locally similar surfaces while preserving motion
 * discontinuities at strong image edges (where foreground/background parallax
 * boundaries are most likely to occur).
 */
object ParallaxCorrection {
    private const val ANALYSIS_MAX = 96
    private const val EDGE_THRESHOLD = 0.075f
    private const val LUMA_SIMILARITY = 0.13f
    private const val MAX_CORRECTION = 8f

    fun refine(reference: Bitmap, flow: OpticalFlowAlignment.FlowField): OpticalFlowAlignment.FlowField {
        require(!reference.isRecycled && reference.width > 0 && reference.height > 0) {
            "Parallax reference must be a valid bitmap"
        }
        require(flow.columns >= 2 && flow.rows >= 2)
        val width = min(ANALYSIS_MAX, reference.width).coerceAtLeast(3)
        val height = min(ANALYSIS_MAX, reference.height).coerceAtLeast(3)
        val scaled = Bitmap.createScaledBitmap(reference, width, height, true)
        try {
            val pixels = IntArray(width * height)
            scaled.getPixels(pixels, 0, width, 0, 0, width, height)
            val luma = FloatArray(pixels.size) { i ->
                val c = pixels[i]
                (0.2126f * ((c shr 16) and 255) + 0.7152f * ((c shr 8) and 255) +
                    0.0722f * (c and 255)) / 255f
            }
            val outX = flow.dx.copyOf()
            val outY = flow.dy.copyOf()
            val cellLuma = FloatArray(flow.columns * flow.rows)
            val cellEdge = FloatArray(cellLuma.size)
            for (gy in 0 until flow.rows) for (gx in 0 until flow.columns) {
                val px = (((gx + 0.5f) / flow.columns) * width).toInt().coerceIn(1, width - 2)
                val py = (((gy + 0.5f) / flow.rows) * height).toInt().coerceIn(1, height - 2)
                val i = gy * flow.columns + gx
                val p = py * width + px
                cellLuma[i] = luma[p]
                cellEdge[i] = (abs(luma[p + 1] - luma[p - 1]) +
                    abs(luma[p + width] - luma[p - width])) * 0.5f
            }

            for (gy in 0 until flow.rows) for (gx in 0 until flow.columns) {
                val index = gy * flow.columns + gx
                if (!flow.reliable[index]) continue
                val xs = ArrayList<Float>(9)
                val ys = ArrayList<Float>(9)
                for (oy in -1..1) for (ox in -1..1) {
                    val nx = gx + ox
                    val ny = gy + oy
                    if (nx !in 0 until flow.columns || ny !in 0 until flow.rows) continue
                    val ni = ny * flow.columns + nx
                    if (!flow.reliable[ni]) continue
                    // Do not smooth vectors across a likely foreground/background edge.
                    if (abs(cellLuma[index] - cellLuma[ni]) > LUMA_SIMILARITY) continue
                    if (max(cellEdge[index], cellEdge[ni]) > EDGE_THRESHOLD &&
                        abs(cellEdge[index] - cellEdge[ni]) > EDGE_THRESHOLD * 0.5f) continue
                    xs.add(flow.dx[ni]); ys.add(flow.dy[ni])
                }
                if (xs.size < 3) continue
                xs.sort(); ys.sort()
                val medianX = xs[xs.size / 2]
                val medianY = ys[ys.size / 2]
                // A bounded, conservative correction avoids flattening real depth motion.
                val deltaX = (medianX - flow.dx[index]).coerceIn(-MAX_CORRECTION, MAX_CORRECTION)
                val deltaY = (medianY - flow.dy[index]).coerceIn(-MAX_CORRECTION, MAX_CORRECTION)
                outX[index] = flow.dx[index] + deltaX * 0.35f
                outY[index] = flow.dy[index] + deltaY * 0.35f
            }
            return OpticalFlowAlignment.FlowField(
                flow.columns, flow.rows, flow.imageWidth, flow.imageHeight,
                outX, outY, flow.reliable.copyOf(), flow.reliableCellRatio
            )
        } finally {
            if (scaled !== reference && !scaled.isRecycled) scaled.recycle()
        }
    }
}
