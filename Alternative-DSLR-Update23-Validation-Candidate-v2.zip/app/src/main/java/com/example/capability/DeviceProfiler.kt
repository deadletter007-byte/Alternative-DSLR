package com.example.capability

import android.app.ActivityManager
import android.content.Context
import android.graphics.ImageFormat
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata
import android.os.Build
import android.os.PowerManager
import android.util.Log

object DeviceProfiler {
    private const val TAG = "DeviceProfiler"

    fun inspectDevice(context: Context): HardwareCapabilities {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        am?.getMemoryInfo(memInfo)

        val totalRamMb = memInfo.totalMem / (1024 * 1024)
        val availRamMb = memInfo.availMem / (1024 * 1024)

        val cpuArch = Build.SUPPORTED_ABIS.firstOrNull() ?: "Unknown"
        val cpuCores = Runtime.getRuntime().availableProcessors()

        val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
        var bestHardwareLevel = CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_LEGACY
        var hasRaw = false
        var hasManualExp = false
        var hasManualFocus = false
        var hasFlash = false
        var minEv = -4
        var maxEv = 4
        var evStep = 0.5f
        var minIso = 50
        var maxIso = 3200
        var minShutterNs = 100_000L // 1/10000s
        var maxShutterNs = 1_000_000_000L // 1s
        val afModes = mutableListOf<String>()
        val awbModes = mutableListOf<String>()
        val detectedLenses = mutableListOf<LensSpec>()

        if (cameraManager != null) {
            try {
                for (cameraId in cameraManager.cameraIdList) {
                    val chars = cameraManager.getCameraCharacteristics(cameraId)
                    val facing = chars.get(CameraCharacteristics.LENS_FACING)
                    val facingStr = when (facing) {
                        CameraCharacteristics.LENS_FACING_FRONT -> "Front"
                        CameraCharacteristics.LENS_FACING_BACK -> "Back"
                        else -> "External"
                    }

                    val level = chars.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL)
                        ?: CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_LEGACY
                    if (level > bestHardwareLevel) {
                        bestHardwareLevel = level
                    }

                    val capabilities = chars.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES) ?: intArrayOf()
                    val lensRaw = capabilities.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_RAW)
                    if (lensRaw) hasRaw = true
                    if (capabilities.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR)) {
                        hasManualExp = true
                    }
                    if (capabilities.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_POST_PROCESSING)) {
                        hasManualFocus = true
                    }

                    val flashAvailable = chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) ?: false
                    if (flashAvailable) hasFlash = true

                    val focalLengths = chars.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.toList()
                        ?: listOf(26f)
                    val apertures = chars.get(CameraCharacteristics.LENS_INFO_AVAILABLE_APERTURES)?.toList()
                        ?: listOf(1.8f)

                    // Sensor resolution
                    val map = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
                    val sizes = map?.getOutputSizes(ImageFormat.JPEG) ?: emptyArray()
                    val maxResolutionMp = if (sizes.isNotEmpty()) {
                        val maxPixels = sizes.maxOf { it.width.toLong() * it.height.toLong() }
                        maxPixels / 1_000_000f
                    } else {
                        12f
                    }

                    val isLogical = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                        capabilities.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_LOGICAL_MULTI_CAMERA)
                    } else false

                    val physicalIds = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                        chars.physicalCameraIds.toList()
                    } else emptyList()

                    detectedLenses.add(
                        LensSpec(
                            id = cameraId,
                            facing = facingStr,
                            focalLengthsMm = focalLengths,
                            apertures = apertures,
                            maxResolutionMegapixels = maxResolutionMp,
                            supportsRaw = lensRaw,
                            isLogicalMultiCamera = isLogical,
                            physicalCameraIds = physicalIds
                        )
                    )

                    // Inspect EV & Ranges for primary rear sensor
                    if (facing == CameraCharacteristics.LENS_FACING_BACK || detectedLenses.size == 1) {
                        val evRange = chars.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE)
                        if (evRange != null) {
                            minEv = evRange.lower
                            maxEv = evRange.upper
                        }
                        val step = chars.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP)
                        if (step != null) {
                            evStep = step.numerator.toFloat() / step.denominator.toFloat()
                        }

                        val isoR = chars.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)
                        if (isoR != null) {
                            minIso = isoR.lower
                            maxIso = isoR.upper
                        }

                        val expR = chars.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)
                        if (expR != null) {
                            minShutterNs = expR.lower
                            maxShutterNs = expR.upper
                        }

                        chars.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES)?.forEach { mode ->
                            val modeName = when (mode) {
                                CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_PICTURE -> "Continuous"
                                CameraMetadata.CONTROL_AF_MODE_AUTO -> "Auto"
                                CameraMetadata.CONTROL_AF_MODE_MACRO -> "Macro"
                                CameraMetadata.CONTROL_AF_MODE_OFF -> "Manual"
                                else -> "Mode $mode"
                            }
                            if (!afModes.contains(modeName)) afModes.add(modeName)
                        }

                        chars.get(CameraCharacteristics.CONTROL_AWB_AVAILABLE_MODES)?.forEach { mode ->
                            val modeName = when (mode) {
                                CameraMetadata.CONTROL_AWB_MODE_AUTO -> "Auto"
                                CameraMetadata.CONTROL_AWB_MODE_DAYLIGHT -> "Daylight"
                                CameraMetadata.CONTROL_AWB_MODE_CLOUDY_DAYLIGHT -> "Cloudy"
                                CameraMetadata.CONTROL_AWB_MODE_SHADE -> "Shade"
                                CameraMetadata.CONTROL_AWB_MODE_INCANDESCENT -> "Tungsten"
                                CameraMetadata.CONTROL_AWB_MODE_FLUORESCENT -> "Fluorescent"
                                else -> "AWB $mode"
                            }
                            if (!awbModes.contains(modeName)) awbModes.add(modeName)
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error inspecting cameras", e)
            }
        }

        val hwLevelName = when (bestHardwareLevel) {
            CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_3 -> "Level 3 (Pro Flagship)"
            CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_FULL -> "Full (Advanced Manual)"
            CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_LIMITED -> "Limited (Standard)"
            CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_LEGACY -> "Legacy (Basic)"
            else -> "External / Unknown"
        }

        // Determine recommended profile according to section 3 rules:
        val recommendedProfile = when {
            totalRamMb >= 10000 && bestHardwareLevel >= CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_FULL ->
                ProcessingProfile.MAXIMUM_QUALITY
            totalRamMb >= 6000 && (bestHardwareLevel >= CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_FULL || hasRaw) ->
                ProcessingProfile.ADVANCED
            totalRamMb >= 3500 ->
                ProcessingProfile.BALANCED
            else ->
                ProcessingProfile.LITE
        }

        val thermalStatus = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
            when (pm?.currentThermalStatus) {
                PowerManager.THERMAL_STATUS_NONE -> "Nominal"
                PowerManager.THERMAL_STATUS_LIGHT -> "Light Warmth"
                PowerManager.THERMAL_STATUS_MODERATE -> "Moderate"
                PowerManager.THERMAL_STATUS_SEVERE -> "Severe (Throttling)"
                PowerManager.THERMAL_STATUS_CRITICAL -> "Critical"
                PowerManager.THERMAL_STATUS_EMERGENCY -> "Emergency"
                PowerManager.THERMAL_STATUS_SHUTDOWN -> "Thermal Shutdown"
                else -> "Normal"
            }
        } else {
            "Normal"
        }

        return HardwareCapabilities(
            androidVersion = "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
            apiLevel = Build.VERSION.SDK_INT,
            cpuArch = cpuArch,
            cpuCores = cpuCores,
            totalRamMb = totalRamMb,
            availableRamMb = availRamMb,
            hardwareLevelName = hwLevelName,
            cameraHardwareLevel = bestHardwareLevel,
            supportsRawCapture = hasRaw,
            supportsManualExposure = hasManualExp || bestHardwareLevel >= CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_LIMITED,
            supportsManualFocus = hasManualFocus || bestHardwareLevel >= CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_LIMITED,
            supportsFlash = hasFlash,
            exposureCompensationRange = Pair(minEv, maxEv),
            exposureCompensationStep = evStep,
            isoRange = Pair(minIso, maxIso),
            exposureTimeRangeNs = Pair(minShutterNs, maxShutterNs),
            supportedAfModes = afModes.ifEmpty { listOf("Continuous", "Auto", "Manual") },
            supportedAwbModes = awbModes.ifEmpty { listOf("Auto", "Daylight", "Cloudy", "Tungsten") },
            lenses = detectedLenses.ifEmpty {
                listOf(
                    LensSpec(
                        id = "0",
                        facing = "Back",
                        focalLengthsMm = listOf(24.0f),
                        apertures = listOf(1.8f),
                        maxResolutionMegapixels = 12.0f,
                        supportsRaw = false,
                        isLogicalMultiCamera = false,
                        physicalCameraIds = emptyList()
                    )
                )
            },
            recommendedProfile = recommendedProfile,
            thermalStatus = thermalStatus
        )
    }
}
