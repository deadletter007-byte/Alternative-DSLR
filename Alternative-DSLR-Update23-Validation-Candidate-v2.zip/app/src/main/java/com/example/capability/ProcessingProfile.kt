package com.example.capability

/**
 * The four adaptive processing profiles specified in the Alternative DSLR architecture.
 */
enum class ProcessingProfile(
    val title: String,
    val subtitle: String,
    val description: String,
    val burstFrameCount: Int,
    val supportsSuperRes: Boolean,
    val supportsDeepBokeh: Boolean,
    val bitDepth: Int
) {
    LITE(
        title = "Lite Mode",
        subtitle = "Fast single-frame capture",
        description = "Optimized for entry-level devices. Rapid low-latency capture with minimal thermal and memory overhead.",
        burstFrameCount = 1,
        supportsSuperRes = false,
        supportsDeepBokeh = false,
        bitDepth = 8
    ),
    BALANCED(
        title = "Balanced Mode",
        subtitle = "Multi-frame HDR + Tone Mapping",
        description = "Balanced fidelity and processing speed. Combines 3 bracketed frames with noise reduction and natural color tuning.",
        burstFrameCount = 3,
        supportsSuperRes = true,
        supportsDeepBokeh = true,
        bitDepth = 10
    ),
    ADVANCED(
        title = "Advanced Mode",
        subtitle = "High-Dynamic Fusion & Portrait Depth",
        description = "Designed for powerful devices. 6-frame multi-exposure fusion, neural edge preservation, and DSLR-style bokeh rendering.",
        burstFrameCount = 6,
        supportsSuperRes = true,
        supportsDeepBokeh = true,
        bitDepth = 12
    ),
    MAXIMUM_QUALITY(
        title = "Maximum Quality",
        subtitle = "Flagship RAW Stack & 200MP Reconstruction",
        description = "Flagship computational photography engine. Multi-frame RAW alignment, zero plastic smoothing, tiled 200MP reconstruction.",
        burstFrameCount = 10,
        supportsSuperRes = true,
        supportsDeepBokeh = true,
        bitDepth = 14
    )
}
