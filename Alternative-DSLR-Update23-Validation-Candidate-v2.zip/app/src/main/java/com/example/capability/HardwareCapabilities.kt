package com.example.capability

data class LensSpec(
    val id: String,
    val facing: String, // "Back" or "Front"
    val focalLengthsMm: List<Float>,
    val apertures: List<Float>,
    val maxResolutionMegapixels: Float,
    val supportsRaw: Boolean,
    val isLogicalMultiCamera: Boolean,
    val physicalCameraIds: List<String>
)

data class HardwareCapabilities(
    val androidVersion: String,
    val apiLevel: Int,
    val cpuArch: String,
    val cpuCores: Int,
    val totalRamMb: Long,
    val availableRamMb: Long,
    val hardwareLevelName: String,
    val cameraHardwareLevel: Int, // e.g. CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_FULL
    val supportsRawCapture: Boolean,
    val supportsManualExposure: Boolean,
    val supportsManualFocus: Boolean,
    val supportsFlash: Boolean,
    val exposureCompensationRange: Pair<Int, Int>, // min to max
    val exposureCompensationStep: Float,
    val isoRange: Pair<Int, Int>,
    val exposureTimeRangeNs: Pair<Long, Long>,
    val supportedAfModes: List<String>,
    val supportedAwbModes: List<String>,
    val lenses: List<LensSpec>,
    val recommendedProfile: ProcessingProfile,
    val thermalStatus: String
)
