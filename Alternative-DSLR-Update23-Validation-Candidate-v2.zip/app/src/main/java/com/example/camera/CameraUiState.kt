package com.example.camera

import android.net.Uri
import androidx.camera.core.ImageCapture
import com.example.ai.CloudAiCritique
import com.example.capability.HardwareCapabilities
import com.example.capability.ProcessingProfile
import com.example.engine.SceneAnalysisResult
import com.example.gallery.CapturedMediaItem
import com.example.settings.AiProcessingMode
import com.example.settings.ColorScienceProfile

data class CameraUiState(
    val activeScreen: ActiveScreen = ActiveScreen.CAMERA,
    val selectedMode: CameraMode = CameraMode.AUTO,
    val isBackCamera: Boolean = true,
    val zoomRatio: Float = 1.0f,
    val maxZoomRatio: Float = 8.0f,
    val minZoomRatio: Float = 0.6f,

    // Optics & Simulation
    val virtualLens: VirtualLens? = null,
    val virtualAperture: VirtualAperture = VirtualAperture.F8_0,

    // Adaptive Processing & AI
    val currentProfile: ProcessingProfile = ProcessingProfile.BALANCED,
    val isAutoProfile: Boolean = true,
    val aiProcessingMode: AiProcessingMode = AiProcessingMode.HYBRID,
    val colorProfile: ColorScienceProfile = ColorScienceProfile.NATURAL,
    val targetSuperResMegapixels: Int = 24, // 24, 100, 200

    // Face & Eye Tracking
    val faceTrackingState: FaceTrackingState = FaceTrackingState(),
    val isFaceTrackingEnabled: Boolean = true,

    // Pro / Manual Parameters
    val isManualIso: Boolean = false,
    val manualIso: Int = 100,
    val isManualShutter: Boolean = false,
    val manualShutterSpeed: String = "1/250s",
    val isManualFocus: Boolean = false,
    val manualFocusDistance: Float = 0.0f, // 0.0 infinity to 1.0 close
    val isManualWb: Boolean = false,
    val whiteBalanceKelvin: Int = 5500,
    val evCompensation: Int = 0,
    val isAeLocked: Boolean = false,
    val isAfLocked: Boolean = false,
    val isRawCaptureEnabled: Boolean = false,

    // Hardware Controls
    val flashMode: Int = ImageCapture.FLASH_MODE_OFF,
    val isRecordingVideo: Boolean = false,
    val videoDurationSeconds: Int = 0,
    val isCapturing: Boolean = false,
    val processingProgress: Float = 0f,
    val processingStatusDetail: String? = null,
    val timerSeconds: Int = 0, // 0 = off, 3, 5, 10
    val countdownRemaining: Int = 0,

    // Viewfinder Overlays
    val showGrid: Boolean = true,
    val gridType: GridType = GridType.RULE_OF_THIRDS,
    val showHorizonLevel: Boolean = true,
    val showHistogram: Boolean = true,
    val showFocusPeaking: Boolean = false,
    val showZebraWarning: Boolean = false,
    val rollDegrees: Float = 0.0f,
    val pitchDegrees: Float = 0.0f,

    // Real-time Telemetry
    val histogramLuminance: FloatArray = FloatArray(32) { 0.1f },
    val liveScene: SceneAnalysisResult? = null,
    val cloudCritique: CloudAiCritique? = null,
    val lastCapturedItem: CapturedMediaItem? = null,
    val selectedMediaDetail: CapturedMediaItem? = null,
    val photoEditorItem: CapturedMediaItem? = null,

    // Hardware Capabilities Info
    val capabilities: HardwareCapabilities? = null,
    val lastStatusMessage: String? = null
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as CameraUiState

        if (activeScreen != other.activeScreen) return false
        if (selectedMode != other.selectedMode) return false
        if (isBackCamera != other.isBackCamera) return false
        if (zoomRatio != other.zoomRatio) return false
        if (virtualLens != other.virtualLens) return false
        if (virtualAperture != other.virtualAperture) return false
        if (currentProfile != other.currentProfile) return false
        if (aiProcessingMode != other.aiProcessingMode) return false
        if (colorProfile != other.colorProfile) return false
        if (targetSuperResMegapixels != other.targetSuperResMegapixels) return false
        if (faceTrackingState != other.faceTrackingState) return false
        if (isFaceTrackingEnabled != other.isFaceTrackingEnabled) return false
        if (isManualIso != other.isManualIso) return false
        if (manualIso != other.manualIso) return false
        if (isManualShutter != other.isManualShutter) return false
        if (manualShutterSpeed != other.manualShutterSpeed) return false
        if (isManualFocus != other.isManualFocus) return false
        if (manualFocusDistance != other.manualFocusDistance) return false
        if (isManualWb != other.isManualWb) return false
        if (whiteBalanceKelvin != other.whiteBalanceKelvin) return false
        if (evCompensation != other.evCompensation) return false
        if (isAeLocked != other.isAeLocked) return false
        if (isAfLocked != other.isAfLocked) return false
        if (isRawCaptureEnabled != other.isRawCaptureEnabled) return false
        if (flashMode != other.flashMode) return false
        if (isRecordingVideo != other.isRecordingVideo) return false
        if (videoDurationSeconds != other.videoDurationSeconds) return false
        if (isCapturing != other.isCapturing) return false
        if (processingProgress != other.processingProgress) return false
        if (processingStatusDetail != other.processingStatusDetail) return false
        if (timerSeconds != other.timerSeconds) return false
        if (countdownRemaining != other.countdownRemaining) return false
        if (showGrid != other.showGrid) return false
        if (gridType != other.gridType) return false
        if (showHorizonLevel != other.showHorizonLevel) return false
        if (showHistogram != other.showHistogram) return false
        if (showFocusPeaking != other.showFocusPeaking) return false
        if (showZebraWarning != other.showZebraWarning) return false
        if (rollDegrees != other.rollDegrees) return false
        if (pitchDegrees != other.pitchDegrees) return false
        if (!histogramLuminance.contentEquals(other.histogramLuminance)) return false
        if (liveScene != other.liveScene) return false
        if (cloudCritique != other.cloudCritique) return false
        if (lastCapturedItem != other.lastCapturedItem) return false
        if (selectedMediaDetail != other.selectedMediaDetail) return false
        if (photoEditorItem != other.photoEditorItem) return false
        if (capabilities != other.capabilities) return false
        if (lastStatusMessage != other.lastStatusMessage) return false

        return true
    }

    override fun hashCode(): Int {
        var result = activeScreen.hashCode()
        result = 31 * result + selectedMode.hashCode()
        result = 31 * result + isBackCamera.hashCode()
        result = 31 * result + zoomRatio.hashCode()
        result = 31 * result + (virtualLens?.hashCode() ?: 0)
        result = 31 * result + virtualAperture.hashCode()
        result = 31 * result + currentProfile.hashCode()
        result = 31 * result + aiProcessingMode.hashCode()
        result = 31 * result + colorProfile.hashCode()
        result = 31 * result + targetSuperResMegapixels
        result = 31 * result + faceTrackingState.hashCode()
        result = 31 * result + isFaceTrackingEnabled.hashCode()
        result = 31 * result + isManualIso.hashCode()
        result = 31 * result + manualIso
        result = 31 * result + isManualShutter.hashCode()
        result = 31 * result + manualShutterSpeed.hashCode()
        result = 31 * result + isManualFocus.hashCode()
        result = 31 * result + manualFocusDistance.hashCode()
        result = 31 * result + isManualWb.hashCode()
        result = 31 * result + whiteBalanceKelvin
        result = 31 * result + evCompensation
        result = 31 * result + isAeLocked.hashCode()
        result = 31 * result + isAfLocked.hashCode()
        result = 31 * result + isRawCaptureEnabled.hashCode()
        result = 31 * result + flashMode
        result = 31 * result + isRecordingVideo.hashCode()
        result = 31 * result + videoDurationSeconds
        result = 31 * result + isCapturing.hashCode()
        result = 31 * result + processingProgress.hashCode()
        result = 31 * result + (processingStatusDetail?.hashCode() ?: 0)
        result = 31 * result + timerSeconds
        result = 31 * result + countdownRemaining
        result = 31 * result + showGrid.hashCode()
        result = 31 * result + gridType.hashCode()
        result = 31 * result + showHorizonLevel.hashCode()
        result = 31 * result + showHistogram.hashCode()
        result = 31 * result + showFocusPeaking.hashCode()
        result = 31 * result + showZebraWarning.hashCode()
        result = 31 * result + rollDegrees.hashCode()
        result = 31 * result + pitchDegrees.hashCode()
        result = 31 * result + histogramLuminance.contentHashCode()
        result = 31 * result + (liveScene?.hashCode() ?: 0)
        result = 31 * result + (cloudCritique?.hashCode() ?: 0)
        result = 31 * result + (lastCapturedItem?.hashCode() ?: 0)
        result = 31 * result + (selectedMediaDetail?.hashCode() ?: 0)
        result = 31 * result + (photoEditorItem?.hashCode() ?: 0)
        result = 31 * result + (capabilities?.hashCode() ?: 0)
        result = 31 * result + (lastStatusMessage?.hashCode() ?: 0)
        return result
    }
}
