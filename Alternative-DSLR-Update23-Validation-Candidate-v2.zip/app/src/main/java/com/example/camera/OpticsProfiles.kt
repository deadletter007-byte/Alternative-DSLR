package com.example.camera

enum class VirtualLens(
    val focalLengthMm: Int,
    val label: String,
    val character: String,
    val zoomFactor: Float
) {
    LENS_70MM(70, "70mm", "Virtual framing simulation", 2.2f),
    LENS_85MM(85, "85mm", "Virtual framing simulation", 2.7f),
    LENS_105MM(105, "105mm", "Virtual framing simulation", 3.3f),
    LENS_135MM(135, "135mm", "Virtual framing simulation", 4.2f),
    LENS_200MM(200, "200mm", "Virtual framing simulation", 6.2f)
}

enum class VirtualAperture(
    val fNumber: Float,
    val label: String,
    val blurRadiusMultiplier: Float
) {
    F1_2(1.2f, "f/1.2", 1.0f),
    F1_4(1.4f, "f/1.4", 0.85f),
    F1_8(1.8f, "f/1.8", 0.65f),
    F2_0(2.0f, "f/2.0", 0.5f),
    F2_8(2.8f, "f/2.8", 0.35f),
    F4_0(4.0f, "f/4.0", 0.2f),
    F5_6(5.6f, "f/5.6", 0.1f),
    F8_0(8.0f, "f/8.0", 0.03f)
}
