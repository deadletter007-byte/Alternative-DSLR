package com.example.camera

enum class CameraMode(
    val title: String,
    val description: String,
    val isVideo: Boolean,
    val isComputational: Boolean,
    val isPro: Boolean
) {
    AUTO(
        title = "AUTO",
        description = "Intelligent scene evaluation, auto exposure, white balance & dynamic range",
        isVideo = false,
        isComputational = false,
        isPro = false
    ),
    PRO(
        title = "PRO",
        description = "Full manual DSLR controls: ISO, Shutter, Kelvin WB, EV, Manual Focus & RAW",
        isVideo = false,
        isComputational = false,
        isPro = true
    ),
    PORTRAIT(
        title = "PORTRAIT",
        description = "DSLR aperture simulation (f/1.2 - f/8) with virtual lenses (70-200mm) & fine bokeh",
        isVideo = false,
        isComputational = true,
        isPro = false
    ),
    NIGHT(
        title = "NIGHT",
        description = "Computational low-light multi-frame alignment & noise reduction without glow",
        isVideo = false,
        isComputational = true,
        isPro = false
    ),
    PHOTO(
        title = "PHOTO",
        description = "Standard single-shot high-fidelity capture preserving natural skin and textures",
        isVideo = false,
        isComputational = false,
        isPro = false
    ),
    VIDEO(
        title = "VIDEO",
        description = "High definition video recording with stabilization and low-latency audio",
        isVideo = true,
        isComputational = false,
        isPro = false
    ),
    PRO_VIDEO(
        title = "PRO VIDEO",
        description = "Manual video recording with AE/AF locks, manual audio level, and Kelvin WB",
        isVideo = true,
        isComputational = false,
        isPro = true
    ),
    MACRO(
        title = "MACRO",
        description = "Close-up optical focus with micro-texture sharpness enhancement",
        isVideo = false,
        isComputational = true,
        isPro = false
    ),
    PANORAMA(
        title = "PANO",
        description = "Computational wide-angle frame stitching with horizon leveling",
        isVideo = false,
        isComputational = true,
        isPro = false
    ),
    SLOW_MOTION(
        title = "SLOW-MO",
        description = "High frame-rate capture with smooth optical playback interpolation",
        isVideo = true,
        isComputational = false,
        isPro = false
    ),
    TIME_LAPSE(
        title = "TIME-LAPSE",
        description = "Intervalometer shooting with automatic day-to-night exposure ramping",
        isVideo = true,
        isComputational = true,
        isPro = false
    ),
    HYPERLAPSE(
        title = "HYPERLAPSE",
        description = "Motion-stabilized interval recording for walking and vehicle perspectives",
        isVideo = true,
        isComputational = true,
        isPro = false
    ),
    HIGH_RES(
        title = "HIGH RES",
        description = "Sensor-maximum capture with optional 200MP computational reconstruction pipeline",
        isVideo = false,
        isComputational = true,
        isPro = false
    ),
    HDR(
        title = "HDR",
        description = "Multi-exposure bracketed fusion preserving shadow details & highlight rolloff",
        isVideo = false,
        isComputational = true,
        isPro = false
    ),
    DOCUMENT(
        title = "DOCUMENT",
        description = "Contrast-enhanced document capture with perspective flattening",
        isVideo = false,
        isComputational = true,
        isPro = false
    ),
    FOOD(
        title = "FOOD",
        description = "Warm color gamut tuning and subtle micro-contrast food photography",
        isVideo = false,
        isComputational = true,
        isPro = false
    ),
    LANDSCAPE(
        title = "LANDSCAPE",
        description = "Deep depth of field tuning, foliage clarity, and atmospheric haze reduction",
        isVideo = false,
        isComputational = true,
        isPro = false
    )
}
