# HDR Update 21: Quality Validation Pipeline Integration

## কী পরিবর্তন হয়েছে
- `HdrFusion.alignAndFuse(input)`-এর আগের API অক্ষুণ্ণ রাখা হয়েছে।
- নতুন overload `alignAndFuse(input, onValidation)` যোগ করা হয়েছে।
- HDR fusion-এর সবশেষ image processing শেষ হলে `HdrQualityValidation.inspect(output)` চালানো হয়।
- `MainViewModel` validation result গ্রহণ করে Android Log-এ pass বা warning লিখে।
- Validation warning থাকলেও ছবি বাতিল বা পরিবর্তন করা হয় না। কারণ low-key/high-key দৃশ্য স্বাভাবিকভাবেই কিছু threshold অতিক্রম করতে পারে।

## সীমাবদ্ধতা
- এটি basic luminance/clipping sanity check; perceptual image-quality score, reference comparison বা camera sensor validation নয়।
- Android Gradle build এবং Robolectric test এই পরিবেশে চালানো হয়নি।
- Gradle wrapper-এর properties file আছে, কিন্তু wrapper JAR এবং `gradlew` scripts মূল project-এ অনুপস্থিত। এগুলো নির্ভরযোগ্য মূল project থেকে না পেয়ে বানিয়ে যোগ করা হয়নি।

## পরবর্তী প্রয়োজনীয় পদক্ষেপ
সম্পূর্ণ build চালাতে মূল Android Studio/GitHub project থেকে `gradle/wrapper/gradle-wrapper.jar`, `gradlew` এবং `gradlew.bat` পুনরুদ্ধার করতে হবে, অথবা Android Studio-তে installed Gradle দিয়ে project sync/build করতে হবে।
