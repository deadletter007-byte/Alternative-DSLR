# Alternative DSLR — Software-First Update 23

## মূল নীতি
Alternative DSLR হবে Software-First Computational Photography Camera। হার্ডওয়্যার সুবিধা থাকলে native capture path ব্যবহার করবে; না থাকলে বাস্তবসম্মত software fallback চেষ্টা করবে। কোনো fallback-কে hardware capability বা প্রকৃত sensor data হিসেবে দেখানো যাবে না।

## HDR fallback আচরণ
1. EV bracketing পাওয়া গেলে তিনটি আলাদা exposure capture করে multi-frame HDR fusion চালানো হবে।
2. EV bracketing না থাকলে একই exposure-এ তিনটি JPEG burst capture করা হবে।
3. Burst frames-এর একই মাপের pixel-এ temporal consistency পরীক্ষা করে স্থির অঞ্চলের sample গড় করা হবে। অমিল/চলমান অঞ্চলে reference frame রাখা হবে।
4. এই fallback noise কমাতে ও স্থির texture কিছুটা পরিষ্কার করতে পারে; এটি dynamic range বাড়ায় না এবং clipped highlight/shadow ফিরিয়ে আনে না।
5. Burst capture ব্যর্থ হলে single-frame software HDR-style tone mapping চলবে।

## অন্যান্য Software-First ফিচারের নিয়ম
- 100MP/200MP output reconstructed/upscaled হিসেবে চিহ্নিত হবে, native sensor resolution হিসেবে নয়।
- Digital zoom, portrait blur, stabilization, denoise ও detail reconstruction-এ সীমাবদ্ধতা মেনে graceful fallback থাকবে।
- কোনো feature ব্যর্থ হলে crash নয়, স্পষ্ট status message এবং নিকটতম কার্যকর বিকল্প ব্যবহার করতে হবে।
- AI মডেল/নেটওয়ার্ক না থাকলে local processing চলবে; cloud AI-কে বাধ্যতামূলক করা যাবে না।

## পরীক্ষার অবস্থা
Source integration করা হয়েছে। Android Gradle build, device capture, motion-scene ghosting এবং image-quality validation এখনো চালানো হয়নি।
