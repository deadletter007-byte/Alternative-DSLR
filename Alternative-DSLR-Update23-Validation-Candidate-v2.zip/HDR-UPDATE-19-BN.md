# HDR Update 19: Quality Validation (ধাপ ১০/১০)

এই আপডেটে `HdrQualityValidation` নামে একটি non-destructive sanity-check যোগ করা হয়েছে। `inspect(bitmap)` আউটপুটের width/height, গড় luminance, min/max luminance, near-white clipped pixel ratio এবং near-black pixel ratio পরিমাপ করে। নির্দিষ্ট সীমা অতিক্রম করলে warning দেয়।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
- এটি HDR গুণমানের চূড়ান্ত মানদণ্ড নয়; কেবল obvious output সমস্যা শনাক্ত করার প্রাথমিক পরীক্ষা।
- Reference image, SSIM/PSNR comparison, color-chart test, motion ghosting review এবং বাস্তব ক্যামেরা পরীক্ষা এর বিকল্প নয়।
- `HdrFusion.alignAndFuse()`-এর বিদ্যমান return type পরিবর্তন করা হয়নি। প্রয়োজন হলে caller output bitmap নিয়ে `HdrQualityValidation.inspect(result)` চালাতে পারবে।

## নতুন টেস্ট
- Balanced grayscale gradient-এ dimensions ও basic luminance report যাচাই।
- সম্পূর্ণ সাদা output-এ clipping warning যাচাই।

## Validation status
- ZIP integrity পরীক্ষা করা হবে।
- Android Gradle build এবং Robolectric test চালানো হয়নি/পরিবেশে সম্ভব না হলে তা স্পষ্টভাবে জানাতে হবে।
- Samsung Galaxy S21 Plus-এ real camera capture ও performance test এখনও প্রয়োজন।
