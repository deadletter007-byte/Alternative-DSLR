# Alternative DSLR — HDR Update 07

## এই আপডেটে
- HDR Fusion-এ full-frame `IntArray` copy বাদ দিয়ে 32-row tile ভিত্তিক Pixel Fusion যোগ করা হয়েছে।
- তিনটি bracket frame থেকে একসঙ্গে বিশাল aligned pixel array তৈরি করা হয় না; ফলে অতিরিক্ত working-memory কমে।
- Reference frame (0 EV) দিয়ে স্থানীয় luminance disagreement পরীক্ষা করে moving/unaligned অংশে reference exposure-কে অগ্রাধিকার দেওয়া হয়।
- Alignment analysis bitmap এবং size-mismatch working bitmap নিরাপদে recycle করা হয়; caller-এর মূল input bitmap recycle করা হয় না।
- Fusion ব্যর্থ হলে output bitmap recycle হয়।

## সীমাবদ্ধতা
- এটি global translation alignment; optical flow বা dense motion compensation নয়।
- Source JPEG bitmaps ও final output bitmap-এর নিজস্ব memory খরচ থেকেই যায়। খুব উচ্চ রেজোলিউশনে ডিভাইসের RAM সীমা গুরুত্বপূর্ণ।
- এই পরিবেশে Android Gradle build, Unit Test বা Samsung S21 Plus physical-device test চালানো হয়নি।
- Update 07-কে tested APK হিসেবে গণ্য করা যাবে না।
