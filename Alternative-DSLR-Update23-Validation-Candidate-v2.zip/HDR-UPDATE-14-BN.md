# Alternative DSLR — HDR Update 14

## ধাপ ৫/১০: Advanced Ghost Removal

### কী পরিবর্তন হয়েছে
- `GhostRemovalEngine.kt` যোগ করা হয়েছে।
- HDR fusion-এ non-reference exposure-এর contribution এখন reference-guided consistency ও motion mask দিয়ে নিয়ন্ত্রিত হয়।
- MotionDetectionEngine-এর dilated moving-region mask-এ non-reference frame-এর weight শূন্য করা হয়। ফলে ওই অঞ্চলে middle/reference exposure একাই ব্যবহৃত হয় এবং moving subject-এর দ্বৈত contour কমে।
- Static অঞ্চলে exposure fusion বজায় থাকে; মাঝারি/বড় luminance disagreement-এ candidate frame-এর weight ধাপে ধাপে কমে।
- আগের Optical Flow, Parallax refinement, Local Tone Mapping এবং tile-based bounded-memory processing অক্ষত রাখা হয়েছে।

### সীমাবদ্ধতা
- Ghost removal এখানে conservative reference-frame fallback। এটি AI object segmentation, semantic subject tracking বা pixel-perfect deghosting নয়।
- Reference frame-এ motion blur থাকলে সেটি নিজে থেকে দূর হবে না।
- খুব দ্রুত চলমান বস্তু, বড় camera movement, low texture, flicker বা rolling shutter-এ residual ghosting থাকতে পারে।
- Motion mask coarse grid-based হওয়ায় সূক্ষ্ম চুল/পাতার সীমানায় কিছু trade-off হতে পারে।

### যাচাই অবস্থা
- Source ZIP Update13 থেকে তৈরি।
- ZIP integrity পরীক্ষা করা হয়েছে।
- Kotlin/Android Gradle build ও S21 Plus বাস্তব ক্যামেরা পরীক্ষা এই পরিবেশে চালানো হয়নি; তাই APK build success দাবি করা হচ্ছে না।
