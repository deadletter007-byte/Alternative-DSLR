# HDR Update 17: Edge-aware Detail Preservation

## কী যুক্ত হয়েছে
- Natural Color Reconstruction-এর পরে `EdgeAwareDetailPreservation` pass যুক্ত হয়েছে।
- 3x3 Gaussian neighbourhood থেকে স্থানীয় luminance detail estimate করা হয়।
- Flat/সমান রঙের এলাকায় sharpening প্রায় বন্ধ থাকে, যাতে noise ও banding অযথা না বাড়ে।
- স্থানীয় contrast অনুযায়ী detail gain ধীরে বাড়ে; luminance পরিবর্তন সর্বোচ্চ সীমাবদ্ধ রাখা হয়েছে।
- RGB channel একই অনুপাতে scale করা হয়, তাই আলাদা channel sharpening-এর কারণে রঙের fringe তৈরির ঝুঁকি কমে।
- 32-row tile এবং এক-পিক্সেল halo ব্যবহার করা হয়েছে, যাতে tile boundary-তে দৃশ্যমান seam কমে এবং memory bounded থাকে।

## সীমাবদ্ধতা
- এটি edge-aware local detail enhancement; AI super-resolution বা হারানো texture পুনর্গঠন নয়।
- ইনপুটে না থাকা hair/skin/fabric detail তৈরি করতে পারে না।
- উচ্চ ISO noise, JPEG ringing বা motion blur থাকলে sharpening-এর আগে সেগুলো বিবেচনা করতে হবে।
- gain ইচ্ছাকৃতভাবে সংযত রাখা হয়েছে; বিভিন্ন resolution ও আলোতে S21 Plus-সহ বাস্তব ডিভাইসে tuning প্রয়োজন।

## Validation
- ZIP archive integrity পরীক্ষা করা হয়েছে।
- এই প্যাকেজে Android Gradle build, Kotlin compilation বা Samsung S21 Plus camera test চালানো হয়নি।
