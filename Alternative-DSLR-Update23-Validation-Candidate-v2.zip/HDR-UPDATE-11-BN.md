# Alternative DSLR — HDR Update 11

## ধাপ ২/১০: Advanced Motion Detection

এই আপডেটে HDR bracket frame-গুলোর মধ্যে স্থানীয় scene motion শনাক্ত করার একটি low-memory grid-based engine যোগ করা হয়েছে এবং HDR fusion-এ সেটি যুক্ত করা হয়েছে।

### পরিবর্তন
- `MotionDetectionEngine.kt` নতুন ফাইল। 48×36 পর্যন্ত analysis grid ব্যবহার করে।
- Reference ও bracket frame-এর global exposure difference median luminance ratio দিয়ে normalize করা হয়।
- Exposure normalize করার পর স্থানীয় luminance difference প্রায় 0.48 stop-এর বেশি হলে cell-কে moving হিসেবে চিহ্নিত করা হয়।
- Detection boundary-তে সামান্য dilation করা হয়, যাতে moving subject-এর কিনারায় ghosting কমে।
- `HdrFusion.kt`-এ alignment shift হিসাব করে motion map তৈরি করা হয়।
- Moving cell থেকে non-reference frame-এর fusion weight কমিয়ে 0.08 করা হয়; middle 0 EV reference frame অক্ষত থাকে।

### সীমাবদ্ধতা
- এটি grid-based motion detection; dense optical flow নয়।
- খুব ছোট/দ্রুত বস্তু, কম আলোতে noise, বড় parallax বা জটিল camera movement পুরোপুরি সামলাতে পারবে না।
- Sampling sparse হওয়ায় কিছু সূক্ষ্ম motion বাদ পড়তে পারে।
- Android Gradle build, unit tests ও Samsung S21 Plus device test এই পরিবেশে চালানো হয়নি।

### যাচাই
- Source integration ও archive integrity যাচাই করা হয়েছে।
- Gradle wrapper script/JAR এবং system Gradle অনুপস্থিত থাকায় Android compilation চালানো যায়নি।
