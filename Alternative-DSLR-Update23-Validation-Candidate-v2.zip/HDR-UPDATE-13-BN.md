# Alternative DSLR — HDR Update 13

## ধাপ ৪/১০: Parallax Correction

এই আপডেটে Optical Flow-এর local motion field-এর ওপর একটি conservative, edge-aware parallax refinement যুক্ত করা হয়েছে। HDR bracket-এর বিভিন্ন depth plane-এ সামান্য ভিন্ন displacement থাকলে একই global translation প্রয়োগের ঝুঁকি কমানোই এর উদ্দেশ্য।

### পরিবর্তন
- `ParallaxCorrection.kt` নতুন engine। Reference frame-এর সর্বোচ্চ 96×96 analysis image থেকে local luminance ও edge strength map তৈরি করে।
- Optical-flow grid-এর নির্ভরযোগ্য cell-গুলোকে শুধু কাছাকাছি luminance/edge বৈশিষ্ট্যের প্রতিবেশীর সঙ্গে তুলনা করা হয়।
- 3 বা তার বেশি উপযুক্ত প্রতিবেশী থাকলে median displacement-এর দিকে সর্বোচ্চ 35% এবং প্রতি vector component-এ সর্বোচ্চ 8 px bounded correction দেওয়া হয়।
- শক্তিশালী edge বা উল্লেখযোগ্য luminance discontinuity পার হয়ে vector smoothing করা হয় না, যাতে foreground/background boundary অতিরিক্ত মিশে না যায়।
- `HdrFusion.kt`-এ প্রতিটি non-reference bracket frame-এর Optical Flow field ParallaxCorrection দিয়ে refine করে তারপর tile fusion-এ পাঠানো হয়।
- Reference exposure, motion detection, confidence fallback, local tone mapping এবং bounded tile processing বজায় রাখা হয়েছে।

### সীমাবদ্ধতা ও সতর্কতা
- এটি image-space parallax-aware refinement; stereo depth, calibrated camera pose বা metric depth map তৈরি করে না।
- শুধু তিনটি exposure frame দিয়ে প্রকৃত 3D parallax পুরোপুরি সমাধান করা সম্ভব নয়। বড় camera translation, rotation, rolling shutter, moving subjects, low texture এবং কম আলোতে ভুল alignment হতে পারে।
- Strong edge-এর পাশে conservative fallback রাখা হয়েছে; তাই কিছু residual ghosting থাকতে পারে।
- S21 Plus-এ processing time, memory, edge artifacts ও ghosting পরীক্ষা করা বাকি।

### যাচাই
- Update 12 source ZIP থেকে কাজ করা হয়েছে; বিদ্যমান source files অক্ষত রেখে নতুন engine এবং integration যোগ করা হয়েছে।
- `OpticalFlowAlignment.kt` ও `ParallaxCorrection.kt` Kotlin compiler check Android Bitmap stub দিয়ে পাস করেছে।
- ZIP integrity test পাস করেছে।
- পূর্ণ Android Gradle build, Robolectric/instrumented test এবং physical-device test এই পরিবেশে চালানো হয়নি।
