package com.example.engine

import android.content.Context
import android.graphics.Bitmap
import com.example.ai.HybridAiEngine
import com.example.camera.CameraMode
import com.example.camera.VirtualAperture
import com.example.camera.VirtualLens
import com.example.capability.ProcessingProfile
import com.example.settings.AiProcessingMode
import com.example.settings.ColorScienceProfile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class PipelineRequest(
    val baseBitmap: Bitmap,
    val mode: CameraMode,
    val virtualAperture: VirtualAperture,
    val virtualLens: VirtualLens?,
    val processingProfile: ProcessingProfile,
    val metadata: ShotMetadata,
    val targetSuperResMegapixels: Int = 24,
    val colorProfile: ColorScienceProfile = ColorScienceProfile.NATURAL,
    val aiMode: AiProcessingMode = AiProcessingMode.HYBRID,
    val onProgress: (Float, String) -> Unit = { _, _ -> }
)

data class PipelineOutput(
    val processedBitmap: Bitmap,
    val originalBitmap: Bitmap,
    val savedResult: SavedCaptureResult,
    val sceneAnalysis: SceneAnalysisResult,
    val superResResult: SuperResolutionEngine.SuperResResult?,
    val appliedEngines: List<String>
)

object ComputationalPipeline {

    suspend fun execute(
        context: Context,
        request: PipelineRequest
    ): PipelineOutput = withContext(Dispatchers.Default) {
        val applied = mutableListOf<String>()
        val originalCopy = request.baseBitmap.copy(request.baseBitmap.config ?: Bitmap.Config.ARGB_8888, false)

        request.onProgress(0.05f, "Scene Analysis Engine...")

        // 1. Scene Analysis Engine
        val sceneAnalysis = SceneAnalysisEngine.analyzeBitmap(request.baseBitmap)
        applied.add("Scene Analysis: ${sceneAnalysis.detectedScene.label} (${sceneAnalysis.colorTemperatureKelvin}K)")

        var currentBitmap = request.baseBitmap

        // 2. Hybrid AI Execution Path
        val aiDecision = HybridAiEngine.decideExecutionPath(
            context = context,
            mode = request.aiMode,
            targetMegapixels = request.targetSuperResMegapixels,
            capabilities = null
        )
        // Report the selected route without implying a neural image model ran.
        applied.add("Processing route: ${aiDecision.selectedExecutionEngine.label} (${aiDecision.explanation})")

        // 3. Noise Reduction Engine
        if (request.metadata.iso > 400 || sceneAnalysis.luminance < 0.3f) {
            request.onProgress(0.18f, "Traditional edge-aware noise reduction (not AI)...")
            currentBitmap = NoiseReductionEngine.reduceNoise(currentBitmap, request.metadata.iso)
            applied.add("Traditional edge-aware spatial noise reduction (not AI)")
        }

        // 4. HDR Processing Engine
        if (request.mode == CameraMode.HDR || sceneAnalysis.suggestsHdr) {
            request.onProgress(0.30f, "Single-image HDR-style tone mapping (not multi-frame HDR)...")
            currentBitmap = HdrEngine.processHdrToneMapping(currentBitmap)
            applied.add("Single-image HDR-style tone mapping (not multi-frame HDR)")
        }

        // 5. Photographic Color Science Engine
        request.onProgress(0.42f, "Applying Color Profile: ${request.colorProfile.label}...")
        currentBitmap = ColorScience.applyColorProfile(currentBitmap, request.colorProfile)
        applied.add("Color Science: ${request.colorProfile.label}")

        // 6. Portrait Depth Engine (DSLR Bokeh Simulation)
        if (request.mode == CameraMode.PORTRAIT) {
            request.onProgress(0.55f, "Portrait Bokeh Simulation: ${request.virtualAperture.label}...")
            currentBitmap = PortraitDepthEngine.renderPortraitBokeh(
                input = currentBitmap,
                aperture = request.virtualAperture
            )
            applied.add("Portrait Depth: ${request.virtualAperture.label} Bokeh")
        }

        // 7. 24MP, 100MP, or 200MP Super-Resolution Engine
        var superResInfo: SuperResolutionEngine.SuperResResult? = null
        val needsSuperRes = request.mode == CameraMode.HIGH_RES || request.targetSuperResMegapixels > 20
        if (needsSuperRes) {
            request.onProgress(0.68f, "Super Resolution Pipeline (${request.targetSuperResMegapixels}MP target)...")
            superResInfo = SuperResolutionEngine.reconstruct(
                input = currentBitmap,
                targetMegapixels = request.targetSuperResMegapixels,
                sensorMegapixels = request.metadata.sensorMegapixels,
                profile = request.processingProfile,
                onProgress = { p, msg ->
                    request.onProgress(0.68f + (p * 0.20f), msg)
                }
            )
            currentBitmap = superResInfo.outputBitmap
            applied.add(superResInfo.processingMethodDescription)
        }

        // 8. Natural Detail Preservation Engine (Zero Plastic Beauty Filter)
        request.onProgress(0.90f, "Detail Preservation (Skin Pores & Fibers)...")
        currentBitmap = DetailPreservationEngine.enhanceTexture(currentBitmap, 1.15f)
        applied.add("Conservative local contrast enhancement (cannot recreate missing detail)")

        // 9. Final Image Optimization Engine (Storage & EXIF)
        request.onProgress(0.96f, "Saving to DCIM/AlternativeDSLR...")
        val updatedMetadata = request.metadata.copy(
            processingProfileName = "${request.processingProfile.title} | ${superResInfo?.processingMethodDescription ?: "Native Standard"}"
        )
        val savedResult = FinalOptimizationEngine.saveCapturePair(
            context = context,
            processedBitmap = currentBitmap,
            originalBitmap = originalCopy,
            metadata = updatedMetadata
        )
        applied.add("Final Optimization (EXIF & MediaStore)")

        request.onProgress(1.0f, "Complete")

        PipelineOutput(
            processedBitmap = currentBitmap,
            originalBitmap = originalCopy,
            savedResult = savedResult,
            sceneAnalysis = sceneAnalysis,
            superResResult = superResInfo,
            appliedEngines = applied
        )
    }
}
