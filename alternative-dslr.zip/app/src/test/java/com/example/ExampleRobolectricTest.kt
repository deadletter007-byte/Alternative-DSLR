package com.example

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import androidx.test.core.app.ApplicationProvider
import com.example.capability.DeviceProfiler
import com.example.capability.ProcessingProfile
import com.example.camera.CameraMode
import com.example.camera.VirtualAperture
import com.example.camera.VirtualLens
import com.example.engine.SceneAnalysisEngine
import android.graphics.PointF
import android.graphics.RectF
import com.example.ai.ExecutionEngine
import com.example.ai.HybridAiEngine
import com.example.camera.FaceFocusState
import com.example.camera.FaceTrackingState
import com.example.camera.TrackedEye
import com.example.camera.TrackedFace
import com.example.editor.EditorAdjustments
import com.example.editor.PhotoEditorEngine
import com.example.engine.ColorScience
import com.example.engine.SuperResolutionEngine
import com.example.settings.AiProcessingMode
import com.example.settings.ColorScienceProfile
import com.example.settings.SettingsRepository
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun testAppName() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Alternative DSLR", appName)
    }

    @Test
    fun testDeviceProfilerInspection() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val caps = DeviceProfiler.inspectDevice(context)
        assertNotNull(caps)
        assertNotNull(caps.recommendedProfile)
        assertTrue(caps.lenses.isNotEmpty())
    }

    @Test
    fun testSceneAnalysisEngine() {
        val bitmap = Bitmap.createBitmap(100, 100, Bitmap.Config.ARGB_8888)
        bitmap.eraseColor(Color.rgb(200, 200, 200)) // Bright scene
        val result = SceneAnalysisEngine.analyzeBitmap(bitmap)
        assertNotNull(result)
        assertTrue(result.luminance > 0.5f)
        assertEquals(100, result.suggestedIso)
    }

    @Test
    fun testCameraModesAndOptics() {
        assertEquals(17, CameraMode.values().size)
        assertTrue(CameraMode.PRO.isPro)
        assertTrue(CameraMode.PORTRAIT.isComputational)
        assertEquals(5, VirtualLens.values().size)
        assertEquals(8, VirtualAperture.values().size)
    }

    @Test
    fun testSettingsRepositoryPersistence() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repo = SettingsRepository(context)

        // Test 24MP, 100MP, 200MP persistence
        repo.targetResolutionMp = 24
        assertEquals(24, repo.targetResolutionMp)
        repo.targetResolutionMp = 100
        assertEquals(100, repo.targetResolutionMp)
        repo.targetResolutionMp = 200
        assertEquals(200, repo.targetResolutionMp)

        // Test AI Processing Mode persistence
        repo.aiProcessingMode = AiProcessingMode.ON_DEVICE_ONLY
        assertEquals(AiProcessingMode.ON_DEVICE_ONLY, repo.aiProcessingMode)
        repo.aiProcessingMode = AiProcessingMode.HYBRID
        assertEquals(AiProcessingMode.HYBRID, repo.aiProcessingMode)
        repo.aiProcessingMode = AiProcessingMode.CLOUD_ON_REQUEST
        assertEquals(AiProcessingMode.CLOUD_ON_REQUEST, repo.aiProcessingMode)

        // Test Color Science Profile persistence
        repo.colorProfile = ColorScienceProfile.DSLR_NATURAL
        assertEquals(ColorScienceProfile.DSLR_NATURAL, repo.colorProfile)
        repo.colorProfile = ColorScienceProfile.CINEMATIC_CLASSIC
        assertEquals(ColorScienceProfile.CINEMATIC_CLASSIC, repo.colorProfile)

        // Test Face Tracking toggle persistence
        repo.faceTrackingEnabled = true
        assertTrue(repo.faceTrackingEnabled)
        repo.faceTrackingEnabled = false
        assertFalse(repo.faceTrackingEnabled)
    }

    @Test
    fun testColorScienceTenProfiles() = runBlocking {
        val profiles = ColorScienceProfile.values()
        assertEquals("Must support exactly 10 distinct color science profiles", 10, profiles.size)

        val testBitmap = Bitmap.createBitmap(50, 50, Bitmap.Config.ARGB_8888)
        testBitmap.eraseColor(Color.rgb(180, 140, 100))

        profiles.forEach { profile ->
            val processed = ColorScience.applyColorProfile(testBitmap, profile)
            assertNotNull("Processing profile ${profile.label} must produce a valid bitmap", processed)
            assertEquals(50, processed.width)
            assertEquals(50, processed.height)
        }
    }

    @Test
    fun testSuperResolutionEngineTargetCalculations() = runBlocking {
        val testBitmap = Bitmap.createBitmap(100, 75, Bitmap.Config.ARGB_8888)

        // Target 24MP calculation
        val result24 = SuperResolutionEngine.reconstruct(
            input = testBitmap,
            targetMegapixels = 24,
            sensorMegapixels = 12.0f,
            profile = ProcessingProfile.MAXIMUM_QUALITY
        )
        assertNotNull(result24.outputBitmap)
        assertEquals(24, result24.targetMegapixels)
        assertFalse("Upscaled from 12MP to 24MP should be marked as reconstructed", result24.isNativeSensorCapture)

        // Target 100MP calculation
        val result100 = SuperResolutionEngine.reconstruct(
            input = testBitmap,
            targetMegapixels = 100,
            sensorMegapixels = 12.0f,
            profile = ProcessingProfile.MAXIMUM_QUALITY
        )
        assertNotNull(result100.outputBitmap)
        assertEquals(100, result100.targetMegapixels)

        // Target 200MP calculation
        val result200 = SuperResolutionEngine.reconstruct(
            input = testBitmap,
            targetMegapixels = 200,
            sensorMegapixels = 12.0f,
            profile = ProcessingProfile.MAXIMUM_QUALITY
        )
        assertNotNull(result200.outputBitmap)
        assertEquals(200, result200.targetMegapixels)
    }

    @Test
    fun testHybridAiEngineDecisions() {
        val context = ApplicationProvider.getApplicationContext<Context>()

        val onDeviceDecision = HybridAiEngine.decideExecutionPath(
            context = context,
            mode = AiProcessingMode.ON_DEVICE_ONLY,
            targetMegapixels = 24,
            capabilities = null
        )
        assertEquals(ExecutionEngine.ON_DEVICE, onDeviceDecision.selectedExecutionEngine)
        assertFalse(onDeviceDecision.requiresConsentPrompt)

        val hybridDecision = HybridAiEngine.decideExecutionPath(
            context = context,
            mode = AiProcessingMode.HYBRID,
            targetMegapixels = 100,
            capabilities = null
        )
        assertNotNull(hybridDecision.selectedExecutionEngine)

        val cloudDecision = HybridAiEngine.decideExecutionPath(
            context = context,
            mode = AiProcessingMode.CLOUD_ON_REQUEST,
            targetMegapixels = 24,
            capabilities = null
        )
        assertEquals(ExecutionEngine.ON_DEVICE, cloudDecision.selectedExecutionEngine)
    }

    @Test
    fun testPhotoEditorEngineNonDestructiveProcessing() = runBlocking {
        val testBitmap = Bitmap.createBitmap(80, 80, Bitmap.Config.ARGB_8888)
        testBitmap.eraseColor(Color.rgb(120, 130, 140))

        val adjustments = EditorAdjustments(
            exposure = 10f,
            contrast = 5f,
            saturation = 10f,
            temperature = 15f,
            tint = -5f,
            texture = 20f,
            selectedAperture = null,
            selectedColorProfile = ColorScienceProfile.PORTRAIT_NATURAL,
            rotationDegrees = 90
        )

        val edited = PhotoEditorEngine.applyAdjustments(testBitmap, adjustments)
        assertNotNull(edited)
        // 90 degree rotation on 80x80 keeps 80x80
        assertEquals(80, edited.width)
        assertEquals(80, edited.height)
    }

    @Test
    fun testFaceTrackingStateModels() {
        val leftEyePoint = PointF(0.4f, 0.45f)
        val rightEyePoint = PointF(0.6f, 0.45f)
        val face = TrackedFace(
            id = 1,
            bounds = RectF(0.3f, 0.3f, 0.7f, 0.8f),
            leftEye = leftEyePoint,
            rightEye = rightEyePoint,
            focusState = FaceFocusState.EYE_DETECTED,
            isSelected = true
        )
        val state = FaceTrackingState(
            faces = listOf(face),
            selectedFaceId = 1,
            isEyeAfActive = true,
            trackingStatusText = "Eye AF Locked"
        )

        assertEquals(1, state.faces.size)
        assertEquals(1, state.selectedFaceId)
        assertTrue(state.isEyeAfActive)
        assertEquals("Eye AF Locked", state.trackingStatusText)
    }
}
