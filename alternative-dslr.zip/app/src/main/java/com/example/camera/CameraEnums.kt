package com.example.camera

enum class GridType(val title: String) {
    NONE("None"),
    RULE_OF_THIRDS("Rule of Thirds (3×3)"),
    GOLDEN_RATIO("Golden Ratio (Phi)"),
    SQUARE("Square 1:1 Framing")
}

enum class ActiveScreen {
    CAMERA,
    GALLERY,
    IMAGE_DETAIL,
    COMPARE_VIEW,
    SETTINGS,
    DEVICE_INSPECTOR,
    ABOUT,
    PHOTO_EDITOR
}
