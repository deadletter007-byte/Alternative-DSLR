package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.camera.ActiveScreen
import com.example.ui.screens.AboutScreen
import com.example.ui.screens.CameraMainScreen
import com.example.ui.screens.CompareScreen
import com.example.ui.screens.DeviceInspectionScreen
import com.example.ui.screens.GalleryScreen
import com.example.ui.screens.ImageDetailScreen
import com.example.ui.screens.PhotoEditorScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.AlternativeDslrTheme
import com.example.ui.theme.DslrAmber
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.TitaniumBright
import com.example.ui.theme.TitaniumSilver

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            AlternativeDslrTheme {
                val context = LocalContext.current
                var hasCameraPermission by remember {
                    mutableStateOf(
                        ContextCompat.checkSelfPermission(
                            context,
                            Manifest.permission.CAMERA
                        ) == PackageManager.PERMISSION_GRANTED
                    )
                }

                val permissionLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestMultiplePermissions()
                ) { permissions ->
                    hasCameraPermission = permissions[Manifest.permission.CAMERA] == true
                }

                LaunchedEffect(Unit) {
                    if (!hasCameraPermission) {
                        permissionLauncher.launch(
                            arrayOf(
                                Manifest.permission.CAMERA,
                                Manifest.permission.RECORD_AUDIO
                            )
                        )
                    }
                }

                if (!hasCameraPermission) {
                    PermissionRequestScreen(
                        onRequestPermission = {
                            permissionLauncher.launch(
                                arrayOf(
                                    Manifest.permission.CAMERA,
                                    Manifest.permission.RECORD_AUDIO
                                )
                            )
                        }
                    )
                } else {
                    AlternativeDslrApp(viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
fun AlternativeDslrApp(viewModel: MainViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    when (uiState.activeScreen) {
        ActiveScreen.CAMERA -> {
            CameraMainScreen(
                viewModel = viewModel,
                state = uiState
            )
        }

        ActiveScreen.GALLERY -> {
            GalleryScreen(
                onNavigateBack = { viewModel.onScreenChange(ActiveScreen.CAMERA) },
                onSelectItem = { item -> viewModel.onSelectMediaDetail(item) }
            )
        }

        ActiveScreen.IMAGE_DETAIL -> {
            val item = uiState.selectedMediaDetail
            if (item != null) {
                ImageDetailScreen(
                    item = item,
                    onNavigateBack = { viewModel.onScreenChange(ActiveScreen.GALLERY) },
                    onOpenCompare = { viewModel.onScreenChange(ActiveScreen.COMPARE_VIEW) },
                    onOpenEditor = { detail -> viewModel.openPhotoEditor(detail) },
                    onDelete = { media -> viewModel.deleteMedia(media) }
                )
            } else {
                viewModel.onScreenChange(ActiveScreen.GALLERY)
            }
        }

        ActiveScreen.PHOTO_EDITOR -> {
            val item = uiState.photoEditorItem
            if (item != null) {
                PhotoEditorScreen(
                    item = item,
                    onNavigateBack = { viewModel.onScreenChange(ActiveScreen.IMAGE_DETAIL) },
                    onSavedCopy = { viewModel.onPhotoEditorSaved() }
                )
            } else {
                viewModel.onScreenChange(ActiveScreen.GALLERY)
            }
        }

        ActiveScreen.COMPARE_VIEW -> {
            val item = uiState.selectedMediaDetail
            if (item != null) {
                CompareScreen(
                    item = item,
                    onNavigateBack = { viewModel.onScreenChange(ActiveScreen.IMAGE_DETAIL) }
                )
            } else {
                viewModel.onScreenChange(ActiveScreen.GALLERY)
            }
        }

        ActiveScreen.DEVICE_INSPECTOR -> {
            DeviceInspectionScreen(
                capabilities = uiState.capabilities,
                currentProfile = uiState.currentProfile,
                onSelectProfile = { viewModel.setProcessingProfile(it) },
                onNavigateBack = { viewModel.onScreenChange(ActiveScreen.CAMERA) }
            )
        }

        ActiveScreen.SETTINGS -> {
            SettingsScreen(
                viewModel = viewModel,
                state = uiState,
                onNavigateBack = { viewModel.onScreenChange(ActiveScreen.CAMERA) }
            )
        }

        ActiveScreen.ABOUT -> {
            AboutScreen(
                onNavigateBack = { viewModel.onScreenChange(ActiveScreen.CAMERA) }
            )
        }
    }
}

@Composable
fun PermissionRequestScreen(
    onRequestPermission: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Default.CameraAlt,
                contentDescription = null,
                tint = DslrAmber,
                modifier = Modifier.size(72.dp)
            )

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "Alternative DSLR",
                fontSize = 24.sp,
                fontWeight = FontWeight.ExtraBold,
                color = TitaniumBright
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "To access the camera sensor, optical zoom, and computational photography pipeline, Alternative DSLR requires Camera and Audio permissions.",
                fontSize = 13.sp,
                color = TitaniumSilver,
                textAlign = TextAlign.Center,
                lineHeight = 18.sp,
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            Spacer(modifier = Modifier.height(28.dp))

            Button(
                onClick = onRequestPermission,
                colors = ButtonDefaults.buttonColors(containerColor = DslrAmber),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth(0.8f)
                    .testTag("request_permission_button")
            ) {
                Text(
                    text = "Enable Camera Access",
                    color = ObsidianBlack,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }
        }
    }
}
