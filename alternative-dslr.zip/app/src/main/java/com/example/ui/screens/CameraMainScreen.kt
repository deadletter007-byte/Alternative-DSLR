package com.example.ui.screens

import android.view.ViewGroup
import androidx.camera.view.LifecycleCameraController
import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.MainViewModel
import com.example.camera.ActiveScreen
import com.example.camera.CameraMode
import com.example.camera.CameraUiState
import com.example.camera.GridType
import com.example.ui.components.FaceTrackingOverlay
import com.example.ui.components.ModeCarousel
import com.example.ui.components.OpticsSelector
import com.example.ui.components.ProControlsPanel
import com.example.ui.components.ShutterBar
import com.example.ui.components.TopBarHUD
import com.example.ui.components.ViewfinderOverlays
import com.example.ui.theme.DslrAmber
import com.example.ui.theme.DslrCyan
import com.example.ui.theme.DslrGreen
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.TitaniumBright
import com.example.ui.theme.TitaniumDark
import com.example.ui.theme.TitaniumSilver

@Composable
fun CameraMainScreen(
    viewModel: MainViewModel,
    state: CameraUiState,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val cameraController = remember {
        LifecycleCameraController(context).apply {
            bindToLifecycle(lifecycleOwner)
            viewModel.attachCameraController(this)
        }
    }

    DisposableEffect(lifecycleOwner) {
        onDispose {
            cameraController.unbind()
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .testTag("camera_main_screen")
    ) {
        // 1. Live Camera Preview (CameraX PreviewView)
        AndroidView(
            factory = { ctx ->
                PreviewView(ctx).apply {
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    scaleType = PreviewView.ScaleType.FILL_CENTER
                    controller = cameraController
                }
            },
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures { offset ->
                        val normX = offset.x / size.width.toFloat()
                        val normY = offset.y / size.height.toFloat()
                        viewModel.tapToFocus(normX, normY)
                    }
                }
        )

        // 2. Viewfinder Overlays (Grid, Horizon Level, Histogram, Zebra, Peaking)
        ViewfinderOverlays(
            state = state,
            modifier = Modifier.fillMaxSize()
        )

        // 3. Real Face and Eye Tracking Overlay
        if (state.isFaceTrackingEnabled) {
            FaceTrackingOverlay(
                trackingState = state.faceTrackingState,
                onSelectFace = { nx, ny -> viewModel.selectFace(nx, ny) },
                modifier = Modifier.fillMaxSize()
            )
        }

        // 4. Processing Progress Banner (Tiled 24MP / 100MP / 200MP reconstruction progress)
        AnimatedVisibility(
            visible = state.isCapturing && state.processingStatusDetail != null,
            enter = fadeIn() + slideInVertically(),
            exit = fadeOut() + slideOutVertically(),
            modifier = Modifier
                .align(Alignment.Center)
                .padding(24.dp)
        ) {
            CardBannerProgress(
                progress = state.processingProgress,
                status = state.processingStatusDetail ?: "Processing..."
            )
        }

        // 5. Status Message Toast
        AnimatedVisibility(
            visible = state.lastStatusMessage != null && !state.isCapturing,
            enter = fadeIn() + slideInVertically(),
            exit = fadeOut() + slideOutVertically(),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 84.dp)
        ) {
            state.lastStatusMessage?.let { msg ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(ObsidianBlack.copy(alpha = 0.85f))
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = msg,
                        fontSize = 11.sp,
                        color = DslrAmber,
                        maxLines = 1
                    )
                }
            }
        }

        // 6. Top Telemetry HUD & Quick Toggles
        Column(modifier = Modifier.align(Alignment.TopCenter)) {
            TopBarHUD(
                state = state,
                onToggleFlash = { viewModel.toggleFlash() },
                onCycleTimer = {
                    val nextTimer = when (state.timerSeconds) {
                        0 -> 3
                        3 -> 5
                        5 -> 10
                        else -> 0
                    }
                    viewModel.setTimerSeconds(nextTimer)
                },
                onCycleGrid = {
                    val nextGrid = when (state.gridType) {
                        GridType.NONE -> GridType.RULE_OF_THIRDS
                        GridType.RULE_OF_THIRDS -> GridType.GOLDEN_RATIO
                        GridType.GOLDEN_RATIO -> GridType.SQUARE
                        GridType.SQUARE -> GridType.NONE
                    }
                    viewModel.setGridType(nextGrid)
                },
                onToggleLevel = { viewModel.toggleHorizonLevel() },
                onOpenSettings = { viewModel.onScreenChange(ActiveScreen.SETTINGS) },
                onOpenInspector = { viewModel.onScreenChange(ActiveScreen.DEVICE_INSPECTOR) },
                onOpenAbout = { viewModel.onScreenChange(ActiveScreen.ABOUT) }
            )

            // Viewfinder Status Strip (Resolution badge, AI Mode badge, Color Profile)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Resolution badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(ObsidianBlack.copy(alpha = 0.70f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "${state.targetSuperResMegapixels}MP ${if (state.targetSuperResMegapixels > 24) "AI" else "HQ"}",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = DslrAmber,
                        fontFamily = FontFamily.Monospace
                    )
                }

                // AI Engine Mode & Color Science Profile
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(ObsidianBlack.copy(alpha = 0.70f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = state.aiProcessingMode.name.take(6),
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = DslrCyan,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(ObsidianBlack.copy(alpha = 0.70f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = state.colorProfile.label,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = TitaniumBright,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        // 7. Bottom Control Stack
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
        ) {
            // Pro manual controls panel if in PRO or PRO VIDEO mode
            if (state.selectedMode.isPro) {
                ProControlsPanel(
                    state = state,
                    onSetIso = { viewModel.setManualIso(it) },
                    onToggleAutoIso = { viewModel.toggleManualIso() },
                    onSetShutter = { viewModel.setManualShutterSpeed(it) },
                    onToggleAutoShutter = { viewModel.toggleManualShutter() },
                    onSetEv = { viewModel.setEvCompensation(it) },
                    onSetFocus = { viewModel.setManualFocus(it) },
                    onToggleAutoFocus = { viewModel.toggleManualFocus() },
                    onSetKelvin = { viewModel.setWhiteBalanceKelvin(it) },
                    onToggleAutoWb = { viewModel.toggleManualWb() },
                    onToggleAeLock = { viewModel.toggleAeLock() },
                    onToggleAfLock = { viewModel.toggleAfLock() },
                    onToggleRaw = { viewModel.toggleRaw() },
                    onTogglePeaking = { viewModel.toggleFocusPeaking() },
                    onToggleZebra = { viewModel.toggleZebraWarning() }
                )
            }

            // Lens & Virtual Optics Selector
            OpticsSelector(
                state = state,
                onSetZoomRatio = { viewModel.setZoomRatio(it) },
                onSelectPhysicalCamera = { viewModel.selectPhysicalCameraModule(it) },
                onSelectVirtualLens = { viewModel.setVirtualLens(it) },
                onSelectVirtualAperture = { viewModel.setVirtualAperture(it) }
            )

            // Mode Carousel (Auto, Pro, Portrait, Night, etc.)
            ModeCarousel(
                currentMode = state.selectedMode,
                onSelectMode = { viewModel.onSelectMode(it) }
            )

            // Shutter Button & Camera Controls
            ShutterBar(
                state = state,
                onTriggerCapture = { viewModel.triggerShutter() },
                onToggleVideo = { viewModel.toggleVideoRecording() },
                onToggleCameraFacing = { viewModel.toggleCameraFacing() },
                onOpenGallery = { viewModel.onScreenChange(ActiveScreen.GALLERY) }
            )
        }
    }
}

@Composable
private fun CardBannerProgress(progress: Float, status: String) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .background(ObsidianBlack.copy(alpha = 0.92f))
            .padding(horizontal = 20.dp, vertical = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(
                    progress = { progress },
                    color = DslrAmber,
                    strokeWidth = 3.dp,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "${(progress * 100).toInt()}%",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = DslrAmber,
                    fontFamily = FontFamily.Monospace
                )
            }
            Text(
                text = status,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                color = TitaniumBright,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}
