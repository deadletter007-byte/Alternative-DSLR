package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.camera.CameraMode
import com.example.camera.CameraUiState
import com.example.camera.VirtualAperture
import com.example.camera.VirtualLens
import com.example.ui.theme.DslrAmber
import com.example.ui.theme.DslrGold
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.TitaniumDark
import com.example.ui.theme.TitaniumMid
import com.example.ui.theme.TitaniumSilver

@Composable
fun OpticsSelector(
    state: CameraUiState,
    onSetZoomRatio: (Float) -> Unit,
    onSelectVirtualLens: (VirtualLens?) -> Unit,
    onSelectVirtualAperture: (VirtualAperture) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // If in Portrait Mode, show virtual aperture & virtual portrait lens choices
        if (state.selectedMode == CameraMode.PORTRAIT) {
            // Virtual Aperture selector (f/1.2 - f/8)
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(bottom = 6.dp)
            ) {
                items(VirtualAperture.values()) { aperture ->
                    val isSelected = aperture == state.virtualAperture
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isSelected) DslrAmber else TitaniumDark.copy(alpha = 0.8f))
                            .clickable { onSelectVirtualAperture(aperture) }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                            .testTag("aperture_${aperture.name.lowercase()}")
                    ) {
                        Text(
                            text = aperture.label,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) ObsidianBlack else TitaniumSilver,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            // Virtual Portrait Lenses (70mm, 85mm, 105mm, 135mm, 200mm)
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                items(VirtualLens.values()) { lens ->
                    val isSelected = lens == state.virtualLens
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isSelected) DslrGold else TitaniumDark.copy(alpha = 0.8f))
                            .clickable { onSelectVirtualLens(lens) }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                            .testTag("virtual_lens_${lens.focalLengthMm}mm")
                    ) {
                        Text(
                            text = "${lens.label} (${lens.character})",
                            fontSize = 10.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) ObsidianBlack else TitaniumSilver,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        } else {
            // Standard Optical / Computational Zoom Multipliers
            val zoomSteps = listOf(0.6f, 1.0f, 2.0f, 5.0f)
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(ObsidianBlack.copy(alpha = 0.7f))
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                zoomSteps.forEach { step ->
                    val isSelected = kotlin.math.abs(state.zoomRatio - step) < 0.2f
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(if (isSelected) DslrAmber else Color.Transparent)
                            .clickable { onSetZoomRatio(step) }
                            .testTag("zoom_button_${(step * 10).toInt()}"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (step == 0.6f) ".6" else "${step.toInt()}x",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) ObsidianBlack else TitaniumSilver,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}
