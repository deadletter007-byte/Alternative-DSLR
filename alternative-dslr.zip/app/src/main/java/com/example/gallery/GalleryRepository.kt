package com.example.gallery

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

data class CapturedMediaItem(
    val id: Long,
    val uri: Uri,
    val originalUri: Uri?,
    val displayName: String,
    val dateTaken: Long,
    val isVideo: Boolean,
    val isRaw: Boolean,
    val resolution: String,
    val sizeBytes: Long,
    val filePath: String?
)

object GalleryRepository {

    suspend fun loadAlternativeDslrMedia(context: Context): List<CapturedMediaItem> = withContext(Dispatchers.IO) {
        val items = mutableListOf<CapturedMediaItem>()
        val projection = arrayOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.DATE_TAKEN,
            MediaStore.Images.Media.SIZE,
            MediaStore.Images.Media.WIDTH,
            MediaStore.Images.Media.HEIGHT
        )

        // Query MediaStore for AlternativeDSLR images or ADSLR prefix
        val selection = "${MediaStore.Images.Media.DISPLAY_NAME} LIKE 'ADSLR_%'"
        val sortOrder = "${MediaStore.Images.Media.DATE_TAKEN} DESC"

        try {
            context.contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projection,
                selection,
                null,
                sortOrder
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_TAKEN)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)
                val widthCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.WIDTH)
                val heightCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.HEIGHT)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val name = cursor.getString(nameCol) ?: "Capture_$id"
                    val date = cursor.getLong(dateCol)
                    val size = cursor.getLong(sizeCol)
                    val w = cursor.getInt(widthCol)
                    val h = cursor.getInt(heightCol)

                    val contentUri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id)

                    // Find matching original file if stored in internal filesDir
                    val origFile = File(context.filesDir, name.replace("_PROC.jpg", "_ORIG.jpg"))
                    val origUri = if (origFile.exists()) Uri.fromFile(origFile) else null

                    items.add(
                        CapturedMediaItem(
                            id = id,
                            uri = contentUri,
                            originalUri = origUri,
                            displayName = name,
                            dateTaken = date,
                            isVideo = false,
                            isRaw = name.contains("RAW") || name.endsWith(".dng"),
                            resolution = if (w > 0 && h > 0) "$w × $h" else "High-Res",
                            sizeBytes = size,
                            filePath = null
                        )
                    )
                }
            }
        } catch (e: Exception) {
            // Fallback or error handled gracefully
        }

        // Also inspect internal storage if MediaStore is restricted
        try {
            context.filesDir.listFiles { file -> file.name.startsWith("ADSLR_") && file.name.endsWith(".jpg") }
                ?.sortedByDescending { it.lastModified() }
                ?.forEach { file ->
                    if (items.none { it.displayName == file.name }) {
                        items.add(
                            CapturedMediaItem(
                                id = file.lastModified(),
                                uri = Uri.fromFile(file),
                                originalUri = null,
                                displayName = file.name,
                                dateTaken = file.lastModified(),
                                isVideo = false,
                                isRaw = false,
                                resolution = "Standard",
                                sizeBytes = file.length(),
                                filePath = file.absolutePath
                            )
                        )
                    }
                }
        } catch (e: Exception) {
            // Log or ignore
        }

        items
    }

    suspend fun deleteItem(context: Context, item: CapturedMediaItem): Boolean = withContext(Dispatchers.IO) {
        var deleted = false
        try {
            if (item.uri.scheme == "content") {
                val rows = context.contentResolver.delete(item.uri, null, null)
                deleted = rows > 0
            } else if (item.uri.scheme == "file") {
                val f = File(item.uri.path ?: "")
                if (f.exists()) deleted = f.delete()
            }
            // Also delete cached original if exists
            item.originalUri?.path?.let { p ->
                val of = File(p)
                if (of.exists()) of.delete()
            }
        } catch (e: Exception) {
            deleted = false
        }
        deleted
    }
}
