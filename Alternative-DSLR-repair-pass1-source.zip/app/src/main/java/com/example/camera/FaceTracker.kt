package com.example.camera

import android.graphics.PointF
import android.graphics.Rect
import android.graphics.RectF
import androidx.annotation.OptIn
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageProxy
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.google.mlkit.vision.face.FaceLandmark
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class FaceTracker {

    private val _trackingState = MutableStateFlow(FaceTrackingState())
    val trackingState: StateFlow<FaceTrackingState> = _trackingState.asStateFlow()

    private val detector = FaceDetection.getClient(
        FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_ALL)
            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_NONE)
            .setMinFaceSize(0.12f)
            .enableTracking()
            .build()
    )

    private var selectedFaceId: Int? = null
    private var isFocusLocked = false
    private var lastFocusLockTime = 0L

    @OptIn(ExperimentalGetImage::class)
    fun processImageProxy(imageProxy: ImageProxy, isFrontCamera: Boolean, onComplete: () -> Unit = {}) {
        val mediaImage = imageProxy.image
        if (mediaImage == null) {
            imageProxy.close()
            onComplete()
            return
        }

        val rotation = imageProxy.imageInfo.rotationDegrees
        val inputImage = InputImage.fromMediaImage(mediaImage, rotation)

        detector.process(inputImage)
            .addOnSuccessListener { faces ->
                updateTracking(faces, imageProxy.width, imageProxy.height, rotation, isFrontCamera)
            }
            .addOnFailureListener {
                // Keep last state or mark searching
            }
            .addOnCompleteListener {
                imageProxy.close()
                onComplete()
            }
    }

    private fun updateTracking(
        mlFaces: List<Face>,
        imageWidth: Int,
        imageHeight: Int,
        rotationDegrees: Int,
        isFrontCamera: Boolean
    ) {
        val isRotated = rotationDegrees == 90 || rotationDegrees == 270
        val frameW = if (isRotated) imageHeight.toFloat() else imageWidth.toFloat()
        val frameH = if (isRotated) imageWidth.toFloat() else imageHeight.toFloat()

        if (mlFaces.isEmpty()) {
            val previousFaces = _trackingState.value.faces
            if (previousFaces.isNotEmpty()) {
                val now = System.currentTimeMillis()
                val recent = previousFaces.filter { now - it.lastSeenTimestamp < 600 }
                if (recent.isNotEmpty()) {
                    _trackingState.update {
                        it.copy(
                            faces = recent.map { f -> f.copy(focusState = FaceFocusState.LOST) },
                            isTrackingLost = true,
                            trackingStatusText = "Tracking Lost (Recovering)"
                        )
                    }
                    return
                }
            }
            _trackingState.update {
                it.copy(
                    faces = emptyList(),
                    isTrackingLost = false,
                    isEyeAfActive = false,
                    trackingStatusText = "Searching Subject"
                )
            }
            return
        }

        val now = System.currentTimeMillis()
        if (isFocusLocked && now - lastFocusLockTime > 3000) {
            isFocusLocked = false
        }

        val updatedFaces = mlFaces.map { face ->
            val id = face.trackingId ?: 0
            val isSelected = (selectedFaceId != null && selectedFaceId == id) || (selectedFaceId == null && face == mlFaces.first())

            val normalizedBounds = normalizeRect(
                box = face.boundingBox,
                sourceWidth = imageWidth,
                sourceHeight = imageHeight,
                rotationDegrees = rotationDegrees,
                isFrontCamera = isFrontCamera
            )

            // Eye landmarks
            val leftEyeLandmark = face.getLandmark(FaceLandmark.LEFT_EYE)
            val rightEyeLandmark = face.getLandmark(FaceLandmark.RIGHT_EYE)

            val leftEyeNorm = leftEyeLandmark?.let {
                normalizePoint(it.position.x, it.position.y, imageWidth, imageHeight, rotationDegrees, isFrontCamera)
            }
            val rightEyeNorm = rightEyeLandmark?.let {
                normalizePoint(it.position.x, it.position.y, imageWidth, imageHeight, rotationDegrees, isFrontCamera)
            }

            val hasEyes = leftEyeNorm != null || rightEyeNorm != null

            val focusState = when {
                isFocusLocked && isSelected -> FaceFocusState.LOCKED
                isSelected && hasEyes -> FaceFocusState.EYE_DETECTED
                isSelected -> FaceFocusState.SELECTED
                else -> FaceFocusState.DETECTED
            }

            TrackedFace(
                id = id,
                bounds = normalizedBounds,
                leftEye = leftEyeNorm,
                rightEye = rightEyeNorm,
                isSelected = isSelected,
                focusState = focusState,
                rollAngle = face.headEulerAngleZ,
                panAngle = face.headEulerAngleY,
                lastSeenTimestamp = now
            )
        }

        // Set default selected face if not set
        if (selectedFaceId == null && updatedFaces.isNotEmpty()) {
            selectedFaceId = updatedFaces.first().id
        }

        val hasEyeAf = updatedFaces.any { it.isSelected && (it.leftEye != null || it.rightEye != null) }
        val statusText = when {
            isFocusLocked -> "Focus & Exposure Locked"
            hasEyeAf -> "Eye AF Active (Dual Track)"
            updatedFaces.size > 1 -> "Multi-Face AF (${updatedFaces.size} Faces)"
            else -> "Face AF Tracking"
        }

        _trackingState.update {
            it.copy(
                faces = updatedFaces,
                selectedFaceId = selectedFaceId,
                isEyeAfActive = hasEyeAf,
                trackingStatusText = statusText,
                isTrackingLost = false
            )
        }
    }

    fun selectFaceAt(normX: Float, normY: Float): TrackedFace? {
        val faces = _trackingState.value.faces
        val tapped = faces.firstOrNull { it.bounds.contains(normX, normY) }
        if (tapped != null) {
            selectedFaceId = tapped.id
            isFocusLocked = true
            lastFocusLockTime = System.currentTimeMillis()
            _trackingState.update { current ->
                current.copy(
                    selectedFaceId = tapped.id,
                    faces = current.faces.map { f ->
                        if (f.id == tapped.id) f.copy(isSelected = true, focusState = FaceFocusState.LOCKED)
                        else f.copy(isSelected = false, focusState = FaceFocusState.DETECTED)
                    },
                    trackingStatusText = "AF Target Locked (Face #${tapped.id})"
                )
            }
            return tapped
        }
        return null
    }

    fun setFocusLocked(locked: Boolean) {
        this.isFocusLocked = locked
        if (locked) lastFocusLockTime = System.currentTimeMillis()
        _trackingState.update { state ->
            state.copy(
                faces = state.faces.map { f ->
                    if (f.isSelected) f.copy(focusState = if (locked) FaceFocusState.LOCKED else FaceFocusState.SELECTED)
                    else f
                },
                trackingStatusText = if (locked) "AF Locked" else "Tracking Active"
            )
        }
    }

    private fun normalizeRect(
        box: Rect,
        sourceWidth: Int,
        sourceHeight: Int,
        rotationDegrees: Int,
        isFrontCamera: Boolean
    ): RectF {
        val p1 = normalizePoint(box.left.toFloat(), box.top.toFloat(), sourceWidth, sourceHeight, rotationDegrees, isFrontCamera)
        val p2 = normalizePoint(box.right.toFloat(), box.bottom.toFloat(), sourceWidth, sourceHeight, rotationDegrees, isFrontCamera)

        val left = minOf(p1.x, p2.x).coerceIn(0f, 1f)
        val top = minOf(p1.y, p2.y).coerceIn(0f, 1f)
        val right = maxOf(p1.x, p2.x).coerceIn(0f, 1f)
        val bottom = maxOf(p1.y, p2.y).coerceIn(0f, 1f)

        return RectF(left, top, right, bottom)
    }

    private fun normalizePoint(
        x: Float,
        y: Float,
        width: Int,
        height: Int,
        rotationDegrees: Int,
        isFrontCamera: Boolean
    ): PointF {
        // Step 1: Normalize to [0..1] in image sensor space
        var nx = (x / width.toFloat()).coerceIn(0f, 1f)
        var ny = (y / height.toFloat()).coerceIn(0f, 1f)

        // Step 2: Handle front camera horizontal mirroring
        if (isFrontCamera) {
            nx = 1.0f - nx
        }

        // Step 3: Rotate coordinates according to display rotation
        return when (rotationDegrees) {
            90 -> PointF(1.0f - ny, nx)
            180 -> PointF(1.0f - nx, 1.0f - ny)
            270 -> PointF(ny, 1.0f - nx)
            else -> PointF(nx, ny)
        }
    }

    fun release() {
        detector.close()
    }
}
