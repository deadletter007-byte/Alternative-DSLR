package com.example.camera

import android.graphics.PointF
import android.graphics.RectF

enum class FaceFocusState {
    DETECTED,     // Detected, awaiting focus
    SELECTED,     // Tapped / active primary tracking target
    EYE_DETECTED, // Eye landmark pinpointed
    AF_ACTIVE,    // Camera lens moving to achieve focus
    LOCKED,       // Focus & AE locked on face (emerald green)
    LOST          // Face temporarily occluded
}

data class TrackedEye(
    val point: PointF, // Normalized 0..1 preview coordinate
    val isLeft: Boolean
)

data class TrackedFace(
    val id: Int,
    val bounds: RectF, // Normalized 0..1 preview coordinate (left, top, right, bottom)
    val leftEye: PointF? = null,
    val rightEye: PointF? = null,
    val isSelected: Boolean = false,
    val focusState: FaceFocusState = FaceFocusState.DETECTED,
    val rollAngle: Float = 0f,
    val panAngle: Float = 0f,
    val lastSeenTimestamp: Long = System.currentTimeMillis()
)

data class FaceTrackingState(
    val faces: List<TrackedFace> = emptyList(),
    val selectedFaceId: Int? = null,
    val isEyeAfActive: Boolean = false,
    val trackingStatusText: String = "Searching",
    val isTrackingLost: Boolean = false
)
