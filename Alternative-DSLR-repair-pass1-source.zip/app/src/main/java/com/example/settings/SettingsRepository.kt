package com.example.settings

import android.content.Context
import android.content.SharedPreferences
import com.example.camera.GridType
import com.example.capability.ProcessingProfile

enum class AiProcessingMode(val label: String, val description: String) {
    ON_DEVICE_ONLY("On-Device AI Only", "Process entirely offline on device neural/CPU hardware. Maximum privacy."),
    HYBRID("Hybrid AI (Recommended)", "Prioritizes on-device AI, seamlessly assisted by Cloud AI for complex scenes."),
    CLOUD_ON_REQUEST("Cloud AI on Request", "On-device capture with manual Cloud AI deep image analysis when requested.")
}

enum class ColorScienceProfile(val label: String, val description: String) {
    NATURAL("Natural", "True-to-life organic tones with realistic skin and foliage."),
    NEUTRAL("Neutral", "Flat linear DSLR profile with minimal contrast for grading."),
    VIVID("Vivid", "Rich dynamic colors with saturated skies and rich foliage."),
    PORTRAIT_NATURAL("Portrait Natural", "Protects skin tones and melanin with soft transition rolloff."),
    LANDSCAPE_NATURAL("Landscape Natural", "Deep greens, clean sky blues, and atmospheric haze suppression."),
    WARM("Golden Warm", "Warm golden-hour tone curve with amber highlights."),
    COOL("Cool Titanium", "Crisp cool white balance with clean daylight highlights."),
    PRO_NEUTRAL("Professional Neutral", "Calibrated studio profile preserving accurate color chart values."),
    DSLR_NATURAL("DSLR Natural", "Classic full-frame sensor response with rich midtone contrast."),
    CINEMATIC_CLASSIC("Cinematic Classic", "Subtle analog character with organic shadow warmth and soft highlight roll.")
}

enum class AiProvider(val label: String, val subtitle: String) {
    GEMINI("Google Gemini", "Gemini 2.0 Flash multimodal photography intelligence"),
    CHATGPT("OpenAI ChatGPT", "GPT-4o / GPT-4o-mini conversational photography assistant"),
    ON_DEVICE("On-Device Local AI", "Offline neural scene analysis & hardware optimization")
}

class SettingsRepository(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("alternative_dslr_prefs", Context.MODE_PRIVATE)

    var aiProvider: AiProvider
        get() {
            val name = prefs.getString(KEY_AI_PROVIDER, AiProvider.GEMINI.name)
            return try {
                AiProvider.valueOf(name ?: AiProvider.GEMINI.name)
            } catch (e: Exception) {
                AiProvider.GEMINI
            }
        }
        set(value) = prefs.edit().putString(KEY_AI_PROVIDER, value.name).apply()

    var openAiApiKey: String
        get() = prefs.getString(KEY_OPENAI_API_KEY, "") ?: ""
        set(value) = prefs.edit().putString(KEY_OPENAI_API_KEY, value.trim()).apply()

    var geminiApiKey: String
        get() = prefs.getString(KEY_GEMINI_API_KEY, "") ?: ""
        set(value) = prefs.edit().putString(KEY_GEMINI_API_KEY, value.trim()).apply()

    var openAiModel: String
        get() = prefs.getString(KEY_OPENAI_MODEL, "gpt-4o-mini") ?: "gpt-4o-mini"
        set(value) = prefs.edit().putString(KEY_OPENAI_MODEL, value).apply()

    var geminiModel: String
        get() = prefs.getString(KEY_GEMINI_MODEL, "gemini-2.0-flash") ?: "gemini-2.0-flash"
        set(value) = prefs.edit().putString(KEY_GEMINI_MODEL, value).apply()

    var jpegQuality: Int
        get() = prefs.getInt(KEY_JPEG_QUALITY, 95)
        set(value) = prefs.edit().putInt(KEY_JPEG_QUALITY, value.coerceIn(70, 100)).apply()

    var targetResolutionMp: Int
        get() = prefs.getInt(KEY_TARGET_RES_MP, 24)
        set(value) = prefs.edit().putInt(KEY_TARGET_RES_MP, value).apply()

    var aiProcessingMode: AiProcessingMode
        get() {
            val name = prefs.getString(KEY_AI_MODE, AiProcessingMode.HYBRID.name)
            return try {
                AiProcessingMode.valueOf(name ?: AiProcessingMode.HYBRID.name)
            } catch (e: Exception) {
                AiProcessingMode.HYBRID
            }
        }
        set(value) = prefs.edit().putString(KEY_AI_MODE, value.name).apply()

    var colorProfile: ColorScienceProfile
        get() {
            val name = prefs.getString(KEY_COLOR_PROFILE, ColorScienceProfile.NATURAL.name)
            return try {
                ColorScienceProfile.valueOf(name ?: ColorScienceProfile.NATURAL.name)
            } catch (e: Exception) {
                ColorScienceProfile.NATURAL
            }
        }
        set(value) = prefs.edit().putString(KEY_COLOR_PROFILE, value.name).apply()

    var processingProfile: ProcessingProfile
        get() {
            val name = prefs.getString(KEY_PROCESSING_PROFILE, ProcessingProfile.BALANCED.name)
            return try {
                ProcessingProfile.valueOf(name ?: ProcessingProfile.BALANCED.name)
            } catch (e: Exception) {
                ProcessingProfile.BALANCED
            }
        }
        set(value) = prefs.edit().putString(KEY_PROCESSING_PROFILE, value.name).apply()

    var isRawCaptureEnabled: Boolean
        get() = prefs.getBoolean(KEY_RAW_ENABLED, false)
        set(value) = prefs.edit().putBoolean(KEY_RAW_ENABLED, value).apply()

    var showHorizonLevel: Boolean
        get() = prefs.getBoolean(KEY_SHOW_HORIZON, true)
        set(value) = prefs.edit().putBoolean(KEY_SHOW_HORIZON, value).apply()

    var showHistogram: Boolean
        get() = prefs.getBoolean(KEY_SHOW_HISTOGRAM, true)
        set(value) = prefs.edit().putBoolean(KEY_SHOW_HISTOGRAM, value).apply()

    var showFocusPeaking: Boolean
        get() = prefs.getBoolean(KEY_SHOW_PEAKING, false)
        set(value) = prefs.edit().putBoolean(KEY_SHOW_PEAKING, value).apply()

    var showZebraWarning: Boolean
        get() = prefs.getBoolean(KEY_SHOW_ZEBRA, false)
        set(value) = prefs.edit().putBoolean(KEY_SHOW_ZEBRA, value).apply()

    var faceTrackingEnabled: Boolean
        get() = prefs.getBoolean(KEY_FACE_TRACKING, true)
        set(value) = prefs.edit().putBoolean(KEY_FACE_TRACKING, value).apply()

    var gridType: GridType
        get() {
            val name = prefs.getString(KEY_GRID_TYPE, GridType.RULE_OF_THIRDS.name)
            return try {
                GridType.valueOf(name ?: GridType.RULE_OF_THIRDS.name)
            } catch (e: Exception) {
                GridType.RULE_OF_THIRDS
            }
        }
        set(value) = prefs.edit().putString(KEY_GRID_TYPE, value.name).apply()

    var timerSeconds: Int
        get() = prefs.getInt(KEY_TIMER_SECONDS, 0)
        set(value) = prefs.edit().putInt(KEY_TIMER_SECONDS, value).apply()

    var soundEnabled: Boolean
        get() = prefs.getBoolean(KEY_SOUND_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_SOUND_ENABLED, value).apply()

    var cloudConsentGiven: Boolean
        get() = prefs.getBoolean(KEY_CLOUD_CONSENT, false)
        set(value) = prefs.edit().putBoolean(KEY_CLOUD_CONSENT, value).apply()

    companion object {
        private const val KEY_AI_PROVIDER = "pref_ai_provider"
        private const val KEY_OPENAI_API_KEY = "pref_openai_api_key"
        private const val KEY_GEMINI_API_KEY = "pref_gemini_api_key"
        private const val KEY_OPENAI_MODEL = "pref_openai_model"
        private const val KEY_GEMINI_MODEL = "pref_gemini_model"
        private const val KEY_JPEG_QUALITY = "pref_jpeg_quality"
        private const val KEY_TARGET_RES_MP = "pref_target_res_mp"
        private const val KEY_AI_MODE = "pref_ai_mode"
        private const val KEY_COLOR_PROFILE = "pref_color_profile"
        private const val KEY_PROCESSING_PROFILE = "pref_processing_profile"
        private const val KEY_RAW_ENABLED = "pref_raw_enabled"
        private const val KEY_SHOW_HORIZON = "pref_show_horizon"
        private const val KEY_SHOW_HISTOGRAM = "pref_show_histogram"
        private const val KEY_SHOW_PEAKING = "pref_show_peaking"
        private const val KEY_SHOW_ZEBRA = "pref_show_zebra"
        private const val KEY_FACE_TRACKING = "pref_face_tracking"
        private const val KEY_GRID_TYPE = "pref_grid_type"
        private const val KEY_TIMER_SECONDS = "pref_timer_seconds"
        private const val KEY_SOUND_ENABLED = "pref_sound_enabled"
        private const val KEY_CLOUD_CONSENT = "pref_cloud_consent"
    }
}
