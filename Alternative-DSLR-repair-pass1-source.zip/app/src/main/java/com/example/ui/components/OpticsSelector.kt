package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.camera.CameraMode
import com.example.camera.CameraUiState
import com.example.camera.VirtualAperture
import com.example.camera.VirtualLens
import com.example.ui.theme.DslrAmber
import com.example.ui.theme.DslrCyan
import com.example.ui.theme.DslrGold
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.TitaniumBright
import com.example.ui.theme.TitaniumDark
import com.example.ui.theme.TitaniumSilver

@Composable
fun OpticsSelector(
    state: CameraUiState,
    onSetZoomRatio: (Float) -> Unit,
    onSelectVirtualLens: (VirtualLens?) -> Unit,
    onSelectVirtualAperture: (VirtualAperture) -> Unit,
    modifier: Modifier = Modifier
) {
    var showZoomSlider by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // True Optical / Computational Status Badge
        val zoomClassification = when {
            state.selectedMode == CameraMode.PORTRAIT -> "COMPUTATIONAL PORTRAIT OPTICS (SIMULATION)"
            state.zoomRatio < 0.9f -> "ULTRAWIDE 0.6x (OPTICAL SENSOR)"
            kotlin.math.abs(state.zoomRatio - 1.0f) < 0.1f -> "WIDE MAIN 1.0x (OPTICAL SENSOR)"
            state.zoomRatio <= 2.2f -> "HYBRID CROP (${String.format("%.1f", state.zoomRatio)}x • SENSOR FUSION)"
            state.zoomRatio <= 5.0f -> "TELEPHOTO (${String.format("%.1f", state.zoomRatio)}x • OPTICAL/HYBRID)"
            else -> "DIGITAL ZOOM (${String.format("%.1f", state.zoomRatio)}x • AI ENHANCED)"
        }

        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(4.dp))
                .background(ObsidianBlack.copy(alpha = 0.80f))
                .padding(horizontal = 8.dp, vertical = 2.dp)
        ) {
            Text(
                text = zoomClassification,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                color = if (state.selectedMode == CameraMode.PORTRAIT) DslrGold else if (state.zoomRatio <= 1.0f) DslrCyan else DslrAmber,
                fontFamily = FontFamily.Monospace
            )
        }

        Spacer(modifier = Modifier.height(4.dp))

        // If in Portrait Mode, show virtual aperture & virtual portrait lens choices
        if (state.selectedMode == CameraMode.PORTRAIT) {
            // Virtual Aperture selector (f/1.2 - f/8)
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(bottom = 6.dp)
            ) {
                items(VirtualAperture.values()) { aperture ->
                    val isSelected = aperture == state.virtualAperture
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isSelected) DslrAmber else TitaniumDark.copy(alpha = 0.8f))
                            .clickable { onSelectVirtualAperture(aperture) }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                            .testTag("aperture_${aperture.name.lowercase()}")
                    ) {
                        Text(
                            text = aperture.label,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) ObsidianBlack else TitaniumSilver,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            // Virtual Portrait Lenses (70mm, 85mm, 105mm, 135mm, 200mm)
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                items(VirtualLens.values()) { lens ->
                    val isSelected = lens == state.virtualLens
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isSelected) DslrGold else TitaniumDark.copy(alpha = 0.8f))
                            .clickable { onSelectVirtualLens(lens) }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                            .testTag("virtual_lens_${lens.focalLengthMm}mm")
                    ) {
                        Text(
                            text = "${lens.label} (${lens.character})",
                            fontSize = 10.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) ObsidianBlack else TitaniumSilver,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        } else {
            // Smooth Zoom Slider
            AnimatedVisibility(visible = showZoomSlider) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth(0.9f)
                        .padding(horizontal = 12.dp, vertical = 4.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(ObsidianBlack.copy(alpha = 0.85f))
                        .padding(horizontal = 12.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "0.6x",
                        fontSize = 10.sp,
                        color = TitaniumSilver,
                        fontFamily = FontFamily.Monospace
                    )
                    Slider(
                        value = state.zoomRatio,
                        onValueChange = { onSetZoomRatio(it) },
                        valueRange = state.minZoomRatio..state.maxZoomRatio,
                        colors = SliderDefaults.colors(
                            thumbColor = DslrAmber,
                            activeTrackColor = DslrAmber,
                            inactiveTrackColor = TitaniumDark
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 8.dp)
                            .testTag("zoom_slider")
                    )
                    Text(
                        text = "${String.format("%.1f", state.maxZoomRatio)}x",
                        fontSize = 10.sp,
                        color = TitaniumSilver,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            // Standard Optical / Computational Zoom Presets
            val zoomSteps = listOf(0.6f, 1.0f, 2.0f, 3.0f, 5.0f, 8.0f)
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(ObsidianBlack.copy(alpha = 0.75f))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                zoomSteps.forEach { step ->
                    val isSelected = kotlin.math.abs(state.zoomRatio - step) < 0.18f
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(if (isSelected) DslrAmber else Color.Transparent)
                            .clickable { onSetZoomRatio(step) }
                            .testTag("zoom_button_${(step * 10).toInt()}"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (step == 0.6f) ".6" else "${step.toInt()}x",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) ObsidianBlack else TitaniumSilver,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                // Slider Toggle Icon
                IconButton(
                    onClick = { showZoomSlider = !showZoomSlider },
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(if (showZoomSlider) DslrAmber.copy(alpha = 0.3f) else Color.Transparent)
                        .testTag("toggle_zoom_slider")
                ) {
                    Icon(
                        imageVector = Icons.Default.Tune,
                        contentDescription = "Zoom Slider",
                        tint = if (showZoomSlider) DslrAmber else TitaniumSilver,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}
