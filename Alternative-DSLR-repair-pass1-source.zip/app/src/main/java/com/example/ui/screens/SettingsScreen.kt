package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.RadioButtonChecked
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.MainViewModel
import com.example.camera.CameraUiState
import com.example.camera.GridType
import com.example.settings.AiProcessingMode
import com.example.settings.AiProvider
import com.example.settings.ColorScienceProfile
import com.example.settings.SettingsRepository
import com.example.ui.theme.DslrAmber
import com.example.ui.theme.DslrCyan
import com.example.ui.theme.DslrGold
import com.example.ui.theme.DslrGreen
import com.example.ui.theme.MetallicCarbon
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.TitaniumBright
import com.example.ui.theme.TitaniumDark
import com.example.ui.theme.TitaniumMid
import com.example.ui.theme.TitaniumSilver

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: MainViewModel,
    state: CameraUiState,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onNavigateBack() }
    val context = LocalContext.current
    val settingsRepo = remember { SettingsRepository(context) }
    var openAiKeyInput by remember { mutableStateOf(settingsRepo.openAiApiKey) }
    var geminiKeyInput by remember { mutableStateOf(settingsRepo.geminiApiKey) }
    var activeAiProvider by remember { mutableStateOf(settingsRepo.aiProvider) }
    var keySaveFeedback by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Alternative DSLR Settings",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = TitaniumBright
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("settings_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = TitaniumBright
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = ObsidianBlack
                )
            )
        },
        containerColor = ObsidianBlack,
        modifier = modifier.fillMaxSize()
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // ==========================================
            // Section 1: 24MP, 100MP, and 200MP Output System
            // ==========================================
            SettingsHeader("RESOLUTION & SUPER-RESOLUTION TARGET")
            Text(
                text = "Choose an output target. Native capture is used only when the sensor supports it; otherwise this build uses conventional interpolation, not a trained AI super-resolution model.",
                fontSize = 11.sp,
                color = TitaniumSilver,
                modifier = Modifier.padding(bottom = 10.dp)
            )

            // 24MP Option
            ResolutionCard(
                mp = 24,
                title = "24MP Enhanced",
                description = "Captures using closest supported native camera resolution (or interpolated 24MP). Fast processing, zero lag.",
                isSelected = state.targetSuperResMegapixels == 24,
                tag = "resolution_24mp_card",
                onClick = { viewModel.setTargetResolutionMp(24) }
            )

            Spacer(modifier = Modifier.height(8.dp))

            // 100MP Option
            ResolutionCard(
                mp = 100,
                title = "100MP Output Target",
                description = "Native only if supported by the sensor. Otherwise conventional upscaling; it does not create genuine missing detail.",
                isSelected = state.targetSuperResMegapixels == 100,
                tag = "resolution_100mp_card",
                onClick = { viewModel.setTargetResolutionMp(100) }
            )

            Spacer(modifier = Modifier.height(8.dp))

            // 200MP Option
            ResolutionCard(
                mp = 200,
                title = "200MP Output Target",
                description = "Attempts a memory-aware interpolated output. Not native 200MP and not AI reconstruction. Actual saved dimensions may be lower on memory-limited devices.",
                isSelected = state.targetSuperResMegapixels == 200,
                tag = "resolution_200mp_card",
                onClick = { viewModel.setTargetResolutionMp(200) }
            )

            Spacer(modifier = Modifier.height(18.dp))

            // ==========================================
            // Section 2: Hybrid AI Processing Architecture
            // ==========================================
            SettingsHeader("HYBRID AI ENGINE (ON-DEVICE + CLOUD)")
            Text(
                text = "Select how AI imaging algorithms execute. Privacy-first: personal photos are never uploaded without consent.",
                fontSize = 11.sp,
                color = TitaniumSilver,
                modifier = Modifier.padding(bottom = 10.dp)
            )

            Card(
                colors = CardDefaults.cardColors(containerColor = MetallicCarbon),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    AiProcessingMode.values().forEach { mode ->
                        val isSelected = state.aiProcessingMode == mode
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) TitaniumDark else Color.Transparent)
                                .clickable { viewModel.setAiProcessingMode(mode) }
                                .padding(10.dp)
                                .testTag("ai_mode_${mode.name.lowercase()}"),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (isSelected) Icons.Default.RadioButtonChecked else Icons.Default.RadioButtonUnchecked,
                                contentDescription = null,
                                tint = if (isSelected) DslrAmber else TitaniumSilver,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = mode.label,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) DslrAmber else TitaniumBright
                                )
                                Text(
                                    text = mode.description,
                                    fontSize = 10.sp,
                                    color = TitaniumSilver,
                                    lineHeight = 14.sp
                                )
                            }
                        }
                        if (mode != AiProcessingMode.values().last()) {
                            Spacer(modifier = Modifier.height(4.dp))
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // ==========================================
            // Section 3: Face & Eye Tracking
            // ==========================================
            SettingsHeader("AUTOFOCUS & TRACKING SYSTEM")
            Card(
                colors = CardDefaults.cardColors(containerColor = MetallicCarbon),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    SettingToggleRow(
                        title = "DSLR Face & Eye Autofocus",
                        subtitle = "Real-time face detection, eye landmarks, and AF/AE priority tracking",
                        isChecked = state.isFaceTrackingEnabled,
                        onCheckedChange = { viewModel.toggleFaceTracking() }
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // ==========================================
            // Section 4: Photographic Color Science
            // ==========================================
            SettingsHeader("NATURAL COLOR SCIENCE")
            Text(
                text = "10 calibrated photographic color profiles preserving authentic skin tones and greens.",
                fontSize = 11.sp,
                color = TitaniumSilver,
                modifier = Modifier.padding(bottom = 10.dp)
            )

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(ColorScienceProfile.values()) { prof ->
                    val isSelected = state.colorProfile == prof
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) DslrCyan else MetallicCarbon)
                            .border(
                                BorderStroke(1.dp, if (isSelected) DslrCyan else TitaniumMid),
                                RoundedCornerShape(8.dp)
                            )
                            .clickable { viewModel.setColorProfile(prof) }
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                            .testTag("color_profile_${prof.name.lowercase()}")
                    ) {
                        Column {
                            Text(
                                text = prof.label,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) ObsidianBlack else TitaniumBright,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = prof.description.take(24) + "...",
                                fontSize = 9.sp,
                                color = if (isSelected) ObsidianBlack.copy(alpha = 0.8f) else TitaniumSilver
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // ==========================================
            // Section 5: Viewfinder & Composition Overlays
            // ==========================================
            SettingsHeader("VIEWFINDER TOOLS & COMPOSITION")
            Card(
                colors = CardDefaults.cardColors(containerColor = MetallicCarbon),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    SettingToggleRow(
                        title = "Artificial Horizon Level",
                        subtitle = "Pitch & roll sensor indicator with ±1° green level lock",
                        isChecked = state.showHorizonLevel,
                        onCheckedChange = { viewModel.toggleHorizonLevel() }
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    SettingToggleRow(
                        title = "Real-time Luminance Histogram",
                        subtitle = "32-bin preview luminance distribution graph",
                        isChecked = state.showHistogram,
                        onCheckedChange = { viewModel.toggleHistogram() }
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    SettingToggleRow(
                        title = "Focus Peaking",
                        subtitle = "Green focal plane highlighting on contrast edges",
                        isChecked = state.showFocusPeaking,
                        onCheckedChange = { viewModel.toggleFocusPeaking() }
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    SettingToggleRow(
                        title = "Zebra 95% Exposure Warning",
                        subtitle = "Diagonal warning hatching in clipped highlight regions",
                        isChecked = state.showZebraWarning,
                        onCheckedChange = { viewModel.toggleZebraWarning() }
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    SettingOptionSelector(
                        title = "Framing Grid",
                        options = GridType.values().toList(),
                        labels = listOf("None", "3×3", "Phi", "1:1"),
                        selected = state.gridType,
                        onSelect = { viewModel.setGridType(it) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // ==========================================
            // Section 6: Capture Format & Shutter Timer
            // ==========================================
            SettingsHeader("FORMAT & SHUTTER")
            Card(
                colors = CardDefaults.cardColors(containerColor = MetallicCarbon),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    SettingToggleRow(
                        title = "RAW DNG Capture",
                        subtitle = "Save uncompressed 14-bit DNG alongside processed JPEG",
                        isChecked = state.isRawCaptureEnabled,
                        onCheckedChange = { viewModel.toggleRaw() }
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    SettingOptionSelector(
                        title = "Self-Timer",
                        options = listOf(0, 3, 5, 10),
                        labels = listOf("Off", "3s", "5s", "10s"),
                        selected = state.timerSeconds,
                        onSelect = { viewModel.setTimerSeconds(it) }
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Storage: DCIM/AlternativeDSLR",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = TitaniumBright
                    )
                    Text(
                        text = "Exif tags: ISO, shutter speed, focal length, color profile, and processing mode.",
                        fontSize = 10.sp,
                        color = TitaniumSilver,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // ==========================================
            // Section 7: AI Assistant Configuration (Gemini & ChatGPT)
            // ==========================================
            SettingsHeader("AI ASSISTANT & CLOUD PROVIDER CONFIGURATION")
            Text(
                text = "Alternative DSLR features genuine Google Gemini and OpenAI ChatGPT integration. Select your active assistant provider and configure your API credentials securely.",
                fontSize = 11.sp,
                color = TitaniumSilver,
                modifier = Modifier.padding(bottom = 10.dp)
            )

            Card(
                colors = CardDefaults.cardColors(containerColor = MetallicCarbon),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Active AI Provider",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = TitaniumBright
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    AiProvider.values().forEach { provider ->
                        val isSelected = activeAiProvider == provider
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) TitaniumDark else Color.Transparent)
                                .clickable {
                                    activeAiProvider = provider
                                    settingsRepo.aiProvider = provider
                                }
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (isSelected) Icons.Default.RadioButtonChecked else Icons.Default.RadioButtonUnchecked,
                                contentDescription = null,
                                tint = if (isSelected) DslrAmber else TitaniumSilver,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = provider.label,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) DslrAmber else TitaniumBright
                                )
                                Text(
                                    text = provider.subtitle,
                                    fontSize = 10.sp,
                                    color = TitaniumSilver
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // OpenAI API Key
                    Text(
                        text = "OpenAI API Key (ChatGPT)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = TitaniumBright
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = openAiKeyInput,
                            onValueChange = { openAiKeyInput = it },
                            placeholder = { Text("sk-...", fontSize = 11.sp, color = TitaniumMid) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = DslrAmber,
                                unfocusedBorderColor = TitaniumDark,
                                focusedTextColor = TitaniumBright,
                                unfocusedTextColor = TitaniumBright
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .testTag("openai_key_input")
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                settingsRepo.openAiApiKey = openAiKeyInput
                                keySaveFeedback = "OpenAI API Key Saved"
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = DslrAmber),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("save_openai_key_button")
                        ) {
                            Text("Save", color = ObsidianBlack, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Google Gemini API Key
                    Text(
                        text = "Google AI Studio API Key (Gemini)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = TitaniumBright
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = geminiKeyInput,
                            onValueChange = { geminiKeyInput = it },
                            placeholder = { Text("AIzaSy...", fontSize = 11.sp, color = TitaniumMid) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = DslrCyan,
                                unfocusedBorderColor = TitaniumDark,
                                focusedTextColor = TitaniumBright,
                                unfocusedTextColor = TitaniumBright
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .testTag("gemini_key_input")
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                settingsRepo.geminiApiKey = geminiKeyInput
                                keySaveFeedback = "Gemini API Key Saved"
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = DslrCyan),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("save_gemini_key_button")
                        ) {
                            Text("Save", color = ObsidianBlack, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }

                    keySaveFeedback?.let { feedback ->
                        Text(
                            text = feedback,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = DslrGreen,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    SettingToggleRow(
                        title = "Cloud Upload Consent",
                        subtitle = "Allow sending image metadata & thumbnails to configured cloud AI for critique",
                        isChecked = settingsRepo.cloudConsentGiven,
                        onCheckedChange = { settingsRepo.cloudConsentGiven = it }
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // ==========================================
            // Section 8: JPEG Compression Quality
            // ==========================================
            SettingsHeader("IMAGE COMPRESSION & JPEG FIDELITY")
            Card(
                colors = CardDefaults.cardColors(containerColor = MetallicCarbon),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    SettingOptionSelector(
                        title = "JPEG Quality",
                        options = listOf(90, 95, 100),
                        labels = listOf("90% Fine", "95% Super Fine", "100% Studio Fidelity"),
                        selected = settingsRepo.jpegQuality,
                        onSelect = { settingsRepo.jpegQuality = it }
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun ResolutionCard(
    mp: Int,
    title: String,
    description: String,
    isSelected: Boolean,
    tag: String,
    onClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) TitaniumDark else MetallicCarbon
        ),
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(
            1.5.dp,
            if (isSelected) DslrAmber else TitaniumMid
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag(tag)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (isSelected) DslrAmber else TitaniumMid)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "${mp}MP",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) ObsidianBlack else TitaniumBright,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = title,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isSelected) DslrAmber else TitaniumBright
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = description,
                    fontSize = 11.sp,
                    color = TitaniumSilver,
                    lineHeight = 15.sp
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            Icon(
                imageVector = if (isSelected) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                contentDescription = if (isSelected) "Selected" else "Not selected",
                tint = if (isSelected) DslrAmber else TitaniumMid,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}

@Composable
private fun SettingsHeader(title: String) {
    Text(
        text = title,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        color = DslrAmber,
        fontFamily = FontFamily.Monospace,
        letterSpacing = 1.sp,
        modifier = Modifier.padding(bottom = 6.dp)
    )
}

@Composable
private fun SettingToggleRow(
    title: String,
    subtitle: String,
    isChecked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = TitaniumBright
            )
            Text(
                text = subtitle,
                fontSize = 10.sp,
                color = TitaniumSilver
            )
        }
        Switch(
            checked = isChecked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = ObsidianBlack,
                checkedTrackColor = DslrAmber,
                uncheckedThumbColor = TitaniumSilver,
                uncheckedTrackColor = TitaniumDark
            )
        )
    }
}

@Composable
private fun <T> SettingOptionSelector(
    title: String,
    options: List<T>,
    labels: List<String>,
    selected: T,
    onSelect: (T) -> Unit
) {
    Column {
        Text(
            text = title,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = TitaniumBright,
            modifier = Modifier.padding(bottom = 6.dp)
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            options.forEachIndexed { i, opt ->
                val isSel = opt == selected
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSel) DslrAmber else TitaniumDark
                    ),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onSelect(opt) }
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = labels[i],
                            fontSize = 11.sp,
                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSel) ObsidianBlack else TitaniumSilver,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}
