package com.example

import android.app.Application
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.util.Log
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.SurfaceOrientedMeteringPointFactory
import androidx.camera.view.LifecycleCameraController
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.AiAssistantRepository
import com.example.camera.ActiveScreen
import com.example.camera.CameraMode
import com.example.camera.CameraUiState
import com.example.camera.FaceTracker
import com.example.camera.FaceTrackingState
import com.example.camera.GridType
import com.example.camera.VirtualAperture
import com.example.camera.VirtualLens
import com.example.capability.DeviceProfiler
import com.example.capability.ProcessingProfile
import com.example.engine.ComputationalPipeline
import com.example.engine.PipelineRequest
import com.example.engine.ShotMetadata
import com.example.gallery.CapturedMediaItem
import com.example.gallery.GalleryRepository
import com.example.settings.AiProcessingMode
import com.example.settings.ColorScienceProfile
import com.example.settings.SettingsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.concurrent.Executors

class MainViewModel(application: Application) : AndroidViewModel(application), SensorEventListener {

    private val settingsRepo = SettingsRepository(application)
    private val faceTracker = FaceTracker()
    val aiAssistantRepo = AiAssistantRepository(application)

    private val _uiState = MutableStateFlow(
        CameraUiState(
            targetSuperResMegapixels = settingsRepo.targetResolutionMp,
            aiProcessingMode = settingsRepo.aiProcessingMode,
            colorProfile = settingsRepo.colorProfile,
            currentProfile = settingsRepo.processingProfile,
            isRawCaptureEnabled = settingsRepo.isRawCaptureEnabled,
            showHorizonLevel = settingsRepo.showHorizonLevel,
            showHistogram = settingsRepo.showHistogram,
            showFocusPeaking = settingsRepo.showFocusPeaking,
            showZebraWarning = settingsRepo.showZebraWarning,
            isFaceTrackingEnabled = settingsRepo.faceTrackingEnabled,
            gridType = settingsRepo.gridType,
            timerSeconds = settingsRepo.timerSeconds
        )
    )
    val uiState: StateFlow<CameraUiState> = _uiState.asStateFlow()

    private var cameraController: LifecycleCameraController? = null
    private val sensorManager = application.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
    private val rotationSensor = sensorManager?.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        ?: sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private var countdownJob: Job? = null
    private var videoTimerJob: Job? = null

    init {
        // Inspect actual hardware capabilities at launch
        val caps = DeviceProfiler.inspectDevice(application)
        _uiState.update {
            it.copy(
                capabilities = caps,
                isBackCamera = true
            )
        }

        // Initialize sensor for real-time horizon level
        rotationSensor?.let {
            sensorManager?.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
        }

        // Observe face tracking state
        viewModelScope.launch {
            faceTracker.trackingState.collect { faceState ->
                if (_uiState.value.isFaceTrackingEnabled) {
                    _uiState.update { it.copy(faceTrackingState = faceState) }
                }
            }
        }

        // Preload recent captures for gallery thumbnail
        refreshGallery()
    }

    fun attachCameraController(controller: LifecycleCameraController) {
        this.cameraController = controller
        controller.cameraSelector = if (_uiState.value.isBackCamera) {
            CameraSelector.DEFAULT_BACK_CAMERA
        } else {
            CameraSelector.DEFAULT_FRONT_CAMERA
        }

        // Enable both ImageCapture and VideoCapture use cases
        try {
            controller.setEnabledUseCases(
                LifecycleCameraController.IMAGE_CAPTURE or
                    LifecycleCameraController.VIDEO_CAPTURE or
                    LifecycleCameraController.IMAGE_ANALYSIS
            )
        } catch (e: Exception) {
            Log.w("MainViewModel", "Could not bind both image and video simultaneously, fallback to default", e)
        }

        // Setup real-time ImageAnalysis for face tracking, histogram, and scene analysis
        controller.setImageAnalysisAnalyzer(cameraExecutor) { imageProxy ->
            try {
                // 1. Histogram & luminance analysis
                analyzeFrameForHistogram(imageProxy)

                // 2. Face & Eye tracking if enabled
                if (_uiState.value.isFaceTrackingEnabled) {
                    faceTracker.processImageProxy(
                        imageProxy = imageProxy,
                        isFrontCamera = !_uiState.value.isBackCamera
                    )
                } else {
                    imageProxy.close()
                }
            } catch (e: Exception) {
                imageProxy.close()
            }
        }
    }

    private fun analyzeFrameForHistogram(imageProxy: ImageProxy) {
        try {
            val plane = imageProxy.planes[0]
            val buffer = plane.buffer
            val remaining = buffer.remaining()
            if (remaining > 0) {
                val bins = FloatArray(32)
                val step = (remaining / 2048).coerceAtLeast(1)
                var count = 0
                for (i in 0 until remaining step step) {
                    val yVal = (buffer.get(i).toInt() and 0xFF)
                    val binIndex = (yVal * 32 / 256).coerceIn(0, 31)
                    bins[binIndex]++
                    count++
                }
                if (count > 0) {
                    val max = bins.maxOrNull() ?: 1.0f
                    for (b in bins.indices) {
                        bins[b] = (bins[b] / max).coerceIn(0.05f, 1.0f)
                    }
                    _uiState.update { it.copy(histogramLuminance = bins) }
                }
            }
        } catch (e: Exception) {
            // Frame analysis skip
        }
    }

    fun tapToFocus(normX: Float, normY: Float) {
        // First check if user tapped a face directly
        val selectedFace = faceTracker.selectFaceAt(normX, normY)
        val controller = cameraController ?: return

        try {
            val factory = SurfaceOrientedMeteringPointFactory(1.0f, 1.0f)
            val point = if (selectedFace != null) {
                val cx = selectedFace.bounds.centerX()
                val cy = selectedFace.bounds.centerY()
                factory.createPoint(cx, cy)
            } else {
                factory.createPoint(normX, normY)
            }

            val action = FocusMeteringAction.Builder(point, FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE)
                .setAutoCancelDuration(3, java.util.concurrent.TimeUnit.SECONDS)
                .build()

            controller.cameraControl?.startFocusAndMetering(action)?.addListener(
                {
                    faceTracker.setFocusLocked(true)
                },
                cameraExecutor
            )
        } catch (e: Exception) {
            Log.w("MainViewModel", "Focus metering error", e)
        }
    }

    fun selectFace(normX: Float, normY: Float) {
        tapToFocus(normX, normY)
    }

    fun setTargetResolutionMp(mp: Int) {
        settingsRepo.targetResolutionMp = mp
        val desc = when (mp) {
            200 -> "200MP output target (interpolation only; not AI super-resolution)"
            100 -> "100MP output target (interpolation only; not AI super-resolution)"
            else -> "24MP Mode (Enhanced High-Fidelity)"
        }
        _uiState.update {
            it.copy(
                targetSuperResMegapixels = mp,
                lastStatusMessage = "Resolution Target: $desc"
            )
        }
    }

    fun setAiProcessingMode(mode: AiProcessingMode) {
        settingsRepo.aiProcessingMode = mode
        _uiState.update {
            it.copy(
                aiProcessingMode = mode,
                lastStatusMessage = "AI Mode: ${mode.label}"
            )
        }
    }

    fun setColorProfile(profile: ColorScienceProfile) {
        settingsRepo.colorProfile = profile
        _uiState.update {
            it.copy(
                colorProfile = profile,
                lastStatusMessage = "Color Profile: ${profile.label}"
            )
        }
    }

    fun toggleFaceTracking() {
        val newVal = !_uiState.value.isFaceTrackingEnabled
        settingsRepo.faceTrackingEnabled = newVal
        _uiState.update {
            it.copy(
                isFaceTrackingEnabled = newVal,
                faceTrackingState = if (newVal) it.faceTrackingState else FaceTrackingState(faces = emptyList()),
                lastStatusMessage = if (newVal) "Face & Eye Tracking: Enabled" else "Face & Eye Tracking: Disabled"
            )
        }
    }

    fun onScreenChange(screen: ActiveScreen) {
        _uiState.update { it.copy(activeScreen = screen) }
        if (screen == ActiveScreen.GALLERY) {
            refreshGallery()
        }
    }

    fun onSelectMediaDetail(item: CapturedMediaItem?) {
        _uiState.update {
            it.copy(
                selectedMediaDetail = item,
                activeScreen = if (item != null) ActiveScreen.IMAGE_DETAIL else ActiveScreen.GALLERY
            )
        }
    }

    fun openPhotoEditor(item: CapturedMediaItem) {
        _uiState.update {
            it.copy(
                photoEditorItem = item,
                activeScreen = ActiveScreen.PHOTO_EDITOR
            )
        }
    }

    fun onPhotoEditorSaved() {
        refreshGallery()
        _uiState.update {
            it.copy(
                activeScreen = ActiveScreen.GALLERY,
                lastStatusMessage = "Edited copy saved to DCIM/AlternativeDSLR"
            )
        }
    }

    fun openAiCritiqueForPhoto(item: CapturedMediaItem) {
        viewModelScope.launch {
            val bmp = GalleryRepository.loadBitmap(getApplication(), item.uri)
            if (bmp != null) {
                aiAssistantRepo.sendMessage(
                    "Please provide an expert DSLR critique of this photograph. Evaluate framing, exposure balance, texture sharpness, and recommended color science adjustments.",
                    bmp
                )
            }
            onScreenChange(ActiveScreen.AI_ASSISTANT)
        }
    }

    fun onSelectMode(mode: CameraMode) {
        _uiState.update { current ->
            val newProfile = when (mode) {
                CameraMode.HIGH_RES -> ProcessingProfile.MAXIMUM_QUALITY
                CameraMode.NIGHT, CameraMode.HDR, CameraMode.PORTRAIT ->
                    if (current.currentProfile == ProcessingProfile.LITE) ProcessingProfile.BALANCED else current.currentProfile
                else -> current.currentProfile
            }

            val defaultAperture = if (mode == CameraMode.PORTRAIT) VirtualAperture.F1_4 else VirtualAperture.F8_0
            val virtualLens = if (mode == CameraMode.PORTRAIT && current.virtualLens == null) VirtualLens.LENS_85MM else current.virtualLens

            current.copy(
                selectedMode = mode,
                currentProfile = newProfile,
                virtualAperture = defaultAperture,
                virtualLens = virtualLens,
                lastStatusMessage = "Mode: ${mode.title} - ${mode.description}"
            )
        }

        _uiState.value.virtualLens?.let { lens ->
            if (_uiState.value.selectedMode == CameraMode.PORTRAIT) {
                setZoomRatio(lens.zoomFactor)
            }
        }
    }

    fun toggleCameraFacing() {
        val newFacingBack = !_uiState.value.isBackCamera
        _uiState.update { it.copy(isBackCamera = newFacingBack, zoomRatio = 1.0f) }
        cameraController?.cameraSelector = if (newFacingBack) {
            CameraSelector.DEFAULT_BACK_CAMERA
        } else {
            CameraSelector.DEFAULT_FRONT_CAMERA
        }
    }

    fun setZoomRatio(ratio: Float) {
        val clamped = ratio.coerceIn(_uiState.value.minZoomRatio, _uiState.value.maxZoomRatio)
        _uiState.update { it.copy(zoomRatio = clamped) }
        cameraController?.setZoomRatio(clamped)
    }

    fun updateHardwareZoomState(zoomRatio: Float, minZoom: Float, maxZoom: Float) {
        _uiState.update {
            it.copy(
                zoomRatio = zoomRatio,
                // Use the camera-reported range exactly. Never advertise a 0.5x
                // lens when the active physical camera only supports 1.0x minimum.
                minZoomRatio = minZoom.coerceAtLeast(1.0f),
                maxZoomRatio = maxZoom.coerceAtLeast(minZoom.coerceAtLeast(1.0f))
            )
        }
    }

    fun setVirtualLens(lens: VirtualLens?) {
        _uiState.update { it.copy(virtualLens = lens) }
        if (lens != null) {
            setZoomRatio(lens.zoomFactor)
        }
    }

    fun setVirtualAperture(aperture: VirtualAperture) {
        _uiState.update { it.copy(virtualAperture = aperture) }
    }

    fun setProcessingProfile(profile: ProcessingProfile, manualOverride: Boolean = true) {
        settingsRepo.processingProfile = profile
        _uiState.update { it.copy(currentProfile = profile, isAutoProfile = !manualOverride) }
    }

    fun toggleFlash() {
        val nextFlash = when (_uiState.value.flashMode) {
            ImageCapture.FLASH_MODE_OFF -> ImageCapture.FLASH_MODE_ON
            ImageCapture.FLASH_MODE_ON -> ImageCapture.FLASH_MODE_AUTO
            else -> ImageCapture.FLASH_MODE_OFF
        }
        _uiState.update { it.copy(flashMode = nextFlash) }
        cameraController?.imageCaptureFlashMode = nextFlash
    }

    fun setEvCompensation(index: Int) {
        val range = _uiState.value.capabilities?.exposureCompensationRange ?: Pair(-4, 4)
        val clamped = index.coerceIn(range.first, range.second)
        _uiState.update { it.copy(evCompensation = clamped) }
        try {
            cameraController?.cameraControl?.setExposureCompensationIndex(clamped)
        } catch (e: Exception) {
            Log.w("MainViewModel", "EV adjustment unavailable on this sensor", e)
        }
    }

    fun setManualIso(iso: Int) {
        _uiState.update { it.copy(manualIso = iso, isManualIso = true) }
    }

    fun toggleManualIso() {
        _uiState.update { it.copy(isManualIso = !it.isManualIso) }
    }

    fun setManualShutterSpeed(speed: String) {
        _uiState.update { it.copy(manualShutterSpeed = speed, isManualShutter = true) }
    }

    fun toggleManualShutter() {
        _uiState.update { it.copy(isManualShutter = !it.isManualShutter) }
    }

    fun setManualFocus(distance: Float) {
        _uiState.update { it.copy(manualFocusDistance = distance, isManualFocus = true) }
    }

    fun toggleManualFocus() {
        _uiState.update { it.copy(isManualFocus = !it.isManualFocus) }
    }

    fun setWhiteBalanceKelvin(kelvin: Int) {
        _uiState.update { it.copy(whiteBalanceKelvin = kelvin, isManualWb = true) }
    }

    fun toggleManualWb() {
        _uiState.update { it.copy(isManualWb = !it.isManualWb) }
    }

    fun toggleAeLock() {
        _uiState.update { it.copy(isAeLocked = !it.isAeLocked) }
    }

    fun toggleAfLock() {
        _uiState.update { it.copy(isAfLocked = !it.isAfLocked) }
    }

    fun toggleRaw() {
        val newVal = !_uiState.value.isRawCaptureEnabled
        settingsRepo.isRawCaptureEnabled = newVal
        _uiState.update { it.copy(isRawCaptureEnabled = newVal) }
    }

    fun setGridType(grid: GridType) {
        settingsRepo.gridType = grid
        _uiState.update { it.copy(gridType = grid, showGrid = grid != GridType.NONE) }
    }

    fun toggleHorizonLevel() {
        val newVal = !_uiState.value.showHorizonLevel
        settingsRepo.showHorizonLevel = newVal
        _uiState.update { it.copy(showHorizonLevel = newVal) }
    }

    fun toggleHistogram() {
        val newVal = !_uiState.value.showHistogram
        settingsRepo.showHistogram = newVal
        _uiState.update { it.copy(showHistogram = newVal) }
    }

    fun toggleFocusPeaking() {
        val newVal = !_uiState.value.showFocusPeaking
        settingsRepo.showFocusPeaking = newVal
        _uiState.update { it.copy(showFocusPeaking = newVal) }
    }

    fun toggleZebraWarning() {
        val newVal = !_uiState.value.showZebraWarning
        settingsRepo.showZebraWarning = newVal
        _uiState.update { it.copy(showZebraWarning = newVal) }
    }

    fun setTimerSeconds(seconds: Int) {
        settingsRepo.timerSeconds = seconds
        _uiState.update { it.copy(timerSeconds = seconds) }
    }

    fun triggerShutter() {
        if (_uiState.value.isCapturing) return

        val timer = _uiState.value.timerSeconds
        if (timer > 0) {
            countdownJob?.cancel()
            countdownJob = viewModelScope.launch {
                for (s in timer downTo 1) {
                    _uiState.update { it.copy(countdownRemaining = s) }
                    delay(1000)
                }
                _uiState.update { it.copy(countdownRemaining = 0) }
                performActualCapture()
            }
        } else {
            performActualCapture()
        }
    }

    private fun performActualCapture() {
        _uiState.update {
            it.copy(
                isCapturing = true,
                processingProgress = 0.05f,
                processingStatusDetail = "Sensor Acquisition...",
                lastStatusMessage = "Capturing computational exposure..."
            )
        }

        val controller = cameraController
        if (controller == null) {
            _uiState.update { it.copy(isCapturing = false, lastStatusMessage = "Camera not attached") }
            return
        }

        // Use CameraX JPEG file output. The first ImageProxy plane is YUV luminance,
        // not a JPEG bitstream; decoding it as JPEG damages or breaks the captured image.
        controller.imageCaptureMode = ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY
        val captureFile = java.io.File(
            getApplication<Application>().cacheDir,
            "capture_${System.currentTimeMillis()}.jpg"
        )
        val outputOptions = ImageCapture.OutputFileOptions.Builder(captureFile).build()

        controller.takePicture(
            outputOptions,
            cameraExecutor,
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                    val bitmap = decodeCapturedJpeg(captureFile)
                    captureFile.delete()
                    if (bitmap != null) {
                        viewModelScope.launch { processCapturedBitmap(bitmap) }
                    } else {
                        _uiState.update {
                            it.copy(isCapturing = false, lastStatusMessage = "Captured JPEG could not be decoded")
                        }
                    }
                }

                override fun onError(exception: ImageCaptureException) {
                    captureFile.delete()
                    Log.e("MainViewModel", "Image capture failed", exception)
                    _uiState.update {
                        it.copy(
                            isCapturing = false,
                            lastStatusMessage = "Capture error: ${exception.localizedMessage}"
                        )
                    }
                }
            }
        )
    }

    private suspend fun processCapturedBitmap(rawBitmap: Bitmap) {
        val state = _uiState.value
        val metadata = ShotMetadata(
            iso = if (state.isManualIso) state.manualIso else (state.liveScene?.suggestedIso ?: 100),
            shutterSpeed = if (state.isManualShutter) state.manualShutterSpeed else (state.liveScene?.suggestedShutterSpeed ?: "1/250s"),
            evCompensation = state.evCompensation.toFloat(),
            focalLengthMm = state.virtualLens?.focalLengthMm?.toFloat() ?: 26f,
            aperture = state.virtualAperture.fNumber,
            whiteBalanceKelvin = state.whiteBalanceKelvin,
            isRaw = state.isRawCaptureEnabled,
            processingProfileName = state.currentProfile.title,
            lensFacing = if (state.isBackCamera) "Back" else "Front",
            sensorMegapixels = state.capabilities?.lenses?.firstOrNull()?.maxResolutionMegapixels ?: 12f
        )

        val request = PipelineRequest(
            baseBitmap = rawBitmap,
            mode = state.selectedMode,
            virtualAperture = state.virtualAperture,
            virtualLens = state.virtualLens,
            processingProfile = state.currentProfile,
            metadata = metadata,
            targetSuperResMegapixels = state.targetSuperResMegapixels,
            colorProfile = state.colorProfile,
            aiMode = state.aiProcessingMode,
            onProgress = { progress, detail ->
                _uiState.update {
                    it.copy(
                        processingProgress = progress,
                        processingStatusDetail = detail
                    )
                }
            }
        )

        try {
            val output = ComputationalPipeline.execute(getApplication(), request)
            _uiState.update {
                it.copy(
                    isCapturing = false,
                    processingProgress = 1.0f,
                    processingStatusDetail = null,
                    lastStatusMessage = "Saved: ${output.savedResult.resolution} (${output.appliedEngines.size} engines applied)"
                )
            }
            refreshGallery()
        } catch (e: Exception) {
            Log.e("MainViewModel", "Pipeline execution error", e)
            _uiState.update {
                it.copy(
                    isCapturing = false,
                    processingProgress = 0f,
                    processingStatusDetail = null,
                    lastStatusMessage = "Processing error: ${e.localizedMessage}"
                )
            }
        }
    }

    private fun decodeCapturedJpeg(file: java.io.File): Bitmap? {
        return try {
            if (!file.exists() || file.length() <= 0L) return null
            val bitmap = BitmapFactory.decodeFile(file.absolutePath) ?: return null
            val exif = ExifInterface(file.absolutePath)
            val orientation = exif.getAttributeInt(
                ExifInterface.TAG_ORIENTATION,
                ExifInterface.ORIENTATION_NORMAL
            )
            val matrix = Matrix()
            when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
                ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
                ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
                ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.preScale(-1f, 1f)
                ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.preScale(1f, -1f)
                ExifInterface.ORIENTATION_TRANSPOSE -> {
                    matrix.preScale(-1f, 1f)
                    matrix.postRotate(270f)
                }
                ExifInterface.ORIENTATION_TRANSVERSE -> {
                    matrix.preScale(-1f, 1f)
                    matrix.postRotate(90f)
                }
            }
            if (orientation == ExifInterface.ORIENTATION_NORMAL ||
                orientation == ExifInterface.ORIENTATION_UNDEFINED
            ) bitmap else Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
        } catch (e: Exception) {
            Log.e("MainViewModel", "JPEG decode/orientation error", e)
            null
        }
    }

    private var activeRecording: androidx.camera.video.Recording? = null

    fun toggleVideoRecording() {
        val isRec = _uiState.value.isRecordingVideo
        if (isRec) {
            videoTimerJob?.cancel()
            try {
                activeRecording?.stop()
                activeRecording?.close()
            } catch (e: Exception) {
                Log.w("MainViewModel", "Error stopping recording", e)
            }
            activeRecording = null
            _uiState.update { it.copy(isRecordingVideo = false, lastStatusMessage = "Finalizing video capture...") }
        } else {
            val controller = cameraController
            if (controller == null) {
                _uiState.update { it.copy(lastStatusMessage = "Camera not attached for video recording") }
                return
            }

            val videoFile = java.io.File(getApplication<Application>().cacheDir, "DSLR_VID_${System.currentTimeMillis()}.mp4")
            val outputOptions = androidx.camera.video.FileOutputOptions.Builder(videoFile).build()

            try {
                val recording = controller.startRecording(
                    outputOptions,
                    androidx.camera.view.video.AudioConfig.AUDIO_DISABLED,
                    cameraExecutor
                ) { event ->
                    when (event) {
                        is androidx.camera.video.VideoRecordEvent.Finalize -> {
                            if (!event.hasError()) {
                                viewModelScope.launch {
                                    val savedUri = GalleryRepository.saveVideoToMediaStore(getApplication(), videoFile)
                                    refreshGallery()
                                    _uiState.update {
                                        it.copy(
                                            isRecordingVideo = false,
                                            videoDurationSeconds = 0,
                                            lastStatusMessage = "Video saved: ${videoFile.name}"
                                        )
                                    }
                                }
                            } else {
                                Log.e("MainViewModel", "Video recording finalized with error: ${event.cause}")
                                _uiState.update {
                                    it.copy(
                                        isRecordingVideo = false,
                                        videoDurationSeconds = 0,
                                        lastStatusMessage = "Video capture error: ${event.cause?.localizedMessage ?: "Unknown"}"
                                    )
                                }
                            }
                        }
                    }
                }
                activeRecording = recording
                _uiState.update { it.copy(isRecordingVideo = true, videoDurationSeconds = 0, lastStatusMessage = "Recording video...") }
                videoTimerJob = viewModelScope.launch {
                    while (true) {
                        delay(1000)
                        _uiState.update { it.copy(videoDurationSeconds = it.videoDurationSeconds + 1) }
                    }
                }
            } catch (e: Exception) {
                Log.e("MainViewModel", "Failed to start video recording", e)
                _uiState.update {
                    it.copy(
                        isRecordingVideo = false,
                        videoDurationSeconds = 0,
                        lastStatusMessage = "Recording start failed: ${e.localizedMessage}"
                    )
                }
            }
        }
    }

    fun refreshGallery() {
        viewModelScope.launch {
            val media = GalleryRepository.loadAlternativeDslrMedia(getApplication())
            val newest = media.firstOrNull()
            _uiState.update { it.copy(lastCapturedItem = newest) }
        }
    }

    fun deleteMedia(item: CapturedMediaItem) {
        viewModelScope.launch {
            GalleryRepository.deleteItem(getApplication(), item)
            refreshGallery()
            if (_uiState.value.selectedMediaDetail?.id == item.id) {
                _uiState.update { it.copy(selectedMediaDetail = null, activeScreen = ActiveScreen.GALLERY) }
            }
        }
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event == null) return
        if (event.sensor.type == Sensor.TYPE_ROTATION_VECTOR) {
            val rotationMatrix = FloatArray(9)
            SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)
            val orientation = FloatArray(3)
            SensorManager.getOrientation(rotationMatrix, orientation)
            val pitch = Math.toDegrees(orientation[1].toDouble()).toFloat()
            val roll = Math.toDegrees(orientation[2].toDouble()).toFloat()
            _uiState.update { it.copy(pitchDegrees = pitch, rollDegrees = roll) }
        } else if (event.sensor.type == Sensor.TYPE_ACCELEROMETER) {
            val ax = event.values[0]
            val ay = event.values[1]
            val roll = (Math.atan2(ax.toDouble(), ay.toDouble()) * (180 / Math.PI)).toFloat() - 90f
            _uiState.update { it.copy(rollDegrees = roll) }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onCleared() {
        super.onCleared()
        sensorManager?.unregisterListener(this)
        faceTracker.release()
        cameraExecutor.shutdown()
        countdownJob?.cancel()
        videoTimerJob?.cancel()
    }
}
